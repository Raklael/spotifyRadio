import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
import esbuild from 'esbuild';

const rootDir = process.cwd();
const distDir = path.join(rootDir, 'dist');
fs.mkdirSync(distDir, { recursive: true });

// 1. Compileer Tailwind CSS naar dist/standalone.css
const cssOutPath = path.join(distDir, 'standalone.css');
execSync(
  `npx tailwindcss -i "${path.join(rootDir, 'src/index.css')}" -o "${cssOutPath}" --minify`,
  { stdio: 'inherit' }
);
const css = fs.readFileSync(cssOutPath, 'utf8');

// 2. Bundle React + TypeScript als IIFE (werkt direct vanaf file:// zonder CORS of dev-server)
const result = esbuild.buildSync({
  entryPoints: [path.join(rootDir, 'src/main.tsx')],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['es2020'],
  jsx: 'automatic',
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  loader: {
    '.css': 'empty',
  },
  write: false,
});

const rawJs = result.outputFiles[0].text;
// Voorkom dat een letterlijke </script> string in de bundle de HTML script-tag voortijdig sluit
const safeJs = rawJs.replace(/<\/script>/gi, '<\\/script>');
const safeCss = css.replace(/<\/style>/gi, '<\\/style>');

const html = `<!doctype html>
<html lang="nl" class="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
    <meta name="theme-color" content="#121212" />
    <title>Spotify Friends Radio</title>
    <style>${safeCss}</style>
  </head>
  <body class="bg-[#121212] text-white antialiased selection:bg-[#1ED760]/30 selection:text-white">
    <div id="root"></div>
    <script>${safeJs}</script>
  </body>
</html>
`;

fs.writeFileSync(path.join(rootDir, 'index.html'), html, 'utf8');
fs.writeFileSync(path.join(distDir, 'index.html'), html, 'utf8');
console.log('Standalone index.html gegenereerd (geschikt om direct via file:// te openen).');
