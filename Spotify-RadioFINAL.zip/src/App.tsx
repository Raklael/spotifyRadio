import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { AppProvider, useApp } from './context/AppContext';
import { SpotifyLayout } from './components/layout/SpotifyLayout';
import { HomePage } from './components/home/HomePage';
import { SearchPage } from './components/search/SearchPage';
import { FriendsPage } from './components/friends/FriendsPage';
import { LibraryPage } from './components/library/LibraryPage';
import { FriendProfile } from './components/friends/FriendProfile';
import { GroupProfile } from './components/groups/GroupProfile';
import { RadioBuilder } from './components/radio/RadioBuilder';
import { GroupRadioPlayer } from './components/radio/GroupRadioPlayer';
import { PlaylistDetailPage } from './components/playlist/PlaylistDetailPage';
import { FullPlayer } from './components/player/FullPlayer';
import { DeviceSheet } from './components/player/DeviceSheet';
import { RecommendationExplanation } from './components/radio/RecommendationExplanation';
import { GroupVoting } from './components/radio/GroupVoting';
import { OnboardingModal } from './components/onboarding/OnboardingModal';
import { PrivacyModal } from './components/onboarding/PrivacyModal';

const RouteView: React.FC = () => {
  const { route } = useApp();

  const routeKey =
    route.name === 'tab'
      ? `tab-${route.tab}`
      : route.name === 'friend-profile'
        ? `friend-${route.friendId}`
        : route.name === 'group-profile'
          ? `group-${route.groupId}`
          : route.name === 'playlist-detail'
            ? `playlist-${route.playlistId}`
            : route.name === 'group-radio'
              ? `radio-${route.sessionId}`
              : `builder-${route.preselectedGroupId ?? 'custom'}`;

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={routeKey}
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -4 }}
        transition={{ duration: 0.16, ease: 'easeOut' }}
        className="min-h-full"
      >
        {route.name === 'tab' && route.tab === 'home' && <HomePage />}
        {route.name === 'tab' && route.tab === 'search' && <SearchPage />}
        {route.name === 'tab' && route.tab === 'friends' && <FriendsPage />}
        {route.name === 'tab' && route.tab === 'library' && <LibraryPage />}
        {route.name === 'friend-profile' && <FriendProfile friendId={route.friendId} />}
        {route.name === 'group-profile' && <GroupProfile groupId={route.groupId} />}
        {route.name === 'playlist-detail' && <PlaylistDetailPage playlistId={route.playlistId} />}
        {route.name === 'radio-builder' && (
          <RadioBuilder
            preselectedFriendIds={route.preselectedFriendIds}
            preselectedGroupId={route.preselectedGroupId}
            initialStep={route.initialStep}
          />
        )}
        {route.name === 'group-radio' && <GroupRadioPlayer sessionId={route.sessionId} />}
      </motion.div>
    </AnimatePresence>
  );
};

export function App() {
  return (
    <AppProvider>
      <SpotifyLayout>
        <RouteView />
      </SpotifyLayout>
      <FullPlayer />
      <DeviceSheet />
      <RecommendationExplanation />
      <GroupVoting />
      <OnboardingModal />
      <PrivacyModal />
    </AppProvider>
  );
}

export default App;
