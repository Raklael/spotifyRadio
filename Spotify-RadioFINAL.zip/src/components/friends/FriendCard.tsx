import React from 'react';
import { Radio } from 'lucide-react';
import { Friend } from '../../types/music';
import { cn } from '../../utils/cn';

interface FriendCardProps {
  friend: Friend;
  compatibilityScore: number;
  onOpenProfile: () => void;
  onStartRadio: () => void;
}

export const FriendCard: React.FC<FriendCardProps> = ({
  friend,
  compatibilityScore,
  onOpenProfile,
  onStartRadio,
}) => {
  return (
    <div className="rounded-2xl bg-[#181818] hover:bg-[#222222] border border-white/5 p-3 flex items-center gap-3 transition">
      <button
        type="button"
        onClick={onOpenProfile}
        className="flex items-center gap-3 flex-1 min-w-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1ED760] rounded-xl"
      >
        <div className="relative shrink-0">
          <img
            src={friend.avatar}
            alt={friend.name}
            className="w-14 h-14 rounded-full object-cover ring-2 ring-white/10"
          />
          {friend.isOnline && (
            <span
              className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-[#1ED760] ring-2 ring-[#181818]"
              title="Online"
            />
          )}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="text-sm font-extrabold text-white truncate">{friend.name}</p>
            <span className="px-1.5 py-0.5 rounded bg-white/10 text-[10px] font-bold text-[#1ED760] shrink-0">
              {compatibilityScore}% match
            </span>
          </div>
          <p className="text-[11px] font-medium text-[#D1D5DB] truncate mt-0.5">
            {friend.favoriteGenres.slice(0, 2).join(' • ')}
          </p>
          <p className="text-[11px] text-[#B3B3B3] truncate mt-0.5">
            <span
              className={cn(
                'inline-block w-1.5 h-1.5 rounded-full mr-1.5 align-middle',
                friend.isOnline ? 'bg-[#1ED760]' : 'bg-[#727272]'
              )}
            />
            {friend.currentActivity}
          </p>
        </div>
      </button>

      <button
        type="button"
        onClick={onStartRadio}
        className="shrink-0 px-3 py-2 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-95 text-black text-xs font-extrabold inline-flex items-center gap-1.5 transition shadow"
      >
        <Radio className="w-3.5 h-3.5" />
        <span>Start Radio</span>
      </button>
    </div>
  );
};
