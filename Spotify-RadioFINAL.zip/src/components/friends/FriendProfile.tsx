import React, { useMemo } from 'react';
import {
  ArrowLeft,
  Info,
  Play,
  Radio,
  Sparkles,
  UserPlus,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TRACK_BY_ID } from '../../data/mockData';
import { calculateFriendCompatibility } from '../../engine/recommendationEngine';

interface FriendProfileProps {
  friendId: string;
}

export const FriendProfile: React.FC<FriendProfileProps> = ({ friendId }) => {
  const {
    currentUser,
    friends,
    goBack,
    navigate,
    createAndStartRadio,
    playTrack,
  } = useApp();

  const friend = friends.find((f) => f.id === friendId) ?? friends[0];

  const compatibility = useMemo(
    () => calculateFriendCompatibility(currentUser, friend),
    [currentUser, friend]
  );

  const topSongs = useMemo(
    () =>
      friend.likedTracks
        .slice(0, 5)
        .map((id) => TRACK_BY_ID[id])
        .filter((t): t is NonNullable<typeof t> => Boolean(t)),
    [friend.likedTracks]
  );

  const recentSongs = useMemo(
    () =>
      friend.recentlyPlayed
        .map((id) => TRACK_BY_ID[id])
        .filter((t): t is NonNullable<typeof t> => Boolean(t)),
    [friend.recentlyPlayed]
  );

  return (
    <div className="min-h-full bg-gradient-to-b from-[#1E3B2B] via-[#121212] via-35% to-[#121212] pb-8">
      {/* Top Back Bar */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-3 bg-[#121212]/60 backdrop-blur-md">
        <button
          type="button"
          onClick={goBack}
          aria-label="Terug"
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold text-white/80">Vriendenprofiel</span>
        <div className="w-9" />
      </div>

      <div className="px-4 pt-2 space-y-6">
        {/* Hero Profile */}
        <div className="flex flex-col items-center text-center space-y-3">
          <div className="relative">
            <img
              src={friend.avatar}
              alt={friend.fullName}
              className="w-28 h-28 rounded-full object-cover ring-4 ring-[#1ED760]/70 shadow-2xl"
            />
            {friend.isOnline && (
              <span className="absolute bottom-1 right-1 px-2 py-0.5 rounded-full bg-[#1ED760] text-black text-[10px] font-extrabold ring-2 ring-[#121212]">
                Online
              </span>
            )}
          </div>

          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">{friend.fullName}</h1>
            {friend.roleOrTag && (
              <p className="text-xs font-semibold text-[#B3B3B3] mt-0.5">{friend.roleOrTag}</p>
            )}
            <p className="text-xs text-[#1ED760] font-medium mt-1">{friend.currentActivity}</p>
          </div>

          {/* Muzikale Match Card */}
          <div className="w-full rounded-2xl bg-[#181818]/90 border border-white/10 p-3.5 text-left space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#1ED760]" />
                <span className="text-sm font-extrabold text-white">
                  {compatibility.score}% muzikale match
                </span>
              </div>
              <div className="flex -space-x-1.5">
                <img
                  src={currentUser.avatar}
                  alt="Jij"
                  className="w-6 h-6 rounded-full ring-2 ring-[#181818]"
                />
                <img
                  src={friend.avatar}
                  alt={friend.name}
                  className="w-6 h-6 rounded-full ring-2 ring-[#181818]"
                />
              </div>
            </div>
            <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full bg-[#1ED760]"
                style={{ width: `${compatibility.score}%` }}
              />
            </div>
            <p className="text-[11px] text-[#B3B3B3] flex items-start gap-1.5 leading-relaxed">
              <Info className="w-3.5 h-3.5 text-[#B3B3B3] shrink-0 mt-0.5" />
              <span>
                Berekend op basis van gesimuleerde voorkeursdata (gedeelde genres:{' '}
                {compatibility.sharedGenres.length > 0
                  ? compatibility.sharedGenres.join(', ')
                  : 'aanvullende smaken'}
                , artiesten en gelikete nummers).
              </span>
            </p>
          </div>

          {/* Primary & Secondary Actions */}
          <div className="w-full space-y-2.5 pt-1">
            <button
              type="button"
              onClick={() =>
                createAndStartRadio({
                  title: `Radio met ${friend.name}`,
                  sourceType: 'friend',
                  memberIds: [friend.id],
                  vibe: 'gewoon-gezellig',
                  discoveryLevel: 45,
                  equalInfluence: true,
                })
              }
              className="w-full py-3.5 px-5 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-[0.98] text-black font-extrabold text-sm inline-flex items-center justify-center gap-2 shadow-lg transition"
            >
              <Radio className="w-4 h-4" />
              Start Radio met {friend.name}
            </button>

            <button
              type="button"
              onClick={() =>
                navigate({
                  name: 'radio-builder',
                  preselectedFriendIds: [friend.id],
                  initialStep: 1,
                })
              }
              className="w-full py-3 px-5 rounded-full bg-[#282828] hover:bg-[#333333] text-white font-bold text-xs inline-flex items-center justify-center gap-2 transition"
            >
              <UserPlus className="w-4 h-4 text-[#1ED760]" />
              Voeg toe aan groepsradio
            </button>
          </div>
        </div>

        {/* Favoriete Genres */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Favoriete genres
          </h2>
          <div className="flex flex-wrap gap-2">
            {friend.favoriteGenres.map((genre) => (
              <span
                key={genre}
                className="px-3 py-1.5 rounded-full bg-[#282828] text-xs font-bold text-white border border-white/5"
              >
                {genre}
              </span>
            ))}
          </div>
        </section>

        {/* Favoriete Artiesten */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Favoriete artiesten
          </h2>
          <div className="flex flex-wrap gap-2">
            {friend.favoriteArtists.map((artist) => (
              <span
                key={artist}
                className="px-3 py-1.5 rounded-xl bg-[#181818] text-xs font-semibold text-[#D1D5DB] border border-white/10"
              >
                {artist}
              </span>
            ))}
          </div>
        </section>

        {/* Gezamenlijke favorieten */}
        {compatibility.mutualTracks.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Gezamenlijke favoriete nummers ({compatibility.mutualTracks.length})
            </h2>
            <div className="space-y-1.5">
              {compatibility.mutualTracks.map((track) => (
                <button
                  key={track.id}
                  type="button"
                  onClick={() => playTrack(track.id, true)}
                  className="w-full flex items-center gap-3 p-2 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
                >
                  <img
                    src={track.albumArtwork}
                    alt={track.title}
                    className="w-11 h-11 rounded-md object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-white truncate">{track.title}</p>
                    <p className="text-[11px] text-[#B3B3B3] truncate">{track.artist}</p>
                  </div>
                  <span className="text-[10px] font-bold text-[#1ED760] px-2 py-0.5 rounded-full bg-[#1ED760]/10">
                    Allebei leuk
                  </span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Recente luisteractiviteit */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Recent geluisterd door {friend.name}
          </h2>
          <div className="space-y-1.5">
            {recentSongs.map((track) => (
              <button
                key={track.id}
                type="button"
                onClick={() => playTrack(track.id, true)}
                className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#282828] text-left transition"
              >
                <img
                  src={track.albumArtwork}
                  alt={track.title}
                  className="w-10 h-10 rounded-md object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate">{track.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] truncate">{track.artist}</p>
                </div>
                <Play className="w-4 h-4 text-[#B3B3B3]" />
              </button>
            ))}
          </div>
        </section>

        {/* Top nummers */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Topnummers van {friend.name}
          </h2>
          <div className="space-y-1.5">
            {topSongs.map((track, idx) => (
              <button
                key={track.id}
                type="button"
                onClick={() => playTrack(track.id, true)}
                className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#282828] text-left transition"
              >
                <span className="w-5 text-center text-xs font-bold text-[#B3B3B3]">
                  {idx + 1}
                </span>
                <img
                  src={track.albumArtwork}
                  alt={track.title}
                  className="w-10 h-10 rounded-md object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate">{track.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] truncate">
                    {track.artist} • {track.genre}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
