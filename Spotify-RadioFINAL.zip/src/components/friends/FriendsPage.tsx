import React, { useMemo, useState } from 'react';
import { Play, Plus, Radio, Sparkles, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  calculateFriendCompatibility,
  computeSocialInsights,
} from '../../engine/recommendationEngine';
import { FRIEND_BY_ID } from '../../data/mockData';
import { FriendCard } from './FriendCard';
import { GroupCard } from '../groups/GroupCard';
import { GroupEditModal } from '../groups/GroupEditModal';
import { cn } from '../../utils/cn';

export const FriendsPage: React.FC = () => {
  const {
    currentUser,
    friends,
    groups,
    navigate,
    createAndStartRadio,
    playTrack,
  } = useApp();

  const [showAllFriends, setShowAllFriends] = useState(false);
  const [createGroupOpen, setCreateGroupOpen] = useState(false);

  const insights = useMemo(() => computeSocialInsights(friends, groups), [friends, groups]);

  const displayedFriends = showAllFriends ? friends : friends.slice(0, 10);

  return (
    <div className="min-h-full bg-gradient-to-b from-[#162C1E] via-[#121212] via-20% to-[#121212] px-4 pt-5 pb-6 space-y-6">
      {/* Page Header */}
      <header className="space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">Vrienden</h1>
            <p className="text-xs text-[#D1D5DB] mt-0.5">
              Ontdek muziek via de mensen om je heen.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
            className="shrink-0 px-3.5 py-2 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-95 text-black text-xs font-extrabold inline-flex items-center gap-1.5 shadow transition"
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Nieuwe radio</span>
          </button>
        </div>

        {/* Subtiele demo-status strip */}
        <div className="flex items-center justify-between gap-2 rounded-xl bg-white/[0.06] border border-white/10 px-3 py-2 text-[11px] text-[#B3B3B3]">
          <span className="truncate">
            <strong className="text-white">{friends.filter((f) => f.isOnline).length} vrienden</strong> online • {groups.length} groepen actief
          </span>
          <button
            type="button"
            onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
            className="text-[#1ED760] font-bold shrink-0 hover:underline"
          >
            Selecteer meerdere
          </button>
        </div>
      </header>

      {/* B. JOUW GROEPEN (prominent zodat FC Zaterdag 3 direct vindbaar is, gevolgd door A & C) */}
      <section aria-labelledby="groups-heading" className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 id="groups-heading" className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Jouw groepen
          </h2>
          <button
            type="button"
            onClick={() => setCreateGroupOpen(true)}
            className="text-xs font-bold text-[#1ED760] inline-flex items-center gap-1 hover:underline"
          >
            <Plus className="w-3.5 h-3.5" />
            Groep maken
          </button>
        </div>

        <div className="space-y-3">
          {groups.map((group) => {
            const members = group.memberIds
              .map((id) => FRIEND_BY_ID[id])
              .filter((f): f is NonNullable<typeof f> => Boolean(f));
            return (
              <GroupCard
                key={group.id}
                group={group}
                members={members}
                onOpenGroup={() => navigate({ name: 'group-profile', groupId: group.id })}
                onStartGroupRadio={() =>
                  createAndStartRadio({
                    title: `${group.name} Radio`,
                    sourceType: 'group',
                    sourceGroupId: group.id,
                    memberIds: group.memberIds,
                    vibe: group.defaultVibe,
                    discoveryLevel: group.defaultDiscovery,
                    equalInfluence: group.equalInfluence,
                    coverArtwork: group.coverArtwork,
                  })
                }
              />
            );
          })}
        </div>
      </section>

      {/* C. ONTDEK VIA VRIENDEN */}
      <section aria-labelledby="discover-friends-heading" className="space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#1ED760]" />
          <h2 id="discover-friends-heading" className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Ontdek via vrienden
          </h2>
        </div>

        <div className="space-y-2.5">
          {insights.map((insight) => {
            const avatars = insight.friendIds
              .map((id) => FRIEND_BY_ID[id])
              .filter(Boolean);
            return (
              <div
                key={insight.id}
                className="rounded-2xl bg-[#181818] border border-white/5 p-3 flex items-center gap-3"
              >
                <button
                  type="button"
                  onClick={() => playTrack(insight.track.id, true)}
                  className="relative w-14 h-14 rounded-xl overflow-hidden shrink-0 group"
                  aria-label={`Speel ${insight.track.title}`}
                >
                  <img
                    src={insight.track.albumArtwork}
                    alt={insight.track.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/35 flex items-center justify-center opacity-90 group-hover:opacity-100 transition">
                    <Play className="w-5 h-5 fill-white text-white ml-0.5" />
                  </div>
                </button>

                <div className="min-w-0 flex-1">
                  <span className="inline-block text-[10px] font-bold text-[#1ED760] uppercase tracking-wider">
                    {insight.badge}
                  </span>
                  <p className="text-xs font-extrabold text-white leading-snug">
                    {insight.headline}
                  </p>
                  <p className="text-[11px] text-[#D1D5DB] truncate mt-0.5">
                    {insight.track.title} — {insight.track.artist}
                  </p>
                  <div className="flex items-center gap-1.5 mt-1">
                    <div className="flex -space-x-1.5">
                      {avatars.map((av) => (
                        <img
                          key={av.id}
                          src={av.avatar}
                          alt={av.name}
                          className="w-4 h-4 rounded-full ring-1 ring-[#181818] object-cover"
                        />
                      ))}
                    </div>
                    <span className="text-[10px] text-[#B3B3B3] truncate">{insight.subtext}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* A. JOUW VRIENDEN */}
      <section aria-labelledby="your-friends-heading" className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-[#1ED760]" />
            <h2 id="your-friends-heading" className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Jouw vrienden ({friends.length})
            </h2>
          </div>
          <button
            type="button"
            onClick={() => setShowAllFriends((s) => !s)}
            className="text-xs font-bold text-[#B3B3B3] hover:text-white"
          >
            {showAllFriends ? 'Toon minder' : `Toon alle ${friends.length}`}
          </button>
        </div>

        <div className={cn('space-y-2.5')}>
          {displayedFriends.map((friend) => {
            const compat = calculateFriendCompatibility(currentUser, friend);
            return (
              <FriendCard
                key={friend.id}
                friend={friend}
                compatibilityScore={compat.score}
                onOpenProfile={() => navigate({ name: 'friend-profile', friendId: friend.id })}
                onStartRadio={() =>
                  createAndStartRadio({
                    title: `Radio met ${friend.name}`,
                    sourceType: 'friend',
                    memberIds: [friend.id],
                    vibe: 'gewoon-gezellig',
                    discoveryLevel: 45,
                    equalInfluence: true,
                  })
                }
              />
            );
          })}
        </div>
      </section>

      <GroupEditModal open={createGroupOpen} onClose={() => setCreateGroupOpen(false)} />
    </div>
  );
};
