import React from 'react';
import { ChevronRight, Radio } from 'lucide-react';
import { Friend, Group } from '../../types/music';
import { getVibePreset } from '../../engine/recommendationEngine';

interface GroupCardProps {
  group: Group;
  members: Friend[];
  onOpenGroup: () => void;
  onStartGroupRadio: () => void;
}

export const GroupCard: React.FC<GroupCardProps> = ({
  group,
  members,
  onOpenGroup,
  onStartGroupRadio,
}) => {
  const vibe = getVibePreset(group.defaultVibe);

  return (
    <div className="rounded-2xl bg-[#181818] hover:bg-[#222222] border border-white/10 p-3.5 space-y-3 transition">
      <button
        type="button"
        onClick={onOpenGroup}
        className="w-full flex items-center gap-3.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1ED760] rounded-xl"
      >
        <img
          src={group.coverArtwork}
          alt={group.name}
          className="w-16 h-16 rounded-xl object-cover shrink-0 shadow-md"
        />

        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-base font-extrabold text-white truncate">{group.name}</h3>
            <ChevronRight className="w-4 h-4 text-[#B3B3B3] shrink-0" />
          </div>
          <p className="text-xs font-semibold text-[#1ED760] mt-0.5">
            {group.memberIds.length} leden • {vibe.label}
          </p>

          {/* Overlappende profielfoto's */}
          <div className="flex items-center gap-2 mt-2">
            <div className="flex -space-x-2">
              {members.slice(0, 6).map((m) => (
                <img
                  key={m.id}
                  src={m.avatar}
                  alt={m.name}
                  className="w-6 h-6 rounded-full ring-2 ring-[#181818] object-cover"
                />
              ))}
            </div>
            {members.length > 6 && (
              <span className="text-[10px] font-bold text-[#B3B3B3]">
                +{members.length - 6} anderen
              </span>
            )}
          </div>
        </div>
      </button>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onStartGroupRadio}
          className="flex-1 py-2.5 px-4 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-[0.98] text-black text-xs font-extrabold inline-flex items-center justify-center gap-1.5 transition"
        >
          <Radio className="w-3.5 h-3.5" />
          Start groepsradio
        </button>
        <button
          type="button"
          onClick={onOpenGroup}
          className="py-2.5 px-4 rounded-full bg-[#282828] hover:bg-[#333333] text-white text-xs font-bold transition"
        >
          Bekijk groep
        </button>
      </div>
    </div>
  );
};
