import React, { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { VIBE_PRESETS } from '../../data/mockData';
import { Group, GroupCoverTheme, VibeId } from '../../types/music';
import { BottomSheet } from '../ui/BottomSheet';
import { cn } from '../../utils/cn';

interface GroupEditModalProps {
  open: boolean;
  onClose: () => void;
  existingGroup?: Group;
}

const COVER_THEMES: { id: GroupCoverTheme; label: string; color: string }[] = [
  { id: 'football', label: 'Sport & Veld', color: '#1ED760' },
  { id: 'friends', label: 'Zonsondergang', color: '#F97316' },
  { id: 'housemates', label: 'Oceaan', color: '#06B6D4' },
  { id: 'festival', label: 'Festival', color: '#EC4899' },
  { id: 'night', label: 'Nachtclub', color: '#8B5CF6' },
];

export const GroupEditModal: React.FC<GroupEditModalProps> = ({
  open,
  onClose,
  existingGroup,
}) => {
  const { friends, createGroup, updateGroup } = useApp();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [memberIds, setMemberIds] = useState<string[]>([]);
  const [coverTheme, setCoverTheme] = useState<GroupCoverTheme>('friends');
  const [defaultVibe, setDefaultVibe] = useState<VibeId>('gewoon-gezellig');

  useEffect(() => {
    if (!open) return;
    if (existingGroup) {
      setName(existingGroup.name);
      setDescription(existingGroup.description);
      setMemberIds(existingGroup.memberIds);
      setCoverTheme(existingGroup.coverTheme);
      setDefaultVibe(existingGroup.defaultVibe);
    } else {
      setName('');
      setDescription('');
      setMemberIds(['f-milan', 'f-thomas', 'f-lisa']);
      setCoverTheme('friends');
      setDefaultVibe('gewoon-gezellig');
    }
  }, [existingGroup, open]);

  const toggleMember = (id: string) => {
    setMemberIds((prev) =>
      prev.includes(id) ? prev.filter((m) => m !== id) : [...prev, id]
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim() || 'Nieuwe vriendengroep';
    const cleanMembers = memberIds.length > 0 ? memberIds : ['f-milan'];

    if (existingGroup) {
      updateGroup(existingGroup.id, {
        name: cleanName,
        description: description.trim(),
        memberIds: cleanMembers,
        coverTheme,
        defaultVibe,
      });
    } else {
      createGroup({
        name: cleanName,
        description: description.trim() || `${cleanMembers.length} vrienden`,
        memberIds: cleanMembers,
        coverTheme,
        defaultVibe,
      });
    }
    onClose();
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={existingGroup ? `Pas ${existingGroup.name} aan` : 'Nieuwe groep aanmaken'}
      subtitle="Wijzigingen worden lokaal opgeslagen"
    >
      <form onSubmit={handleSave} className="space-y-4 pb-2">
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#B3B3B3]">Groepsnaam</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Bijv. Zaalvoetbal Vrijdag"
            className="w-full rounded-xl bg-[#282828] border border-white/10 px-3.5 py-2.5 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#1ED760]"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#B3B3B3]">Beschrijving</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Waarvoor gebruiken jullie deze groepsradio?"
            className="w-full rounded-xl bg-[#282828] border border-white/10 px-3.5 py-2.5 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#1ED760]"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#B3B3B3]">Groepsafbeelding / stijl</label>
          <div className="flex flex-wrap gap-2">
            {COVER_THEMES.map((theme) => (
              <button
                key={theme.id}
                type="button"
                onClick={() => setCoverTheme(theme.id)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-bold inline-flex items-center gap-1.5 border transition',
                  coverTheme === theme.id
                    ? 'bg-white text-black border-white'
                    : 'bg-[#282828] text-white border-white/10'
                )}
              >
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: theme.color }}
                />
                {theme.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#B3B3B3]">Standaard radiosfeer</label>
          <div className="grid grid-cols-2 gap-2">
            {VIBE_PRESETS.map((vibe) => (
              <button
                key={vibe.id}
                type="button"
                onClick={() => setDefaultVibe(vibe.id)}
                className={cn(
                  'px-3 py-2 rounded-xl text-xs font-bold text-left border transition',
                  defaultVibe === vibe.id
                    ? 'bg-[#1ED760]/20 border-[#1ED760] text-[#1ED760]'
                    : 'bg-[#282828] border-white/5 text-white'
                )}
              >
                {vibe.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#B3B3B3]">
            Leden ({memberIds.length} geselecteerd)
          </label>
          <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
            {friends.map((f) => {
              const selected = memberIds.includes(f.id);
              return (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => toggleMember(f.id)}
                  className={cn(
                    'flex items-center justify-between gap-2 p-2 rounded-xl border text-left transition',
                    selected
                      ? 'bg-[#1ED760]/15 border-[#1ED760]/60'
                      : 'bg-[#282828] border-white/5 opacity-80'
                  )}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <img
                      src={f.avatar}
                      alt={f.name}
                      className="w-7 h-7 rounded-full object-cover shrink-0"
                    />
                    <span className="text-xs font-bold text-white truncate">{f.name}</span>
                  </div>
                  {selected && <Check className="w-3.5 h-3.5 text-[#1ED760] shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-3 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] text-black font-extrabold text-sm transition"
        >
          {existingGroup ? 'Wijzigingen opslaan' : 'Groep aanmaken'}
        </button>
      </form>
    </BottomSheet>
  );
};
