import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Copy,
  Edit3,
  Play,
  Radio,
  Sparkles,
  Users,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { FRIEND_BY_ID } from '../../data/mockData';
import { computeGroupAnalytics, getVibePreset } from '../../engine/recommendationEngine';
import { GroupEditModal } from './GroupEditModal';

interface GroupProfileProps {
  groupId: string;
}

export const GroupProfile: React.FC<GroupProfileProps> = ({ groupId }) => {
  const { groups, goBack, navigate, createAndStartRadio, playTrack, showToast } = useApp();
  const [editOpen, setEditOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showAllMembers, setShowAllMembers] = useState(false);

  const group = groups.find((g) => g.id === groupId) ?? groups[0];

  const members = useMemo(
    () =>
      group.memberIds
        .map((id) => FRIEND_BY_ID[id])
        .filter((f): f is NonNullable<typeof f> => Boolean(f)),
    [group.memberIds]
  );

  const analytics = useMemo(() => computeGroupAnalytics(group, members), [group, members]);
  const vibe = getVibePreset(group.defaultVibe);

  const handleCopyInvite = () => {
    navigator.clipboard?.writeText(group.inviteCode).catch(() => {});
    setCopied(true);
    showToast(`Uitnodigingscode ${group.inviteCode} gekopieerd`);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-full bg-gradient-to-b from-[#173322] via-[#121212] via-35% to-[#121212] pb-8">
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-3 bg-[#121212]/60 backdrop-blur-md">
        <button
          type="button"
          onClick={goBack}
          aria-label="Terug"
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold text-white/80">Groepsprofiel</span>
        <button
          type="button"
          onClick={() => setEditOpen(true)}
          aria-label="Pas groep aan"
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white"
        >
          <Edit3 className="w-4 h-4" />
        </button>
      </div>

      <div className="px-4 pt-2 space-y-6">
        {/* Hero */}
        <div className="flex flex-col items-center text-center space-y-3">
          <img
            src={group.coverArtwork}
            alt={group.name}
            className="w-40 h-40 rounded-2xl object-cover shadow-2xl border border-white/10"
          />

          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">{group.name}</h1>
            <p className="text-xs font-bold text-[#1ED760] mt-0.5">
              {group.memberIds.length} leden • Voorkeurssfeer: {vibe.label}
            </p>
            <p className="text-xs text-[#B3B3B3] mt-1 max-w-xs mx-auto">{group.description}</p>
          </div>

          {/* Overlappende avatars */}
          <div className="flex items-center justify-center -space-x-2.5 pt-1">
            {members.slice(0, 8).map((m) => (
              <img
                key={m.id}
                src={m.avatar}
                alt={m.name}
                className="w-8 h-8 rounded-full ring-2 ring-[#121212] object-cover"
              />
            ))}
            {members.length > 8 && (
              <span className="w-8 h-8 rounded-full bg-[#282828] ring-2 ring-[#121212] text-[10px] font-bold flex items-center justify-center text-white">
                +{members.length - 8}
              </span>
            )}
          </div>

          {/* Actieknoppen */}
          <div className="w-full space-y-2.5 pt-1">
            <button
              type="button"
              onClick={() =>
                createAndStartRadio({
                  title: `${group.name} Radio`,
                  sourceType: 'group',
                  sourceGroupId: group.id,
                  memberIds: group.memberIds,
                  vibe: group.defaultVibe,
                  discoveryLevel: group.defaultDiscovery,
                  equalInfluence: group.equalInfluence,
                  coverArtwork: group.coverArtwork,
                })
              }
              className="w-full py-3.5 px-5 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-[0.98] text-black font-extrabold text-sm inline-flex items-center justify-center gap-2 shadow-lg transition"
            >
              <Radio className="w-4 h-4" />
              Start groepsradio
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() =>
                  navigate({
                    name: 'radio-builder',
                    preselectedGroupId: group.id,
                    initialStep: 2,
                  })
                }
                className="py-2.5 px-3 rounded-full bg-[#282828] hover:bg-[#333333] text-white font-bold text-xs transition"
              >
                Kies andere sfeer
              </button>
              <button
                type="button"
                onClick={() => setEditOpen(true)}
                className="py-2.5 px-3 rounded-full bg-[#282828] hover:bg-[#333333] text-white font-bold text-xs transition"
              >
                Pas groep aan
              </button>
            </div>
          </div>

          {/* Deelbare uitnodigingscode */}
          <div className="w-full rounded-2xl bg-[#181818] border border-white/10 p-3 flex items-center justify-between gap-2">
            <div className="text-left min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-[#B3B3B3]">
                Deelbare groepscode (demo)
              </p>
              <p className="text-xs font-extrabold text-white tracking-wide truncate">
                {group.inviteCode}
              </p>
            </div>
            <button
              type="button"
              onClick={handleCopyInvite}
              className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-bold text-white inline-flex items-center gap-1.5 shrink-0 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#1ED760]" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Gekopieerd' : 'Kopieer'}
            </button>
          </div>
        </div>

        {/* Groepsleden */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3] inline-flex items-center gap-1.5">
              <Users className="w-4 h-4 text-[#1ED760]" />
              Groepsleden ({members.length})
            </h2>
            {members.length > 6 && (
              <button
                type="button"
                onClick={() => setShowAllMembers((v) => !v)}
                className="text-xs font-bold text-[#1ED760]"
              >
                {showAllMembers ? 'Minder tonen' : `Alle ${members.length} tonen`}
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(showAllMembers ? members : members.slice(0, 6)).map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => navigate({ name: 'friend-profile', friendId: m.id })}
                className="flex items-center gap-2.5 p-2 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
              >
                <img
                  src={m.avatar}
                  alt={m.name}
                  className="w-9 h-9 rounded-full object-cover shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">{m.name}</p>
                  <p className="text-[10px] text-[#B3B3B3] truncate">{m.favoriteGenres[0]}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Meest beluisterde genres */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Meest beluisterde genres
          </h2>
          <div className="space-y-2 rounded-2xl bg-[#181818] p-3.5 border border-white/5">
            {analytics.topGenres.map((item) => (
              <div key={item.genre} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-white">{item.genre}</span>
                  <span className="text-[#B3B3B3]">
                    {item.count} leden ({item.percentage}%)
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#1ED760]"
                    style={{ width: `${Math.min(100, item.percentage)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Jullie favoriete artiesten */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Jullie favoriete artiesten
          </h2>
          <div className="flex flex-wrap gap-2">
            {analytics.topArtists.map((a) => (
              <span
                key={a.artist}
                className="px-3 py-1.5 rounded-full bg-[#282828] text-xs font-bold text-white"
              >
                {a.artist}{' '}
                <span className="text-[#1ED760] ml-1">({a.count})</span>
              </span>
            ))}
          </div>
        </section>

        {/* Gedeelde favorieten */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Gedeelde favorieten
          </h2>
          <div className="space-y-1.5">
            {analytics.sharedFavorites.map(({ track, count }) => (
              <button
                key={track.id}
                type="button"
                onClick={() => playTrack(track.id, true)}
                className="w-full flex items-center gap-3 p-2 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
              >
                <img
                  src={track.albumArtwork}
                  alt={track.title}
                  className="w-11 h-11 rounded-md object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate">{track.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] truncate">{track.artist}</p>
                </div>
                <span className="text-[10px] font-bold text-[#1ED760] shrink-0">
                  {count}x geliket
                </span>
              </button>
            ))}
          </div>
        </section>

        {/* Nieuwe ontdekkingen */}
        <section className="space-y-2.5">
          <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#B3B3B3] inline-flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#1ED760]" />
            Nieuwe ontdekkingen voor deze groep
          </h2>
          <div className="space-y-1.5">
            {analytics.discoveries.map((rec) => (
              <button
                key={rec.track.id}
                type="button"
                onClick={() => playTrack(rec.track.id, true)}
                className="w-full flex items-center gap-3 p-2 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
              >
                <img
                  src={rec.track.albumArtwork}
                  alt={rec.track.title}
                  className="w-11 h-11 rounded-md object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate">{rec.track.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] truncate">{rec.primaryReason}</p>
                </div>
                <Play className="w-4 h-4 text-[#1ED760] shrink-0" />
              </button>
            ))}
          </div>
        </section>
      </div>

      <GroupEditModal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        existingGroup={group}
      />
    </div>
  );
};
