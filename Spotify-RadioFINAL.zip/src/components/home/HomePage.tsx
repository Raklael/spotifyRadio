import React, { useMemo, useState } from 'react';
import { Play, Radio, ShieldCheck, Sparkles, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  HOME_PLAYLISTS,
  RECOMMENDED_ALBUMS,
  TRACKS,
  TRACK_BY_ID,
} from '../../data/mockData';
import { generateSpecialCover } from '../../utils/artwork';
import { cn } from '../../utils/cn';

type HomeFilter = 'Alles' | 'Muziek' | 'Podcasts';

export const HomePage: React.FC = () => {
  const {
    currentUser,
    friends,
    groups,
    sessions,
    likedTrackIds,
    navigate,
    switchTab,
    playTrack,
    createAndStartRadio,
    setPrivacyModalOpen,
    privacy,
  } = useApp();

  const [filter, setFilter] = useState<HomeFilter>('Alles');

  const fcGroup = groups.find((g) => g.id === 'g-fc-zaterdag-3') ?? groups[0];
  const featuredFriends = useMemo(() => {
    const ids = ['f-milan', 'f-thomas', 'f-lisa', 'f-daan', 'f-bram', 'f-niels', 'f-julia'];
    return ids.map((id) => friends.find((f) => f.id === id)).filter((f): f is NonNullable<typeof f> => Boolean(f));
  }, [friends]);

  const likedCover = useMemo(() => generateSpecialCover('liked'), []);

  const recentGridItems = useMemo(() => {
    const base = [
      {
        id: 'liked',
        title: 'Nummers die je leuk vindt',
        artwork: likedCover,
        category: 'Muziek' as const,
        onClick: () => {
          navigate({ name: 'playlist-detail', playlistId: 'liked' });
        },
      },
      ...HOME_PLAYLISTS.map((p) => ({
        id: p.id,
        title: p.title,
        artwork: p.artwork,
        category: p.category === 'Podcasts' ? ('Podcasts' as const) : ('Muziek' as const),
        onClick: () => {
          navigate({ name: 'playlist-detail', playlistId: p.id });
        },
      })),
    ];

    if (filter === 'Alles') return base.slice(0, 6);
    if (filter === 'Podcasts') return base.filter((b) => b.category === 'Podcasts');
    return base.filter((b) => b.category === 'Muziek').slice(0, 6);
  }, [fcGroup, filter, likedCover, likedTrackIds, navigate, playTrack, sessions]);

  const mixes = useMemo(
    () => HOME_PLAYLISTS.filter((p) => p.category === 'Mix' || p.category === 'Muziek'),
    []
  );

  const discoveryCards = useMemo(
    () => TRACKS.filter((t) => t.discoveryScore >= 0.55).slice(0, 6),
    []
  );

  return (
    <div className="min-h-full bg-gradient-to-b from-[#1E3225] via-[#121212] via-25% to-[#121212] px-4 pt-4 pb-6 space-y-6">
      {/* Header met profielavatar & filter pills */}
      <header className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setPrivacyModalOpen(true)}
            aria-label="Profiel en privacy-instellingen"
            className="relative shrink-0 rounded-full ring-2 ring-white/15 hover:ring-[#1ED760] transition"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-8 h-8 rounded-full object-cover"
            />
          </button>

          {(['Alles', 'Muziek', 'Podcasts'] as HomeFilter[]).map((pill) => {
            const active = filter === pill;
            return (
              <button
                key={pill}
                type="button"
                onClick={() => setFilter(pill)}
                className={cn(
                  'px-3.5 py-1.5 rounded-full text-xs font-semibold transition shrink-0',
                  active
                    ? 'bg-[#1ED760] text-black'
                    : 'bg-[#282828] text-white hover:bg-[#333333]'
                )}
              >
                {pill}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => setPrivacyModalOpen(true)}
          aria-label="Privacy"
          title="Privacy-instellingen"
          className="shrink-0 w-8 h-8 rounded-full bg-white/10 hover:bg-white/15 flex items-center justify-center text-white/85"
        >
          <ShieldCheck
            className={cn(
              'w-4 h-4',
              privacy.shareTasteWithFriends ? 'text-[#1ED760]' : 'text-[#B3B3B3]'
            )}
          />
        </button>
      </header>

      {/* 2-koloms Recently Played Grid (zoals Spotify mobiel) */}
      <section aria-label="Recent afgespeeld">
        <div className="grid grid-cols-2 gap-2">
          {recentGridItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={item.onClick}
              className="flex items-center gap-2.5 bg-[#282828]/85 hover:bg-[#333333] active:scale-[0.98] rounded-md overflow-hidden transition text-left h-14 pr-2"
            >
              <img
                src={item.artwork}
                alt={item.title}
                className="w-14 h-14 object-cover shrink-0"
              />
              <span className="text-xs font-bold text-white line-clamp-2 leading-tight">
                {item.title}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* NIEUW ELEMENT: Luister samen met vrienden */}
      <section aria-labelledby="home-friends-heading" className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 id="home-friends-heading" className="text-lg font-extrabold tracking-tight">
              Luister samen met vrienden
            </h2>
            <p className="text-xs text-[#B3B3B3]">
              Tik op een vriend of team om een radio te starten
            </p>
          </div>
          <button
            type="button"
            onClick={() => switchTab('friends')}
            className="text-xs font-bold text-[#B3B3B3] hover:text-white shrink-0"
          >
            Alles zien
          </button>
        </div>

        <div className="flex gap-3.5 overflow-x-auto no-scrollbar pb-1 -mx-4 px-4">
          {fcGroup && (
            <button
              type="button"
              onClick={() => navigate({ name: 'group-profile', groupId: fcGroup.id })}
              className="flex flex-col items-center gap-1.5 shrink-0 w-[72px] group"
            >
              <div className="relative p-[2.5px] rounded-full bg-gradient-to-tr from-[#1ED760] to-[#3B82F6] group-active:scale-95 transition">
                <img
                  src={fcGroup.coverArtwork}
                  alt={fcGroup.name}
                  className="w-[62px] h-[62px] rounded-full object-cover border-2 border-[#121212]"
                />
                <span className="absolute -bottom-0.5 right-0 px-1.5 py-0.5 rounded-full bg-[#1ED760] text-black text-[9px] font-black ring-2 ring-[#121212]">
                  {fcGroup.memberIds.length}
                </span>
              </div>
              <span className="text-[11px] font-bold text-white truncate w-full text-center">
                Voetbalteam 3
              </span>
            </button>
          )}

          {featuredFriends.map((friend) => (
            <button
              key={friend.id}
              type="button"
              onClick={() => navigate({ name: 'friend-profile', friendId: friend.id })}
              className="flex flex-col items-center gap-1.5 shrink-0 w-[70px] group"
            >
              <div className="relative group-active:scale-95 transition">
                <div
                  className={cn(
                    'p-[2px] rounded-full',
                    friend.isOnline
                      ? 'bg-gradient-to-tr from-[#1ED760] to-[#10B981]'
                      : 'bg-white/15'
                  )}
                >
                  <img
                    src={friend.avatar}
                    alt={friend.name}
                    className="w-[62px] h-[62px] rounded-full object-cover border-2 border-[#121212]"
                  />
                </div>
                {friend.isOnline && (
                  <span
                    className="absolute bottom-0.5 right-0.5 w-3.5 h-3.5 rounded-full bg-[#1ED760] ring-2 ring-[#121212]"
                    title="Online"
                  />
                )}
              </div>
              <span className="text-[11px] font-semibold text-white truncate w-full text-center">
                {friend.name}
              </span>
            </button>
          ))}
        </div>
      </section>


      <section aria-label="Maak een Radio met je vrienden">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#1ED760]/20 via-[#1E2E24] to-[#181818] border border-[#1ED760]/35 p-4 shadow-lg">
          <div className="flex items-start justify-between gap-3">
            <div className="space-y-1.5 flex-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#1ED760]/20 text-[#1ED760] text-[10px] font-extrabold uppercase tracking-wider">
                <Radio className="w-3 h-3" />
                Nieuw • Friends Radio
              </div>
              <h2 className="text-[19px] font-extrabold text-white leading-tight">
                Maak een Radio met je vrienden
              </h2>
              <p className="text-xs text-[#D1D5DB] leading-relaxed">
                Mix jullie muzieksmaken en ontdek samen iets nieuws.
              </p>
            </div>

            <div className="flex -space-x-2.5 shrink-0 pt-1">
              {featuredFriends.slice(0, 3).map((f) => (
                <img
                  key={f.id}
                  src={f.avatar}
                  alt={f.name}
                  className="w-9 h-9 rounded-full ring-2 ring-[#181818] object-cover"
                />
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
              className="flex-1 py-2.5 px-4 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-[0.98] text-black font-extrabold text-xs inline-flex items-center justify-center gap-2 transition shadow-md"
            >
              <Users className="w-4 h-4" />
              Maak vriendenradio
            </button>
            {fcGroup && (
              <button
                type="button"
                onClick={() =>
                  createAndStartRadio({
                    title: `${fcGroup.name} Radio`,
                    sourceType: 'group',
                    sourceGroupId: fcGroup.id,
                    memberIds: fcGroup.memberIds,
                    vibe: fcGroup.defaultVibe,
                    discoveryLevel: fcGroup.defaultDiscovery,
                    equalInfluence: fcGroup.equalInfluence,
                    coverArtwork: fcGroup.coverArtwork,
                  })
                }
                className="py-2.5 px-3.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-bold text-xs shrink-0 transition"
              >
                Teamradio
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Podcasts view indien filter actief */}
      {filter === 'Podcasts' ? (
        <section className="space-y-3">
          <h2 className="text-lg font-extrabold tracking-tight">Podcasts voor jou</h2>
          <div className="space-y-2.5">
            {HOME_PLAYLISTS.filter((p) => p.category === 'Podcasts').map((pod) => (
              <button
                key={pod.id}
                type="button"
                onClick={() => navigate({ name: 'playlist-detail', playlistId: pod.id })}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
              >
                <img
                  src={pod.artwork}
                  alt={pod.title}
                  className="w-16 h-16 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-white truncate">{pod.title}</p>
                  <p className="text-xs text-[#B3B3B3] mt-0.5">{pod.subtitle}</p>
                </div>
                <span className="w-9 h-9 rounded-full bg-[#1ED760] text-black flex items-center justify-center shrink-0">
                  <Play className="w-4 h-4 fill-black ml-0.5" />
                </span>
              </button>
            ))}
          </div>
        </section>
      ) : (
        <>
          {/* Jouw topmixen */}
          <section className="space-y-3">
            <h2 className="text-lg font-extrabold tracking-tight">Jouw topmixen</h2>
            <div className="flex gap-3.5 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
              {mixes.map((mix) => (
                <button
                  key={mix.id}
                  type="button"
                  onClick={() => navigate({ name: 'playlist-detail', playlistId: mix.id })}
                  className="w-36 shrink-0 text-left group"
                >
                  <div className="relative rounded-lg overflow-hidden aspect-square bg-[#282828] mb-2">
                    <img
                      src={mix.artwork}
                      alt={mix.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    {mix.badge && (
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-[#1ED760] text-black text-[9px] font-extrabold">
                        {mix.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-bold text-white truncate">{mix.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] line-clamp-2 mt-0.5">{mix.subtitle}</p>
                </button>
              ))}
            </div>
          </section>

          {/* Radiosuggesties */}
          <section className="space-y-3">
            <h2 className="text-lg font-extrabold tracking-tight">Radiosuggesties</h2>
            <div className="flex gap-3.5 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
              {featuredFriends.slice(0, 4).map((friend) => (
                <button
                  key={friend.id}
                  type="button"
                  onClick={() =>
                    createAndStartRadio({
                      title: `Radio met ${friend.name}`,
                      sourceType: 'friend',
                      memberIds: [friend.id],
                      vibe: 'gewoon-gezellig',
                      discoveryLevel: 45,
                      equalInfluence: true,
                    })
                  }
                  className="w-36 shrink-0 text-left bg-[#181818] hover:bg-[#282828] rounded-xl p-2.5 transition border border-white/5"
                >
                  <div className="relative aspect-square rounded-lg overflow-hidden mb-2 bg-[#282828]">
                    <img
                      src={
                        TRACK_BY_ID[friend.likedTracks[0]]?.albumArtwork ?? TRACKS[0].albumArtwork
                      }
                      alt={friend.name}
                      className="w-full h-full object-cover opacity-85"
                    />
                    <img
                      src={friend.avatar}
                      alt={friend.name}
                      className="w-11 h-11 rounded-full ring-2 ring-[#1ED760] object-cover absolute bottom-2 right-2 shadow-lg"
                    />
                  </div>
                  <p className="text-xs font-bold text-white truncate">Radio met {friend.name}</p>
                  <p className="text-[11px] text-[#B3B3B3] truncate mt-0.5">
                    {friend.favoriteGenres.slice(0, 2).join(' • ')}
                  </p>
                </button>
              ))}
            </div>
          </section>

          {/* Aanbevolen albums */}
          <section className="space-y-3">
            <h2 className="text-lg font-extrabold tracking-tight">Aanbevolen albums</h2>
            <div className="flex gap-3.5 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
              {RECOMMENDED_ALBUMS.map((album) => (
                <button
                  key={album.id}
                  type="button"
                  onClick={() => navigate({ name: 'playlist-detail', playlistId: album.id })}
                  className="w-36 shrink-0 text-left group"
                >
                  <div className="rounded-lg overflow-hidden aspect-square bg-[#282828] mb-2">
                    <img
                      src={album.artwork}
                      alt={album.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  </div>
                  <p className="text-xs font-bold text-white truncate">{album.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] truncate mt-0.5">{album.artist}</p>
                </button>
              ))}
            </div>
          </section>

          {/* Ontdek nieuwe muziek */}
          <section className="space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#1ED760]" />
              <h2 className="text-lg font-extrabold tracking-tight">Ontdek nieuwe muziek</h2>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {discoveryCards.slice(0, 4).map((track) => (
                <button
                  key={track.id}
                  type="button"
                  onClick={() => playTrack(track.id, true)}
                  className="flex items-center gap-2.5 p-2 rounded-xl bg-[#181818] hover:bg-[#282828] border border-white/5 text-left transition"
                >
                  <img
                    src={track.albumArtwork}
                    alt={track.title}
                    className="w-12 h-12 rounded-md object-cover shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">{track.title}</p>
                    <p className="text-[10px] text-[#B3B3B3] truncate">{track.artist}</p>
                    <span className="inline-block text-[9px] font-semibold text-[#1ED760] mt-0.5">
                      {track.genre}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
};
