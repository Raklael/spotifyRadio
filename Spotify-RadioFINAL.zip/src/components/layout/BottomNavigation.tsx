import React from 'react';
import { Home, Search, Users, Library } from 'lucide-react';
import { ActiveTab } from '../../types/music';
import { useApp } from '../../context/AppContext';
import { cn } from '../../utils/cn';

export const BottomNavigation: React.FC = () => {
  const { activeTab, switchTab, route, activeSession } = useApp();

  const items: { id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'search', label: 'Zoeken', icon: Search },
    { id: 'friends', label: 'Vrienden', icon: Users },
    { id: 'library', label: 'Bibliotheek', icon: Library },
  ];

  return (
    <nav
      aria-label="Hoofdnavigatie"
      className="bg-gradient-to-t from-black via-black/95 to-black/85 backdrop-blur-md border-t border-white/5 px-2 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))]"
    >
      <div className="grid grid-cols-4 items-center">
        {items.map((item) => {
          const Icon = item.icon;
          const isCurrentTab = route.name === 'tab' && activeTab === item.id;
          const isFriendsTab = item.id === 'friends';

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => switchTab(item.id)}
              className={cn(
                'relative flex flex-col items-center justify-center gap-1 py-1.5 rounded-xl transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1ED760]',
                isCurrentTab ? 'text-white' : 'text-[#B3B3B3] hover:text-white'
              )}
              aria-current={isCurrentTab ? 'page' : undefined}
            >
              <div className="relative">
                <Icon
                  className={cn(
                    'transition-transform duration-150',
                    isFriendsTab ? 'w-[24px] h-[24px]' : 'w-[22px] h-[22px]',
                    isCurrentTab && 'scale-105 text-white',
                    isFriendsTab && isCurrentTab && 'text-[#1ED760]'
                  )}
                />
                {isFriendsTab && (
                  <span
                    className={cn(
                      'absolute -top-0.5 -right-1.5 w-2 h-2 rounded-full bg-[#1ED760] ring-2 ring-black',
                      activeSession ? 'animate-pulse' : ''
                    )}
                    title="Vrienden actief"
                  />
                )}
              </div>
              <span
                className={cn(
                  'text-[10px] tracking-tight leading-none',
                  isCurrentTab ? 'font-bold text-white' : 'font-medium'
                )}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
