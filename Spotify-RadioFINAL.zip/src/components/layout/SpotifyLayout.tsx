import React, { useState } from 'react';
import {
  Home,
  Library,
  Monitor,
  Radio,
  Search,
  ShieldCheck,
  Smartphone,
  Users,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import { BottomNavigation } from './BottomNavigation';
import { MiniPlayer } from '../player/MiniPlayer';
import { cn } from '../../utils/cn';

interface SpotifyLayoutProps {
  children: React.ReactNode;
}

export const SpotifyLayout: React.FC<SpotifyLayoutProps> = ({ children }) => {
  const {
    activeTab,
    route,
    switchTab,
    navigate,
    activeSession,
    openOnboarding,
    setPrivacyModalOpen,
    toastMessage,
  } = useApp();

  const [desktopWideMode, setDesktopWideMode] = useState(false);

  return (
    <div className="min-h-[100dvh] w-full bg-[#090909] text-white flex flex-col items-center">
      {/* Desktop View Switcher (zichtbaar op md+ schermen zodat mobiele iPhone-ervaring direct inspecteerbaar is) */}
      <div className="hidden md:flex w-full max-w-6xl items-center justify-between px-6 py-2.5 text-xs text-[#B3B3B3]">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#1ED760] text-black font-black text-[11px]">
            S
          </span>
          <span className="font-bold text-white">Spotify Friends Radio</span>
          <span className="text-white/30">•</span>
          <span>Educatief UX-prototype</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={openOnboarding}
            className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/90 font-medium transition"
          >
            Uitleg & Intro
          </button>
          <button
            type="button"
            onClick={() => setPrivacyModalOpen(true)}
            className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/90 font-medium inline-flex items-center gap-1.5 transition"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#1ED760]" />
            Privacy
          </button>
          <div className="flex items-center bg-[#181818] rounded-full p-0.5 border border-white/10">
            <button
              type="button"
              onClick={() => setDesktopWideMode(false)}
              className={cn(
                'px-3 py-1 rounded-full font-semibold inline-flex items-center gap-1.5 transition',
                !desktopWideMode ? 'bg-[#1ED760] text-black' : 'text-[#B3B3B3] hover:text-white'
              )}
            >
              <Smartphone className="w-3.5 h-3.5" />
              Mobiel (412px)
            </button>
            <button
              type="button"
              onClick={() => setDesktopWideMode(true)}
              className={cn(
                'px-3 py-1 rounded-full font-semibold inline-flex items-center gap-1.5 transition',
                desktopWideMode ? 'bg-[#1ED760] text-black' : 'text-[#B3B3B3] hover:text-white'
              )}
            >
              <Monitor className="w-3.5 h-3.5" />
              Desktop
            </button>
          </div>
        </div>
      </div>

      {/* Main App Shell */}
      <div
        className={cn(
          'w-full flex-1 flex relative bg-[#121212] overflow-hidden',
          desktopWideMode
            ? 'max-w-6xl md:my-2 md:rounded-3xl md:border md:border-white/10 md:h-[calc(100dvh-64px)] md:flex-none shadow-2xl'
            : 'max-w-[430px] md:my-2 md:rounded-[34px] md:border-[3px] md:border-[#2A2A2A] md:h-[calc(100dvh-64px)] md:max-h-[880px] md:flex-none shadow-[0_24px_80px_rgba(0,0,0,0.85)]'
        )}
      >
        {/* Desktop Sidebar (alleen zichtbaar in brede desktopmodus) */}
        {desktopWideMode && (
          <aside className="hidden md:flex flex-col w-60 bg-black border-r border-white/10 p-4 shrink-0 justify-between">
            <div className="space-y-6">
              <div className="flex items-center gap-2.5 px-2">
                <div className="w-8 h-8 rounded-full bg-[#1ED760] flex items-center justify-center text-black font-black">
                  <Radio className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-extrabold leading-tight">Spotify</p>
                  <p className="text-[11px] font-semibold text-[#1ED760] leading-tight">
                    Friends Radio
                  </p>
                </div>
              </div>

              <nav className="space-y-1">
                {[
                  { id: 'home' as const, label: 'Home', icon: Home },
                  { id: 'search' as const, label: 'Zoeken', icon: Search },
                  { id: 'friends' as const, label: 'Vrienden', icon: Users },
                  { id: 'library' as const, label: 'Bibliotheek', icon: Library },
                ].map((item) => {
                  const Icon = item.icon;
                  const active = route.name === 'tab' && activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => switchTab(item.id)}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition',
                        active
                          ? 'bg-[#282828] text-white'
                          : 'text-[#B3B3B3] hover:text-white hover:bg-white/5'
                      )}
                    >
                      <Icon className={cn('w-5 h-5', active && item.id === 'friends' && 'text-[#1ED760]')} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </nav>

              <div className="rounded-2xl bg-[#181818] p-3.5 border border-white/5 space-y-2.5">
                <p className="text-xs font-bold text-white">Maak een vriendenradio</p>
                <p className="text-[11px] text-[#B3B3B3] leading-relaxed">
                  Mix de muzieksmaak van je vrienden of team in één radio.
                </p>
                <button
                  type="button"
                  onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
                  className="w-full py-2 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] text-black font-bold text-xs transition"
                >
                  Maak vriendenradio
                </button>
              </div>
            </div>

            {activeSession && (
              <button
                type="button"
                onClick={() => navigate({ name: 'group-radio', sessionId: activeSession.id })}
                className="flex items-center gap-2.5 p-2.5 rounded-xl bg-[#181818] hover:bg-[#282828] text-left border border-white/5 transition"
              >
                <img
                  src={activeSession.coverArtwork}
                  alt={activeSession.title}
                  className="w-10 h-10 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">{activeSession.title}</p>
                  <p className="text-[10px] text-[#1ED760] truncate">Actieve radio</p>
                </div>
              </button>
            )}
          </aside>
        )}

        {/* Content Column */}
        <div className="flex-1 flex flex-col min-w-0 h-[100dvh] md:h-full relative">
          <main className="flex-1 overflow-y-auto pb-36 scroll-smooth">{children}</main>

          {/* Persistent Bottom Chrome */}
          <div className="absolute bottom-0 inset-x-0 z-30 pointer-events-none">
            <div className="pointer-events-auto">
              <MiniPlayer />
              {!desktopWideMode && <BottomNavigation />}
              {desktopWideMode && (
                <div className="md:hidden">
                  <BottomNavigation />
                </div>
              )}
            </div>
          </div>

          {/* Toast Feedback */}
          <AnimatePresence>
            {toastMessage && (
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 16 }}
                className="absolute bottom-32 left-4 right-4 z-40 flex justify-center pointer-events-none"
              >
                <div className="px-4 py-2.5 rounded-full bg-white text-black text-xs font-bold shadow-2xl">
                  {toastMessage}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
