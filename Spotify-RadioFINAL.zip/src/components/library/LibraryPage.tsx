import React, { useMemo, useState } from 'react';
import { Heart, Plus, Radio, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TRACK_BY_ID } from '../../data/mockData';
import { generateSpecialCover } from '../../utils/artwork';
import { cn } from '../../utils/cn';
import { GroupEditModal } from '../groups/GroupEditModal';

type LibFilter = 'Alles' | 'Radio’s' | 'Groepen' | 'Nummers';

export const LibraryPage: React.FC = () => {
  const {
    currentUser,
    groups,
    sessions,
    likedTrackIds,
    navigate,
    playTrack,
    setPrivacyModalOpen,
  } = useApp();

  const [filter, setFilter] = useState<LibFilter>('Alles');
  const [createGroupOpen, setCreateGroupOpen] = useState(false);

  const savedSessions = useMemo(
    () => Object.values(sessions).filter((s) => s.isSaved),
    [sessions]
  );

  const likedTracks = useMemo(
    () =>
      likedTrackIds
        .map((id) => TRACK_BY_ID[id])
        .filter((t): t is NonNullable<typeof t> => Boolean(t)),
    [likedTrackIds]
  );

  const likedCover = useMemo(() => generateSpecialCover('liked'), []);

  return (
    <div className="px-4 pt-5 pb-6 space-y-5">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setPrivacyModalOpen(true)}
            aria-label="Open privacy en profiel"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-8 h-8 rounded-full object-cover ring-2 ring-white/15"
            />
          </button>
          <h1 className="text-2xl font-extrabold tracking-tight">Bibliotheek</h1>
        </div>

        <button
          type="button"
          onClick={() => setCreateGroupOpen(true)}
          className="px-3 py-1.5 rounded-full bg-[#282828] hover:bg-[#333333] text-xs font-bold text-white inline-flex items-center gap-1.5 transition"
        >
          <Plus className="w-4 h-4 text-[#1ED760]" />
          Nieuwe groep
        </button>
      </header>

      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
        {(['Alles', 'Radio’s', 'Groepen', 'Nummers'] as LibFilter[]).map((pill) => (
          <button
            key={pill}
            type="button"
            onClick={() => setFilter(pill)}
            className={cn(
              'px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition',
              filter === pill
                ? 'bg-[#1ED760] text-black'
                : 'bg-[#282828] text-white hover:bg-[#333333]'
            )}
          >
            {pill}
          </button>
        ))}
      </div>

      {/* Gelikete nummers samenvatting */}
      {(filter === 'Alles' || filter === 'Nummers') && (
        <div className="space-y-2.5">
          <button
            type="button"
            onClick={() => navigate({ name: 'playlist-detail', playlistId: 'liked' })}
            className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
          >
            <img
              src={likedCover}
              alt="Nummers die je leuk vindt"
              className="w-14 h-14 rounded-lg object-cover shrink-0"
            />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-white">Nummers die je leuk vindt</p>
              <p className="text-xs text-[#B3B3B3] mt-0.5">
                Afspeellijst • {likedTracks.length} nummers
              </p>
            </div>
            <Heart className="w-4 h-4 fill-[#1ED760] text-[#1ED760] shrink-0 mr-1" />
          </button>

          {filter === 'Nummers' && (
            <div className="space-y-1.5 pt-1">
              {likedTracks.map((track) => (
                <button
                  key={track.id}
                  type="button"
                  onClick={() => playTrack(track.id, true)}
                  className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#282828] text-left transition"
                >
                  <img
                    src={track.albumArtwork}
                    alt={track.title}
                    className="w-11 h-11 rounded-md object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white truncate">{track.title}</p>
                    <p className="text-xs text-[#B3B3B3] truncate">{track.artist}</p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Opgeslagen Vriendenradio's */}
      {(filter === 'Alles' || filter === 'Radio’s') && (
        <section className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#B3B3B3] uppercase tracking-wider">
              Opgeslagen Vriendenradio’s ({savedSessions.length})
            </h2>
            <button
              type="button"
              onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
              className="text-xs font-bold text-[#1ED760]"
            >
              + Nieuw
            </button>
          </div>
          {savedSessions.length === 0 ? (
            <div className="rounded-xl bg-[#181818] p-4 text-center space-y-2">
              <p className="text-xs text-[#B3B3B3]">
                Je hebt nog geen extra radio’s opgeslagen.
              </p>
              <button
                type="button"
                onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
                className="px-4 py-2 rounded-full bg-[#1ED760] text-black text-xs font-bold"
              >
                Maak vriendenradio
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {savedSessions.map((session) => (
                <button
                  key={session.id}
                  type="button"
                  onClick={() => navigate({ name: 'group-radio', sessionId: session.id })}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
                >
                  <img
                    src={session.coverArtwork}
                    alt={session.title}
                    className="w-14 h-14 rounded-lg object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white truncate">{session.title}</p>
                    <p className="text-xs text-[#B3B3B3] truncate">{session.subtitle}</p>
                  </div>
                  <Radio className="w-4 h-4 text-[#1ED760] shrink-0" />
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Groepen */}
      {(filter === 'Alles' || filter === 'Groepen') && (
        <section className="space-y-2.5">
          <h2 className="text-sm font-bold text-[#B3B3B3] uppercase tracking-wider">
            Jouw groepen ({groups.length})
          </h2>
          <div className="space-y-2">
            {groups.map((group) => (
              <button
                key={group.id}
                type="button"
                onClick={() => navigate({ name: 'group-profile', groupId: group.id })}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
              >
                <img
                  src={group.coverArtwork}
                  alt={group.name}
                  className="w-14 h-14 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-white truncate">{group.name}</p>
                  <p className="text-xs text-[#B3B3B3]">{group.memberIds.length} leden</p>
                </div>
                <Users className="w-4 h-4 text-[#B3B3B3] shrink-0" />
              </button>
            ))}
          </div>
        </section>
      )}

      <GroupEditModal
        open={createGroupOpen}
        onClose={() => setCreateGroupOpen(false)}
      />
    </div>
  );
};
