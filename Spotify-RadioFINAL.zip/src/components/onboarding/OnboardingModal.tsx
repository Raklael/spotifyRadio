import React from 'react';
import { Lock, Radio, ShieldCheck, Sparkles, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { BottomSheet } from '../ui/BottomSheet';
import { cn } from '../../utils/cn';

export const OnboardingModal: React.FC = () => {
  const {
    onboardingOpen,
    dismissOnboarding,
    privacy,
    updatePrivacy,
    navigate,
  } = useApp();

  return (
    <BottomSheet
      open={onboardingOpen}
      onClose={dismissOnboarding}
      title="Welkom bij Spotify Friends Radio"
      subtitle="Ontdek nieuwe muziek via je vrienden"
    >
      <div className="space-y-5 pb-3">
        <div className="rounded-2xl bg-gradient-to-br from-[#1ED760]/20 via-[#1C2C22] to-[#181818] border border-[#1ED760]/30 p-4 space-y-2">
          <p className="text-xs font-extrabold uppercase tracking-wider text-[#1ED760]">
            Je favoriete muziek ontdek je samen
          </p>
          <h3 className="text-lg font-extrabold text-white leading-snug">
            Ontdek nieuwe muziek via je vrienden.
          </h3>
          <p className="text-xs text-[#D1D5DB] leading-relaxed">
            Waarom alleen een Radio maken vanuit een nummer, als je ook een Radio kunt maken
            vanuit je vrienden?
          </p>
        </div>

        <div className="space-y-2.5">
          {[
            {
              icon: Users,
              title: 'Combineer muzieksmaken',
              desc: 'Kies één vriend, een vriendengroep of je hele voetbalteam (zoals FC Zaterdag 3).',
            },
            {
              icon: Radio,
              title: 'Maak direct groepsradio’s',
              desc: 'Stel de sfeer in (bijv. Derde helft) en geef iedereen eerlijke invloed.',
            },
            {
              icon: Sparkles,
              title: 'Ontdek samen nieuwe tracks',
              desc: 'Zie altijd waarom een nummer wordt aanbevolen en stem live met de groep.',
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="flex items-start gap-3 p-3 rounded-xl bg-[#222222] border border-white/5"
              >
                <div className="w-8 h-8 rounded-lg bg-[#1ED760]/15 text-[#1ED760] flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-extrabold text-white">{item.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] mt-0.5 leading-snug">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Opt-in privacy instelling direct tijdens onboarding */}
        <div className="rounded-2xl bg-[#202020] border border-white/10 p-3.5 space-y-2.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#1ED760]" />
              <span className="text-xs font-extrabold text-white">
                Deel mijn muzieksmaak met vrienden
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={privacy.shareTasteWithFriends}
              onClick={() =>
                updatePrivacy({ shareTasteWithFriends: !privacy.shareTasteWithFriends })
              }
              className={cn(
                'relative w-11 h-6 rounded-full transition-colors p-0.5 shrink-0',
                privacy.shareTasteWithFriends ? 'bg-[#1ED760]' : 'bg-[#3E3E3E]'
              )}
            >
              <span
                className={cn(
                  'block w-5 h-5 rounded-full bg-white transition-transform',
                  privacy.shareTasteWithFriends ? 'translate-x-5' : 'translate-x-0'
                )}
              />
            </button>
          </div>
          <p className="text-[11px] text-[#B3B3B3] flex items-start gap-1.5 leading-snug">
            <Lock className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>
              Dit is opt-in: je privé-luistergeschiedenis wordt nooit automatisch gedeeld. De app
              werkt direct in demomodus zonder registratie.
            </span>
          </p>
        </div>

        <div className="space-y-2">
          <button
            type="button"
            onClick={dismissOnboarding}
            className="w-full py-3 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] text-black font-extrabold text-sm transition"
          >
            Direct starten in demomodus
          </button>
          <button
            type="button"
            onClick={() => {
              dismissOnboarding();
              navigate({ name: 'radio-builder', initialStep: 1 });
            }}
            className="w-full py-2.5 rounded-full bg-[#282828] hover:bg-[#333333] text-white font-bold text-xs transition"
          >
            Meteen een vriendenradio maken
          </button>
        </div>
      </div>
    </BottomSheet>
  );
};
