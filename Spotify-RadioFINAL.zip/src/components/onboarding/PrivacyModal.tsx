import React from 'react';
import { Info, Lock, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { BottomSheet } from '../ui/BottomSheet';
import { cn } from '../../utils/cn';

export const PrivacyModal: React.FC = () => {
  const { privacyModalOpen, setPrivacyModalOpen, privacy, updatePrivacy, openOnboarding } =
    useApp();

  const toggles: {
    key: keyof typeof privacy;
    title: string;
    desc: string;
  }[] = [
    {
      key: 'shareTasteWithFriends',
      title: 'Deel mijn muzieksmaak met vrienden',
      desc: 'Hoofdschakelaar (opt-in). Alleen als dit aan staat zien vrienden jouw matchpercentage.',
    },
    {
      key: 'shareFavoriteGenres',
      title: 'Deel favoriete genres',
      desc: 'Toont je topgenres zonder losse luistersessies vrij te geven.',
    },
    {
      key: 'shareLikedSongs',
      title: 'Deel gelikete nummers',
      desc: 'Gebruikt gelikete nummers om gezamenlijke favorieten met vrienden te vinden.',
    },
    {
      key: 'participateInGroupRadios',
      title: 'Deelnemen aan groepsaanbevelingen',
      desc: 'Laat jouw voorkeuren meewegen wanneer een groep een gezamenlijke radio start.',
    },
  ];

  return (
    <BottomSheet
      open={privacyModalOpen}
      onClose={() => setPrivacyModalOpen(false)}
      title="Privacy & Gegevensgebruik"
      subtitle="Jij bepaalt wat je deelt met vrienden en groepen"
    >
      <div className="space-y-4 pb-3">
        <div className="rounded-2xl bg-[#222222] border border-white/10 p-3.5 flex items-start gap-2.5">
          <ShieldCheck className="w-5 h-5 text-[#1ED760] shrink-0 mt-0.5" />
          <p className="text-xs text-[#D1D5DB] leading-relaxed">
            Spotify Friends Radio deelt nooit automatisch je volledige privé-luistergeschiedenis.
            Alle voorkeuren draaien lokaal in deze interactieve demomodus.
          </p>
        </div>

        <div className="space-y-2.5">
          {toggles.map((item) => {
            const active = privacy[item.key];
            return (
              <div
                key={item.key}
                className="flex items-center justify-between gap-3 p-3.5 rounded-2xl bg-[#1F1F1F] border border-white/5"
              >
                <div className="min-w-0">
                  <p className="text-xs font-extrabold text-white">{item.title}</p>
                  <p className="text-[11px] text-[#B3B3B3] mt-0.5 leading-snug">{item.desc}</p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={active}
                  aria-label={item.title}
                  onClick={() => updatePrivacy({ [item.key]: !active })}
                  className={cn(
                    'relative w-11 h-6 rounded-full transition-colors p-0.5 shrink-0',
                    active ? 'bg-[#1ED760]' : 'bg-[#3E3E3E]'
                  )}
                >
                  <span
                    className={cn(
                      'block w-5 h-5 rounded-full bg-white transition-transform',
                      active ? 'translate-x-5' : 'translate-x-0'
                    )}
                  />
                </button>
              </div>
            );
          })}
        </div>

        <div className="rounded-xl bg-white/[0.04] p-3 text-[11px] text-[#B3B3B3] space-y-1.5">
          <p className="font-bold text-white flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-[#1ED760]" />
            Welke data gebruikt het aanbevelingsalgoritme?
          </p>
          <p className="leading-relaxed">
            Alleen geaggregeerde genrevoorkeuren, favoriete artiesten, gekozen sfeer en
            ontdekkingsvoorkeur. Geen persoonlijke metadata of tijdstempels van losse streams.
          </p>
        </div>

        <div className="flex items-center justify-between gap-2 pt-1">
          <button
            type="button"
            onClick={() => {
              setPrivacyModalOpen(false);
              openOnboarding();
            }}
            className="text-xs font-bold text-[#1ED760] inline-flex items-center gap-1 hover:underline"
          >
            <Lock className="w-3.5 h-3.5" />
            Bekijk introductie opnieuw
          </button>

          <button
            type="button"
            onClick={() => setPrivacyModalOpen(false)}
            className="px-5 py-2.5 rounded-full bg-[#1ED760] text-black text-xs font-extrabold"
          >
            Gereed
          </button>
        </div>
      </div>
    </BottomSheet>
  );
};
