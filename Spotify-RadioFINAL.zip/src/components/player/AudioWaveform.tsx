import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface AudioWaveformProps {
  isPlaying: boolean;
  bars?: number;
  className?: string;
  barClassName?: string;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  isPlaying,
  bars = 4,
  className,
  barClassName,
}) => {
  const heights = [0.45, 0.9, 0.6, 0.85, 0.5, 0.95, 0.65];

  return (
    <div
      className={cn('inline-flex items-end gap-[2.5px] h-4', className)}
      aria-hidden="true"
    >
      {Array.from({ length: bars }).map((_, idx) => {
        const peak = heights[idx % heights.length];
        return (
          <motion.span
            key={idx}
            className={cn('w-[3px] rounded-full bg-[#1ED760]', barClassName)}
            animate={
              isPlaying
                ? {
                    height: ['25%', `${Math.round(peak * 100)}%`, '35%', '90%', '25%'],
                  }
                : { height: '28%' }
            }
            transition={
              isPlaying
                ? {
                    duration: 0.9 + (idx % 3) * 0.2,
                    repeat: Infinity,
                    ease: 'easeInOut',
                    delay: idx * 0.1,
                  }
                : { duration: 0.2 }
            }
          />
        );
      })}
    </div>
  );
};
