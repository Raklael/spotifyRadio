import React from 'react';
import { Check, Laptop, Smartphone, Speaker } from 'lucide-react';
import { DeviceName, useApp } from '../../context/AppContext';
import { BottomSheet } from '../ui/BottomSheet';
import { cn } from '../../utils/cn';

const DEVICES: { name: DeviceName; subtitle: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { name: 'iPhone van Rafael', subtitle: 'Dit apparaat • Bluetooth & Lokaal', icon: Smartphone },
  { name: 'Kleedkamer JBL Speaker', subtitle: 'Spotify Connect • Sportpark Veld 3', icon: Speaker },
  { name: 'Woonkamer Sonos', subtitle: 'Wi-Fi • Huisgenoten netwerk', icon: Laptop },
];

export const DeviceSheet: React.FC = () => {
  const { deviceSheetOpen, setDeviceSheetOpen, selectedDevice, setSelectedDevice, showToast } = useApp();

  return (
    <BottomSheet
      open={deviceSheetOpen}
      onClose={() => setDeviceSheetOpen(false)}
      title="Verbinden met een apparaat"
      subtitle="Demo Spotify Connect — kies waar de groepsradio speelt"
    >
      <div className="space-y-2.5 pb-2">
        {DEVICES.map((device) => {
          const Icon = device.icon;
          const active = selectedDevice === device.name;
          return (
            <button
              key={device.name}
              type="button"
              onClick={() => {
                setSelectedDevice(device.name);
                showToast(`Afspelen op ${device.name}`);
                setDeviceSheetOpen(false);
              }}
              className={cn(
                'w-full flex items-center justify-between gap-3 p-3.5 rounded-2xl border transition text-left',
                active
                  ? 'bg-[#1ED760]/15 border-[#1ED760]/50 text-white'
                  : 'bg-[#282828] border-white/5 text-white hover:bg-[#333333]'
              )}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={cn(
                    'w-10 h-10 rounded-xl flex items-center justify-center shrink-0',
                    active ? 'bg-[#1ED760] text-black' : 'bg-white/10 text-white'
                  )}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className={cn('text-sm font-bold truncate', active && 'text-[#1ED760]')}>
                    {device.name}
                  </p>
                  <p className="text-xs text-[#B3B3B3] truncate">{device.subtitle}</p>
                </div>
              </div>
              {active && <Check className="w-5 h-5 text-[#1ED760] shrink-0" />}
            </button>
          );
        })}
      </div>
    </BottomSheet>
  );
};
