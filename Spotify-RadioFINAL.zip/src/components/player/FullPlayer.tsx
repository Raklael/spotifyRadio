import React from 'react';
import {
  ChevronDown,
  Heart,
  HelpCircle,
  ListMusic,
  MonitorSpeaker,
  Pause,
  Play,
  Radio,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  Users,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import { FRIEND_BY_ID } from '../../data/mockData';
import { formatTime } from '../../utils/formatTime';
import { cn } from '../../utils/cn';
import { AudioWaveform } from './AudioWaveform';

export const FullPlayer: React.FC = () => {
  const {
    fullPlayerOpen,
    setFullPlayerOpen,
    currentTrack,
    currentRecommendedEntry,
    activeSession,
    isPlaying,
    progressSec,
    shuffle,
    repeat,
    synthAudioEnabled,
    selectedDevice,
    likedTrackIds,
    togglePlay,
    nextTrack,
    prevTrack,
    seekTo,
    toggleShuffle,
    cycleRepeat,
    toggleSynthAudio,
    toggleLikeTrack,
    startTrackRadio,
    setDeviceSheetOpen,
    openWhyModal,
    setVotingSheetOpen,
    navigate,
  } = useApp();

  const isLiked = likedTrackIds.includes(currentTrack.id);
  const progressPct = Math.min(100, (progressSec / Math.max(1, currentTrack.duration)) * 100);

  const contributingFriends = (currentRecommendedEntry?.contributingFriendIds ?? [])
    .map((id) => FRIEND_BY_ID[id])
    .filter(Boolean);

  const socialSubtitle = activeSession
    ? (() => {
        const firstTwo = activeSession.memberIds
          .slice(0, 2)
          .map((id) => FRIEND_BY_ID[id]?.name)
          .filter(Boolean);
        const rest = Math.max(0, activeSession.memberIds.length - firstTwo.length);
        if (firstTwo.length === 0) return activeSession.title;
        return rest > 0
          ? `Radio met ${firstTwo.join(', ')} + ${rest} anderen`
          : `Radio met ${firstTwo.join(' en ')}`;
      })()
    : 'Persoonlijke afspeellijst';

  return (
    <AnimatePresence>
      {fullPlayerOpen && (
        <motion.div
          key="full-player"
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 30, stiffness: 290 }}
          className="fixed inset-0 z-50 flex justify-center bg-black/80 backdrop-blur-md"
          role="dialog"
          aria-modal="true"
          aria-label="Volledige muziekspeler"
        >
          <div
            className="w-full max-w-[430px] h-full flex flex-col justify-between px-5 pt-4 pb-6 overflow-y-auto"
            style={{
              background: `linear-gradient(180deg, ${currentTrack.accentColor}48 0%, #191919 46%, #121212 100%)`,
            }}
          >
            {/* Top Bar */}
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setFullPlayerOpen(false)}
                aria-label="Minimaliseer speler"
                className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/10 text-white"
              >
                <ChevronDown className="w-6 h-6" />
              </button>

              <div className="text-center min-w-0 flex-1">
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/75">
                  {activeSession ? 'Speelt uit Friends Radio' : 'Speelt nu af'}
                </p>
                <p className="text-xs font-bold text-white truncate">
                  {activeSession ? activeSession.title : currentTrack.album}
                </p>
              </div>

              <button
                type="button"
                onClick={toggleSynthAudio}
                aria-label={synthAudioEnabled ? 'Demp demo-audio' : 'Zet demo-audio aan'}
                title="Optionele Web Audio synth-preview"
                className={cn(
                  'px-2.5 py-1.5 rounded-full text-[10px] font-bold flex items-center gap-1 border transition',
                  synthAudioEnabled
                    ? 'bg-[#1ED760]/20 border-[#1ED760]/60 text-[#1ED760]'
                    : 'bg-white/10 border-white/10 text-white/80 hover:bg-white/20'
                )}
              >
                {synthAudioEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span>{synthAudioEnabled ? 'Synth aan' : 'Stil'}</span>
              </button>
            </div>

            {/* Album Artwork */}
            <div className="my-4 flex flex-col items-center">
              <motion.div
                key={currentTrack.id}
                initial={{ scale: 0.94, opacity: 0.7 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.25 }}
                className="relative w-full max-w-[310px] aspect-square rounded-2xl overflow-hidden shadow-2xl border border-white/10"
              >
                <img
                  src={currentTrack.albumArtwork}
                  alt={currentTrack.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-[10px] font-semibold text-white/90 border border-white/10">
                    Interactieve demosimulatie
                  </span>
                  <AudioWaveform isPlaying={isPlaying} className="bg-black/60 px-2 py-1 rounded-full h-6" />
                </div>
              </motion.div>

              {/* Friends Radio Extension Indicator */}
              {activeSession && (
                <div className="w-full max-w-[330px] mt-4 rounded-2xl bg-white/[0.07] border border-white/10 px-3.5 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="flex -space-x-2 shrink-0">
                        {contributingFriends.slice(0, 3).map((friend) => (
                          <img
                            key={friend.id}
                            src={friend.avatar}
                            alt={friend.name}
                            className="w-6 h-6 rounded-full ring-2 ring-[#181818] object-cover"
                          />
                        ))}
                      </div>
                      <p className="text-[11px] font-semibold text-white/90 truncate">
                        {socialSubtitle}
                      </p>
                    </div>
                    {currentRecommendedEntry && (
                      <button
                        type="button"
                        onClick={() => openWhyModal(currentRecommendedEntry)}
                        className="shrink-0 inline-flex items-center gap-1 text-[11px] font-bold text-[#1ED760] hover:underline"
                      >
                        <HelpCircle className="w-3.5 h-3.5" />
                        Waarom dit nummer?
                      </button>
                    )}
                  </div>
                  {currentRecommendedEntry && (
                    <p className="text-[11px] text-[#B3B3B3] mt-1.5 leading-snug">
                      {currentRecommendedEntry.primaryReason}
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Track Info & Like */}
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <h2 className="text-xl font-extrabold text-white truncate tracking-tight">
                    {currentTrack.title}
                  </h2>
                  <p className="text-sm text-[#B3B3B3] truncate font-medium">
                    {currentTrack.artist} • <span className="text-xs">{currentTrack.genre}</span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => toggleLikeTrack(currentTrack.id)}
                  aria-label={isLiked ? 'Verwijder uit favorieten' : 'Vind nummer leuk'}
                  className="w-10 h-10 rounded-full flex items-center justify-center active:scale-90 transition shrink-0"
                >
                  <Heart
                    className={cn(
                      'w-6 h-6 transition-colors',
                      isLiked ? 'fill-[#1ED760] text-[#1ED760]' : 'text-[#B3B3B3] hover:text-white'
                    )}
                  />
                </button>
              </div>

              {/* Start Radio vanaf dit nummer & Mix acties */}
              <div className="flex items-center gap-2 pt-0.5">
                <button
                  type="button"
                  onClick={() => startTrackRadio(currentTrack)}
                  className="flex-1 py-2 px-3 rounded-full bg-[#1ED760]/20 hover:bg-[#1ED760]/30 active:scale-[0.98] border border-[#1ED760]/40 text-[#1ED760] font-bold text-xs inline-flex items-center justify-center gap-1.5 transition shadow-sm"
                >
                  <Radio className="w-3.5 h-3.5" />
                  <span>Start Radio vanaf dit nummer</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setFullPlayerOpen(false);
                    navigate({ name: 'radio-builder', initialStep: 1 });
                  }}
                  className="py-2 px-3 rounded-full bg-white/10 hover:bg-white/15 active:scale-[0.98] border border-white/10 text-white font-semibold text-xs inline-flex items-center justify-center gap-1.5 transition shrink-0"
                  title="Mix met vrienden"
                >
                  <Users className="w-3.5 h-3.5 text-[#1ED760]" />
                  <span>Mix met vrienden</span>
                </button>
              </div>

              {/* Progress Scrubber */}
              <div>
                <input
                  type="range"
                  min={0}
                  max={currentTrack.duration}
                  value={progressSec}
                  onChange={(e) => seekTo(Number(e.target.value))}
                  aria-label="Nummer voortgang"
                  className="spotify-slider w-full"
                  style={{
                    background: `linear-gradient(to right, #ffffff ${progressPct}%, rgba(255,255,255,0.22) ${progressPct}%)`,
                    height: '4px',
                    borderRadius: '9999px',
                  }}
                />
                <div className="flex justify-between text-[11px] font-medium text-[#B3B3B3] mt-1.5">
                  <span>{formatTime(progressSec)}</span>
                  <span>{formatTime(currentTrack.duration)}</span>
                </div>
              </div>

              {/* Playback Controls */}
              <div className="flex items-center justify-between px-1">
                <button
                  type="button"
                  onClick={toggleShuffle}
                  aria-label="Shuffle"
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center transition',
                    shuffle ? 'text-[#1ED760]' : 'text-[#B3B3B3] hover:text-white'
                  )}
                >
                  <Shuffle className="w-5 h-5" />
                </button>

                <button
                  type="button"
                  onClick={prevTrack}
                  aria-label="Vorig nummer"
                  className="w-11 h-11 rounded-full flex items-center justify-center text-white hover:bg-white/10 active:scale-90 transition"
                >
                  <SkipBack className="w-7 h-7 fill-white" />
                </button>

                <button
                  type="button"
                  onClick={togglePlay}
                  aria-label={isPlaying ? 'Pauzeren' : 'Afspelen'}
                  className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition"
                >
                  {isPlaying ? (
                    <Pause className="w-7 h-7 fill-black" />
                  ) : (
                    <Play className="w-7 h-7 fill-black ml-1" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={nextTrack}
                  aria-label="Volgend nummer"
                  className="w-11 h-11 rounded-full flex items-center justify-center text-white hover:bg-white/10 active:scale-90 transition"
                >
                  <SkipForward className="w-7 h-7 fill-white" />
                </button>

                <button
                  type="button"
                  onClick={cycleRepeat}
                  aria-label="Herhalen"
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center transition',
                    repeat !== 'off' ? 'text-[#1ED760]' : 'text-[#B3B3B3] hover:text-white'
                  )}
                >
                  {repeat === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
                </button>
              </div>

              {/* Bottom Utility Bar */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setDeviceSheetOpen(true)}
                  className="flex items-center gap-1.5 text-xs font-semibold text-[#1ED760] hover:underline"
                >
                  <MonitorSpeaker className="w-4 h-4" />
                  <span className="truncate max-w-[140px]">{selectedDevice}</span>
                </button>

                <div className="flex items-center gap-2">
                  {activeSession && (
                    <button
                      type="button"
                      onClick={() => {
                        setFullPlayerOpen(false);
                        setVotingSheetOpen(true);
                      }}
                      className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/15 text-xs font-semibold text-white inline-flex items-center gap-1.5"
                    >
                      <Users className="w-3.5 h-3.5 text-[#1ED760]" />
                      <span>Groepsstemmen</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setFullPlayerOpen(false);
                      if (activeSession) {
                        navigate({ name: 'group-radio', sessionId: activeSession.id });
                      }
                    }}
                    aria-label="Open wachtrij"
                    className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
                  >
                    <ListMusic className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
