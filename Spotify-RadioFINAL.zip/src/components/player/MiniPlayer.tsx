import React from 'react';
import { MonitorSpeaker, Pause, Play, Radio } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import { cn } from '../../utils/cn';

export const MiniPlayer: React.FC = () => {
  const {
    currentTrack,
    activeSession,
    isPlaying,
    progressSec,
    togglePlay,
    setFullPlayerOpen,
    setDeviceSheetOpen,
    startTrackRadio,
  } = useApp();

  const progressPct = Math.min(100, (progressSec / Math.max(1, currentTrack.duration)) * 100);

  return (
    <motion.div
      layout
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="mx-2 mb-1.5 rounded-xl overflow-hidden shadow-xl border border-white/10"
      style={{
        background: `linear-gradient(90deg, ${currentTrack.accentColor}38 0%, #242424 55%, #1E1E1E 100%)`,
      }}
    >
      <div className="flex items-center gap-2.5 px-2.5 py-2">
        <button
          type="button"
          onClick={() => setFullPlayerOpen(true)}
          className="flex items-center gap-2.5 flex-1 min-w-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1ED760] rounded-lg"
          aria-label={`Open speler voor ${currentTrack.title} van ${currentTrack.artist}`}
        >
          <img
            src={currentTrack.albumArtwork}
            alt={currentTrack.album}
            className="w-10 h-10 rounded-md object-cover shrink-0 shadow"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="text-[13px] font-bold text-white truncate leading-tight">
                {currentTrack.title}
              </p>
              {activeSession && (
                <span className="shrink-0 text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#1ED760]/20 text-[#1ED760]">
                  Radio
                </span>
              )}
            </div>
            <p className="text-[11px] text-[#D4D4D4] truncate leading-tight mt-0.5">
              {currentTrack.artist}
              {activeSession ? ` • ${activeSession.title}` : ''}
            </p>
          </div>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => setDeviceSheetOpen(true)}
            aria-label="Apparaat kiezen"
            className="w-9 h-9 rounded-full flex items-center justify-center text-[#B3B3B3] hover:text-white active:scale-95 transition"
          >
            <MonitorSpeaker className="w-[18px] h-[18px]" />
          </button>
            <button
              type="button"
              onClick={() => startTrackRadio(currentTrack)}
              title="Start Radio vanaf dit nummer"
              className="w-9 h-9 rounded-full flex items-center justify-center text-[#1ED760] hover:text-white active:scale-95 transition"
            >
              <Radio className="w-5 h-5" />
            </button>
        </div>
      </div>

      {/* Voortgangsbalk onderaan mini-player */}
      <div className="h-[2.5px] w-full bg-white/15">
        <div
          className="h-full bg-white transition-[width] duration-300 ease-linear"
          style={{ width: `${progressPct}%` }}
        />
      </div>
    </motion.div>
  );
};
