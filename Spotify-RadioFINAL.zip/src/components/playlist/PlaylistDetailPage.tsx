import React from 'react';
import {
  ArrowLeft,
  Heart,
  MoreHorizontal,
  Pause,
  Play,
  Radio,
  Share2,
  Sparkles,
  Users,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Track } from '../../types/music';
import { formatTime } from '../../utils/formatTime';
import { AudioWaveform } from '../player/AudioWaveform';
import { cn } from '../../utils/cn';

interface PlaylistDetailPageProps {
  playlistId: string;
}

export const PlaylistDetailPage: React.FC<PlaylistDetailPageProps> = ({ playlistId }) => {
  const {
    getPlaylistData,
    goBack,
    currentTrack,
    isPlaying,
    likedTrackIds,
    toggleLikeTrack,
    playTrack,
    togglePlay,
    startTrackRadio,
    navigate,
    showToast,
  } = useApp();

  const data = getPlaylistData(playlistId);

  if (!data) {
    return (
      <div className="p-6 text-center space-y-3">
        <p className="text-sm text-[#B3B3B3]">Afspeellijst niet gevonden.</p>
        <button
          type="button"
          onClick={goBack}
          className="px-4 py-2 rounded-full bg-[#1ED760] text-black text-xs font-bold"
        >
          Ga terug
        </button>
      </div>
    );
  }

  const { title, subtitle, artwork, tracks, category } = data;
  const isPlayingThisPlaylist = isPlaying && tracks.some((t) => t.id === currentTrack.id);
  const totalDuration = tracks.reduce((sum, t) => sum + t.duration, 0);

  const handlePlayAll = () => {
    if (isPlayingThisPlaylist) {
      togglePlay();
    } else if (tracks[0]) {
      playTrack(tracks[0].id, true);
      showToast(`Afspelen gestart: ${title}`);
    }
  };

  const handleStartRadioFromPlaylist = () => {
    if (tracks[0]) {
      startTrackRadio(tracks[0]);
    }
  };

  return (
    <div className="min-h-full bg-gradient-to-b from-[#2B3545] via-[#121212] via-35% to-[#121212] pb-10">
      {/* Top Navigatiebalk */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-3 bg-[#121212]/80 backdrop-blur-md border-b border-white/5">
        <button
          type="button"
          onClick={goBack}
          aria-label="Terug"
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white active:scale-95 transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <span className="text-xs font-bold text-white/90 truncate max-w-[200px]">
          {title}
        </span>

        <button
          type="button"
          onClick={() => showToast('Afspeellijst link gekopieerd (demo)')}
          aria-label="Delen"
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white active:scale-95 transition"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>

      <div className="px-4 pt-3 space-y-5">
        {/* Hero Header */}
        <div className="flex flex-col items-center text-center space-y-3 pt-2">
          <div className="relative shadow-2xl rounded-2xl overflow-hidden border border-white/10 group">
            <img
              src={artwork}
              alt={title}
              className="w-44 h-44 object-cover"
            />
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#1ED760]">
              {category ?? 'Afspeellijst'}
            </span>
            <h1 className="text-2xl font-black text-white tracking-tight leading-tight">
              {title}
            </h1>
            <p className="text-xs text-[#B3B3B3] max-w-xs">{subtitle}</p>
            <p className="text-[11px] font-medium text-[#727272]">
              {tracks.length} nummers • {Math.round(totalDuration / 60)} min
            </p>
          </div>
        </div>

        {/* Action Bar in Spotify-stijl */}
        <div className="flex items-center justify-between gap-3 pt-2">
          {/* Radio-knoppen */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={handleStartRadioFromPlaylist}
              className="px-3.5 py-2 rounded-full bg-[#1ED760]/20 hover:bg-[#1ED760]/30 active:scale-95 text-xs font-bold text-[#1ED760] inline-flex items-center gap-1.5 border border-[#1ED760]/40 transition shrink-0"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Start Radio</span>
            </button>

            <button
              type="button"
              onClick={() => {
                navigate({ name: 'radio-builder', initialStep: 1 });
              }}
              className="px-3 py-2 rounded-full bg-white/10 hover:bg-white/15 active:scale-95 text-xs font-semibold text-white inline-flex items-center gap-1.5 border border-white/10 transition shrink-0"
            >
              <Users className="w-3.5 h-3.5 text-[#1ED760]" />
              <span>Mix met vrienden</span>
            </button>
          </div>

          {/* Grote groene Play-knop */}
          <button
            type="button"
            onClick={handlePlayAll}
            aria-label={isPlayingThisPlaylist ? 'Pauzeer' : 'Speel af'}
            className="w-13 h-13 w-[52px] h-[52px] rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-95 text-black flex items-center justify-center shadow-xl transition shrink-0"
          >
            {isPlayingThisPlaylist ? (
              <Pause className="w-6 h-6 fill-black" />
            ) : (
              <Play className="w-6 h-6 fill-black ml-0.5" />
            )}
          </button>
        </div>

        {/* Nummerslijst */}
        <section className="space-y-1 pt-2">
          <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3] px-2 mb-2">
            Nummers ({tracks.length})
          </p>

          <div className="divide-y divide-white/[0.04]">
            {tracks.map((track, idx) => {
              const isCurrent = isPlaying && currentTrack.id === track.id;
              const isLiked = likedTrackIds.includes(track.id);

              return (
                <div
                  key={track.id}
                  className={cn(
                    'flex items-center gap-3 py-2.5 px-2 rounded-xl transition group',
                    isCurrent ? 'bg-[#1ED760]/10' : 'hover:bg-white/[0.04]'
                  )}
                >
                  {/* Track index / Play cover */}
                  <button
                    type="button"
                    onClick={() => playTrack(track.id, true)}
                    className="relative w-10 h-10 rounded-md overflow-hidden shrink-0 group/cover"
                    aria-label={`Speel ${track.title}`}
                  >
                    <img
                      src={track.albumArtwork}
                      alt={track.title}
                      className="w-full h-full object-cover"
                    />
                    <div
                      className={cn(
                        'absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity',
                        isCurrent ? 'opacity-100' : 'opacity-0 group-hover/cover:opacity-100'
                      )}
                    >
                      {isCurrent ? (
                        <AudioWaveform isPlaying={isPlaying} bars={3} className="h-4" />
                      ) : (
                        <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                      )}
                    </div>
                  </button>

                  {/* Track Info */}
                  <button
                    type="button"
                    onClick={() => playTrack(track.id, true)}
                    className="min-w-0 flex-1 text-left"
                  >
                    <p
                      className={cn(
                        'text-sm font-semibold truncate leading-tight',
                        isCurrent ? 'text-[#1ED760]' : 'text-white'
                      )}
                    >
                      {track.title}
                    </p>
                    <p className="text-xs text-[#B3B3B3] truncate mt-0.5 leading-tight">
                      {track.artist} • <span className="text-[11px]">{track.genre}</span>
                    </p>
                  </button>

                  {/* Acties per nummer: Start Radio knop + Like + Duur */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => startTrackRadio(track)}
                      title="Start Radio vanaf dit nummer"
                      aria-label={`Start Radio vanaf ${track.title}`}
                      className="px-2 py-1 rounded-full text-[11px] font-bold text-[#1ED760] hover:bg-[#1ED760]/20 inline-flex items-center gap-1 transition"
                    >
                      <Radio className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Radio</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleLikeTrack(track.id)}
                      aria-label="Vind ik leuk"
                      className="w-8 h-8 rounded-full flex items-center justify-center text-[#B3B3B3] hover:text-white transition"
                    >
                      <Heart
                        className={cn(
                          'w-4 h-4 transition',
                          isLiked ? 'fill-[#1ED760] text-[#1ED760]' : ''
                        )}
                      />
                    </button>

                    <span className="text-xs text-[#727272] tabular-nums font-medium w-9 text-right">
                      {formatTime(track.duration)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
};
