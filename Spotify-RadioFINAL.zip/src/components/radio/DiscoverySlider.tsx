import React from 'react';
import { Compass, Scale } from 'lucide-react';
import { cn } from '../../utils/cn';

interface DiscoverySliderProps {
  value: number; // 0 - 100
  onChange: (val: number) => void;
  equalInfluence: boolean;
  onToggleEqualInfluence: (val: boolean) => void;
  compact?: boolean;
}

export const DiscoverySlider: React.FC<DiscoverySliderProps> = ({
  value,
  onChange,
  equalInfluence,
  onToggleEqualInfluence,
  compact = false,
}) => {
  const modeLabel =
    value < 34 ? 'Vertrouwd' : value < 68 ? 'Een goede mix' : 'Verrassend';

  return (
    <div className={cn('space-y-4', compact && 'space-y-3')}>
      {/* Discovery Slider Card */}
      <div className="rounded-2xl bg-[#181818] border border-white/10 p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-[#1ED760] shrink-0" />
            <h3 className="text-sm font-extrabold text-white">
              Hoe verrassend mag de muziek zijn?
            </h3>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-[#1ED760]/15 text-[#1ED760] text-[11px] font-bold shrink-0">
            {modeLabel}
          </span>
        </div>

        <input
          type="range"
          min={0}
          max={100}
          step={5}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          aria-label="Hoe verrassend mag de muziek zijn?"
          className="spotify-slider w-full"
          style={{
            background: `linear-gradient(to right, #1ED760 ${value}%, rgba(255,255,255,0.2) ${value}%)`,
            height: '5px',
            borderRadius: '9999px',
          }}
        />

        <div className="flex justify-between text-[11px] font-semibold text-[#B3B3B3]">
          <span className={value < 34 ? 'text-white font-bold' : ''}>Vertrouwd</span>
          <span className={value >= 34 && value < 68 ? 'text-white font-bold' : ''}>
            Een goede mix
          </span>
          <span className={value >= 68 ? 'text-white font-bold' : ''}>Verrassend</span>
        </div>
      </div>

      {/* Equal Influence Toggle */}
      <div className="rounded-2xl bg-[#181818] border border-white/10 p-4 flex items-center justify-between gap-3">
        <div className="flex items-start gap-2.5 min-w-0">
          <Scale className="w-4 h-4 text-[#1ED760] shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-extrabold text-white">
              Geef iedereen evenveel invloed
            </p>
            <p className="text-[11px] text-[#B3B3B3] mt-0.5 leading-snug">
              Zorgt dat alle geselecteerde leden eerlijk aan bod komen in de wachtrij.
            </p>
          </div>
        </div>

        <button
          type="button"
          role="switch"
          aria-checked={equalInfluence}
          aria-label="Geef iedereen evenveel invloed"
          onClick={() => onToggleEqualInfluence(!equalInfluence)}
          className={cn(
            'relative w-12 h-7 rounded-full transition-colors shrink-0 p-1',
            equalInfluence ? 'bg-[#1ED760]' : 'bg-[#3E3E3E]'
          )}
        >
          <span
            className={cn(
              'block w-5 h-5 rounded-full bg-white shadow transition-transform',
              equalInfluence ? 'translate-x-5' : 'translate-x-0'
            )}
          />
        </button>
      </div>
    </div>
  );
};
