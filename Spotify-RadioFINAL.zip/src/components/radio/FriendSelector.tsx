import React, { useMemo, useState } from 'react';
import { Check, Search, Users, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { Friend, Group } from '../../types/music';
import { cn } from '../../utils/cn';

interface FriendSelectorProps {
  friends: Friend[];
  groups: Group[];
  selectedIds: string[];
  onToggleFriend: (id: string) => void;
  onSelectGroup: (group: Group) => void;
  onClearAll: () => void;
}

export const FriendSelector: React.FC<FriendSelectorProps> = ({
  friends,
  groups,
  selectedIds,
  onToggleFriend,
  onSelectGroup,
  onClearAll,
}) => {
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return friends;
    return friends.filter(
      (f) =>
        f.name.toLowerCase().includes(q) ||
        f.fullName.toLowerCase().includes(q) ||
        f.favoriteGenres.some((g) => g.toLowerCase().includes(q))
    );
  }, [friends, query]);

  return (
    <div className="space-y-5">
      {/* Zoek vrienden */}
      <div className="relative">
        <Search className="w-4 h-4 text-[#B3B3B3] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Zoek vrienden op naam of genre..."
          aria-label="Zoek vrienden"
          className="w-full rounded-xl bg-[#282828] border border-white/10 pl-10 pr-9 py-2.5 text-sm text-white placeholder:text-[#B3B3B3] focus:outline-none focus:ring-2 focus:ring-[#1ED760]"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            aria-label="Wis zoekveld"
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#B3B3B3] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Voeg bestaande groep in één keer toe */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Snelselectie groep
          </p>
          {selectedIds.length > 0 && (
            <button
              type="button"
              onClick={onClearAll}
              className="text-xs font-bold text-[#B3B3B3] hover:text-white"
            >
              Wis selectie ({selectedIds.length})
            </button>
          )}
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {groups.map((group) => {
            const allIn = group.memberIds.every((id) => selectedIds.includes(id));
            return (
              <button
                key={group.id}
                type="button"
                onClick={() => onSelectGroup(group)}
                className={cn(
                  'shrink-0 flex items-center gap-2 px-3 py-2 rounded-full border text-xs font-bold transition',
                  allIn
                    ? 'bg-[#1ED760]/20 border-[#1ED760] text-[#1ED760]'
                    : 'bg-[#181818] border-white/10 text-white hover:bg-[#282828]'
                )}
              >
                <Users className="w-3.5 h-3.5" />
                <span>{group.name}</span>
                <span className="opacity-75">({group.memberIds.length})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selecteerbare vrienden avatars */}
      <div className="space-y-2">
        <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
          Kies vrienden ({filtered.length})
        </p>

        <div className="grid grid-cols-3 gap-2.5">
          {filtered.map((friend) => {
            const selected = selectedIds.includes(friend.id);
            return (
              <motion.button
                key={friend.id}
                type="button"
                whileTap={{ scale: 0.95 }}
                onClick={() => onToggleFriend(friend.id)}
                className={cn(
                  'relative flex flex-col items-center p-2.5 rounded-2xl border transition text-center',
                  selected
                    ? 'bg-[#1ED760]/12 border-[#1ED760] shadow-[0_0_0_1px_rgba(30,215,96,0.3)]'
                    : 'bg-[#181818] border-white/5 hover:bg-[#242424]'
                )}
                aria-pressed={selected}
              >
                <div className="relative">
                  <img
                    src={friend.avatar}
                    alt={friend.name}
                    className={cn(
                      'w-16 h-16 rounded-full object-cover transition-all',
                      selected ? 'ring-[3px] ring-[#1ED760] ring-offset-2 ring-offset-[#121212]' : 'ring-1 ring-white/15'
                    )}
                  />
                  {selected && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full bg-[#1ED760] text-black flex items-center justify-center ring-2 ring-[#121212] shadow"
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </motion.span>
                  )}
                </div>
                <p className="text-xs font-bold text-white mt-2 truncate w-full">{friend.name}</p>
                <p className="text-[10px] text-[#B3B3B3] truncate w-full">
                  {friend.favoriteGenres[0]}
                </p>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
