import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  ChevronDown,
  Info,
  Pause,
  Play,
  SlidersHorizontal,
  Sparkles,
  Users,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { FRIEND_BY_ID } from '../../data/mockData';
import { getVibePreset } from '../../engine/recommendationEngine';
import { VibeSelector } from './VibeSelector';
import { DiscoverySlider } from './DiscoverySlider';
import { MusicQueue } from './MusicQueue';
import { BottomSheet } from '../ui/BottomSheet';
import { cn } from '../../utils/cn';

interface GroupRadioPlayerProps {
  sessionId: string;
}

export const GroupRadioPlayer: React.FC<GroupRadioPlayerProps> = ({ sessionId }) => {
  const {
    sessions,
    activeSession,
    currentTrack,
    isPlaying,
    goBack,
    togglePlay,
    playSessionTrackAt,
    toggleSaveSession,
    updateSessionSettings,
    openWhyModal,
    setVotingSheetOpen,
    activeVoteState,
    navigate,
    showToast,
  } = useApp();

  const [tuningSheetOpen, setTuningSheetOpen] = useState(false);

  const session = sessions[sessionId] ?? activeSession;

  const members = useMemo(() => {
    if (!session) return [];
    return session.memberIds
      .map((id) => FRIEND_BY_ID[id])
      .filter((f): f is NonNullable<typeof f> => Boolean(f));
  }, [session]);

  if (!session) {
    return (
      <div className="p-6 text-center space-y-3">
        <p className="text-sm text-[#B3B3B3]">Geen actieve groepsradio gevonden.</p>
        <button
          type="button"
          onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
          className="px-4 py-2 rounded-full bg-[#1ED760] text-black text-xs font-bold"
        >
          Maak een vriendenradio
        </button>
      </div>
    );
  }

  const currentEntry = session.queue[session.currentIndex] ?? session.queue[0];
  const displayTrack = currentEntry?.track ?? currentTrack;
  const vibe = getVibePreset(session.vibe);
  const isPlayingThisRadio = isPlaying && activeSession?.id === session.id;

  const totalMembers = session.memberIds.length + (session.includeSelf ? 1 : 0);
  const currentLikeCount = activeVoteState?.likesByTrackId[displayTrack.id]?.count ?? 0;
  const suggestionCount = activeVoteState?.suggestions.length ?? 0;

  return (
    <div className="min-h-full bg-gradient-to-b from-[#1E3B27] via-[#121212] via-30% to-[#121212] pb-6">
      {/* 1. Rustige Top Navigatiebalk */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-4 py-3 bg-[#121212]/80 backdrop-blur-md border-b border-white/5">
        <button
          type="button"
          onClick={goBack}
          aria-label="Terug"
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white active:scale-95 transition"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <span className="text-xs font-bold text-white/90 truncate max-w-[200px]">
          {session.title}
        </span>

        <button
          type="button"
          onClick={() => toggleSaveSession(session.id)}
          aria-label={session.isSaved ? 'Verwijder uit bibliotheek' : 'Sla radio op'}
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white active:scale-95 transition"
        >
          <Bookmark
            className={cn('w-4 h-4', session.isSaved ? 'fill-[#1ED760] text-[#1ED760]' : '')}
          />
        </button>
      </div>

      <div className="px-4 pt-3 space-y-5">
        {/* 2. Hero Header in Spotify-stijl */}
        <div className="flex items-end gap-3.5 pt-1">
          <img
            src={session.coverArtwork}
            alt={session.title}
            className="w-28 h-28 rounded-xl object-cover shadow-2xl border border-white/10 shrink-0"
          />

          <div className="min-w-0 flex-1 space-y-1">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#1ED760]">
              Groepsradio
            </span>
            <h1 className="text-xl font-extrabold text-white leading-tight truncate">
              {session.title}
            </h1>
            <p className="text-xs text-[#B3B3B3] truncate">
              Mix van {totalMembers} leden
            </p>

            {/* Overlappende avatars */}
            <div className="flex items-center gap-1.5 pt-1">
              <div className="flex -space-x-1.5 overflow-hidden">
                {members.slice(0, 5).map((m) => (
                  <img
                    key={m.id}
                    src={m.avatar}
                    alt={m.name}
                    className="w-5 h-5 rounded-full ring-1 ring-[#121212] object-cover"
                  />
                ))}
              </div>
              {members.length > 5 && (
                <span className="text-[10px] font-bold text-[#B3B3B3]">
                  +{members.length - 5}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* 3. Hoofdactiebalk: Grote groene knop + 2 overzichtelijke pills */}
        <div className="flex items-center justify-between gap-3 pt-1">
          {/* Sfeer-pill & Groepsactiviteit-pill */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar min-w-0">
            {/* Pill 1: Sfeer & Instellingen */}
            <button
              type="button"
              onClick={() => setTuningSheetOpen(true)}
              className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/15 active:scale-95 text-xs font-semibold text-white inline-flex items-center gap-1.5 border border-white/10 transition shrink-0"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#1ED760]" />
              <span className="truncate max-w-[110px]">{vibe.label}</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#B3B3B3]" />
            </button>

            {/* Pill 2: Groepsstemmen */}
            <button
              type="button"
              onClick={() => setVotingSheetOpen(true)}
              className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/15 active:scale-95 text-xs font-semibold text-white inline-flex items-center gap-1.5 border border-white/10 transition shrink-0"
            >
              <Users className="w-3.5 h-3.5 text-[#1ED760]" />
              <span>
                Groep {currentLikeCount > 0 ? `(${currentLikeCount})` : ''}
              </span>
            </button>
          </div>

          {/* Grote iconische Spotify Play/Pause cirkelknop */}
          <button
            type="button"
            onClick={() => {
              if (activeSession?.id !== session.id) {
                playSessionTrackAt(session.id, session.currentIndex);
              } else {
                togglePlay();
              }
            }}
            aria-label={isPlayingThisRadio ? 'Pauzeer' : 'Speel af'}
            className="w-13 h-13 w-[50px] h-[50px] rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-95 text-black flex items-center justify-center shadow-lg transition shrink-0"
          >
            {isPlayingThisRadio ? (
              <Pause className="w-6 h-6 fill-black" />
            ) : (
              <Play className="w-6 h-6 fill-black ml-0.5" />
            )}
          </button>
        </div>

        {/* 4. Subtiele "Speelt nu" strook (geen dubbele drukke spelerbediening) */}
        {currentEntry && isPlayingThisRadio && (
          <div className="flex items-center justify-between gap-3 px-3 py-2 rounded-xl bg-[#1ED760]/10 border border-[#1ED760]/30 animate-[fadeIn_0.2s_ease-out]">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-[#1ED760] animate-pulse shrink-0" />
              <p className="text-xs text-white truncate">
                <span className="font-bold text-[#1ED760]">Speelt nu:</span>{' '}
                <span className="font-semibold">{displayTrack.title}</span> • {displayTrack.artist}
              </p>
            </div>
            <button
              type="button"
              onClick={() => openWhyModal(currentEntry)}
              className="text-[11px] font-bold text-[#1ED760] hover:underline shrink-0"
            >
              Waarom?
            </button>
          </div>
        )}

        {/* 5. De Wachtrij: Rustige, overzichtelijke Spotify-lijst */}
        <section className="space-y-2 pt-1">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Wachtrij ({session.queue.length} nummers)
            </h2>
            <button
              type="button"
              onClick={() => setTuningSheetOpen(true)}
              className="text-xs font-semibold text-[#1ED760] hover:underline inline-flex items-center gap-1"
            >
              <SlidersHorizontal className="w-3 h-3" />
              Sfeer aanpassen
            </button>
          </div>

          <MusicQueue
            queue={session.queue}
            currentIndex={session.currentIndex}
            isPlaying={isPlayingThisRadio}
            onPlayIndex={(idx) => playSessionTrackAt(session.id, idx)}
            onOpenWhy={(entry) => openWhyModal(entry)}
          />
        </section>
      </div>

      {/* 6. Gefocuste "Sfeer & Mix afstemmen" BottomSheet (Progressive Disclosure) */}
      <BottomSheet
        open={tuningSheetOpen}
        onClose={() => setTuningSheetOpen(false)}
        title="Sfeer & Mix afstemmen"
        subtitle={`${session.title} • Aanbevelingen worden direct bijgewerkt`}
      >
        <div className="space-y-5 pb-2">
          {/* Sfeerkiezer */}
          <div className="space-y-2.5">
            <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Kies de sfeer
            </p>
            <VibeSelector
              selectedVibe={session.vibe}
              onSelectVibe={(nextVibe) => {
                updateSessionSettings(session.id, { vibe: nextVibe });
                showToast(`Sfeer gewijzigd naar ${getVibePreset(nextVibe).label}`);
              }}
            />
          </div>

          {/* Ontdekkingsschuif & Eerlijkheids-toggle */}
          <div className="space-y-2.5 pt-1">
            <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Verfijning
            </p>
            <DiscoverySlider
              value={session.discoveryLevel}
              onChange={(val) => updateSessionSettings(session.id, { discoveryLevel: val })}
              equalInfluence={session.equalInfluence}
              onToggleEqualInfluence={(val) =>
                updateSessionSettings(session.id, { equalInfluence: val })
              }
            />
          </div>

          <button
            type="button"
            onClick={() => setTuningSheetOpen(false)}
            className="w-full py-3 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] text-black font-extrabold text-sm transition"
          >
            Klaar
          </button>
        </div>
      </BottomSheet>
    </div>
  );
};
