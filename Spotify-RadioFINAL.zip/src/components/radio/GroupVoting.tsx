import React, { useMemo, useState } from 'react';
import {
  ArrowBigUp,
  Bookmark,
  Plus,
  Search,
  Settings2,
  SkipForward,
  Sparkles,
  ThumbsUp,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TRACKS, TRACK_BY_ID } from '../../data/mockData';
import { BottomSheet } from '../ui/BottomSheet';
import { cn } from '../../utils/cn';

export const GroupVoting: React.FC = () => {
  const {
    votingSheetOpen,
    setVotingSheetOpen,
    activeSession,
    activeVoteState,
    currentTrack,
    likedTrackIds,
    toggleLikeTrack,
    toggleGroupTrackLike,
    voteSkipTrack,
    suggestTrackToSession,
    voteForSuggestion,
    updateVotingRules,
    simulateTeamActivity,
  } = useApp();

  const [suggestQuery, setSuggestQuery] = useState('');
  const [showAdminRules, setShowAdminRules] = useState(false);

  const searchSuggestions = useMemo(() => {
    const q = suggestQuery.trim().toLowerCase();
    if (!q) return TRACKS.slice(0, 5);
    return TRACKS.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.artist.toLowerCase().includes(q) ||
        t.genre.toLowerCase().includes(q)
    ).slice(0, 6);
  }, [suggestQuery]);

  if (!activeSession || !activeVoteState) return null;

  const totalMembers = activeSession.memberIds.length + (activeSession.includeSelf ? 1 : 0);
  const likeInfo = activeVoteState.likesByTrackId[currentTrack.id] ?? {
    count: 0,
    userLiked: false,
    likerIds: [],
  };
  const skipInfo = activeVoteState.skipVotesByTrackId[currentTrack.id] ?? {
    count: 0,
    userVoted: false,
  };
  const remainingSkips = Math.max(0, activeVoteState.rules.skipThreshold - skipInfo.count);
  const isSavedInLib = likedTrackIds.includes(currentTrack.id);

  return (
    <BottomSheet
      open={votingSheetOpen}
      onClose={() => setVotingSheetOpen(false)}
      title="Live groepsactiviteit"
      subtitle={`${activeSession.title} • Gesimuleerde lokale groepsstaat`}
    >
      <div className="space-y-5 pb-4">
        {/* Huidig nummer interacties */}
        <div className="rounded-2xl bg-[#222222] border border-white/10 p-3.5 space-y-3">
          <div className="flex items-center gap-3">
            <img
              src={currentTrack.albumArtwork}
              alt={currentTrack.title}
              className="w-12 h-12 rounded-lg object-cover shrink-0"
            />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-extrabold text-white truncate">{currentTrack.title}</p>
              <p className="text-xs text-[#B3B3B3] truncate">{currentTrack.artist}</p>
            </div>
            <button
              type="button"
              onClick={() => toggleLikeTrack(currentTrack.id)}
              aria-label="Opslaan in je bibliotheek"
              className={cn(
                'px-2.5 py-1.5 rounded-full text-[11px] font-bold inline-flex items-center gap-1 transition',
                isSavedInLib
                  ? 'bg-[#1ED760]/20 text-[#1ED760]'
                  : 'bg-white/10 text-white hover:bg-white/20'
              )}
            >
              <Bookmark className={cn('w-3.5 h-3.5', isSavedInLib && 'fill-[#1ED760]')} />
              <span>{isSavedInLib ? 'Opgeslagen' : 'Bewaar'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => toggleGroupTrackLike(activeSession.id, currentTrack.id)}
              className={cn(
                'py-2.5 px-3 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 border transition',
                likeInfo.userLiked
                  ? 'bg-[#1ED760]/20 border-[#1ED760] text-[#1ED760]'
                  : 'bg-[#2A2A2A] border-white/5 text-white hover:bg-[#333333]'
              )}
            >
              <ThumbsUp className="w-3.5 h-3.5" />
              <span>Vind ik leuk ({likeInfo.count})</span>
            </button>

            <button
              type="button"
              disabled={skipInfo.userVoted}
              onClick={() => voteSkipTrack(activeSession.id, currentTrack.id)}
              className={cn(
                'py-2.5 px-3 rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 border transition',
                skipInfo.userVoted
                  ? 'bg-orange-500/20 border-orange-400 text-orange-300'
                  : 'bg-[#2A2A2A] border-white/5 text-white hover:bg-[#333333]'
              )}
            >
              <SkipForward className="w-3.5 h-3.5" />
              <span>
                {skipInfo.userVoted
                  ? `Gestemd (${skipInfo.count}/${activeVoteState.rules.skipThreshold})`
                  : 'Stem om te skippen'}
              </span>
            </button>
          </div>

          <div className="text-[11px] text-[#D1D5DB] space-y-1 pt-0.5">
            <p>
              •{' '}
              <strong>
                {likeInfo.count} van de {totalMembers}{' '}
                {activeSession.title.includes('Zaterdag') ? 'spelers' : 'leden'}
              </strong>{' '}
              vinden dit nummer leuk.
            </p>
            <p>
              • Nog <strong>{remainingSkips} stemmen</strong> nodig om over te slaan (drempel:{' '}
              {activeVoteState.rules.skipThreshold}).
            </p>
          </div>
        </div>

        {/* Voorgestelde nummers & stemmen */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Voorgesteld door groepsleden
            </p>
            <button
              type="button"
              onClick={() => simulateTeamActivity(activeSession.id)}
              className="text-[11px] font-bold text-[#1ED760] inline-flex items-center gap-1 hover:underline"
            >
              <Sparkles className="w-3 h-3" />
              Simuleer stemmen
            </button>
          </div>

          <div className="space-y-2">
            {activeVoteState.suggestions.map((sug) => {
              const track = TRACK_BY_ID[sug.trackId];
              if (!track) return null;
              return (
                <div
                  key={sug.id}
                  className="flex items-center gap-3 p-2.5 rounded-xl bg-[#202020] border border-white/5"
                >
                  <img
                    src={track.albumArtwork}
                    alt={track.title}
                    className="w-10 h-10 rounded-md object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-white truncate">{track.title}</p>
                    <p className="text-[11px] text-[#B3B3B3] truncate">
                      {sug.votes} {sug.votes === 1 ? 'lid heeft' : 'leden hebben'} dit voorgesteld
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => voteForSuggestion(activeSession.id, sug.id)}
                    className={cn(
                      'px-2.5 py-1.5 rounded-full text-xs font-extrabold inline-flex items-center gap-1 border transition shrink-0',
                      sug.userVoted
                        ? 'bg-[#1ED760] border-[#1ED760] text-black'
                        : 'bg-[#2A2A2A] border-white/10 text-white hover:bg-[#333333]'
                    )}
                  >
                    <ArrowBigUp className="w-4 h-4" />
                    <span>{sug.votes}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Nieuw nummer voorstellen */}
        {activeVoteState.rules.allowSuggestions && (
          <div className="space-y-2.5">
            <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
              Stel een nummer voor
            </p>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#B3B3B3] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                value={suggestQuery}
                onChange={(e) => setSuggestQuery(e.target.value)}
                placeholder="Zoek nummer om voor te stellen..."
                className="w-full rounded-xl bg-[#282828] border border-white/10 pl-9 pr-3 py-2 text-xs text-white placeholder:text-[#B3B3B3] focus:outline-none focus:ring-2 focus:ring-[#1ED760]"
              />
            </div>

            <div className="space-y-1.5 max-h-40 overflow-y-auto">
              {searchSuggestions.map((track) => (
                <div
                  key={track.id}
                  className="flex items-center justify-between gap-2 p-2 rounded-xl bg-[#1C1C1C] hover:bg-[#262626]"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={track.albumArtwork}
                      alt={track.title}
                      className="w-9 h-9 rounded object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">{track.title}</p>
                      <p className="text-[10px] text-[#B3B3B3] truncate">{track.artist}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => suggestTrackToSession(activeSession.id, track.id)}
                    className="px-2.5 py-1 rounded-full bg-[#1ED760]/15 text-[#1ED760] hover:bg-[#1ED760] hover:text-black text-[11px] font-bold inline-flex items-center gap-1 shrink-0 transition"
                  >
                    <Plus className="w-3 h-3" />
                    Voorstellen
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Beheerder stemregels */}
        <div className="border-t border-white/10 pt-3">
          <button
            type="button"
            onClick={() => setShowAdminRules((s) => !s)}
            className="w-full flex items-center justify-between text-xs font-bold text-[#B3B3B3] hover:text-white"
          >
            <span className="inline-flex items-center gap-1.5">
              <Settings2 className="w-3.5 h-3.5" />
              Stemregels (groepsbeheerder)
            </span>
            <span>{showAdminRules ? 'Verberg' : 'Aanpassen'}</span>
          </button>

          {showAdminRules && (
            <div className="mt-3 space-y-3 rounded-xl bg-[#202020] p-3 text-xs">
              <div className="flex items-center justify-between">
                <span>Stemmen nodig om over te slaan</span>
                <div className="flex items-center gap-1.5">
                  {[2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => updateVotingRules(activeSession.id, { skipThreshold: n })}
                      className={cn(
                        'w-7 h-7 rounded-full font-bold transition',
                        activeVoteState.rules.skipThreshold === n
                          ? 'bg-[#1ED760] text-black'
                          : 'bg-[#2A2A2A] text-white'
                      )}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span>Leden mogen nummers voorstellen</span>
                <button
                  type="button"
                  onClick={() =>
                    updateVotingRules(activeSession.id, {
                      allowSuggestions: !activeVoteState.rules.allowSuggestions,
                    })
                  }
                  className={cn(
                    'px-3 py-1 rounded-full font-bold',
                    activeVoteState.rules.allowSuggestions
                      ? 'bg-[#1ED760] text-black'
                      : 'bg-[#2A2A2A] text-[#B3B3B3]'
                  )}
                >
                  {activeVoteState.rules.allowSuggestions ? 'Aan' : 'Uit'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </BottomSheet>
  );
};
