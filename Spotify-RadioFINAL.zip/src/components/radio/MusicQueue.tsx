import React from 'react';
import { Info, Play } from 'lucide-react';
import { RecommendedTrack } from '../../types/music';
import { FRIEND_BY_ID } from '../../data/mockData';
import { formatTime } from '../../utils/formatTime';
import { cn } from '../../utils/cn';
import { AudioWaveform } from '../player/AudioWaveform';

interface MusicQueueProps {
  queue: RecommendedTrack[];
  currentIndex: number;
  isPlaying: boolean;
  onPlayIndex: (idx: number) => void;
  onOpenWhy: (entry: RecommendedTrack) => void;
}

export const MusicQueue: React.FC<MusicQueueProps> = ({
  queue,
  currentIndex,
  isPlaying,
  onPlayIndex,
  onOpenWhy,
}) => {
  return (
    <div className="divide-y divide-white/[0.04]">
      {queue.map((entry, idx) => {
        const isCurrent = idx === currentIndex;
        const avatars = entry.contributingFriendIds
          .slice(0, 2)
          .map((id) => FRIEND_BY_ID[id])
          .filter(Boolean);

        // Korte, bondige sociale tag voor een rustige lijst
        const shortSocialTag = (() => {
          if (entry.unfamiliarCount >= Math.ceil(entry.totalMembers * 0.65)) {
            return `Nieuwe ontdekking`;
          }
          if (avatars.length >= 2) {
            return `${avatars[0].name} & ${avatars[1].name}`;
          }
          if (avatars.length === 1) {
            return `${avatars[0].name}'s favoriet`;
          }
          return 'Teamfavoriet';
        })();

        return (
          <div
            key={entry.track.id}
            className={cn(
              'flex items-center gap-3 py-2.5 px-2 rounded-xl transition group',
              isCurrent ? 'bg-[#1ED760]/10' : 'hover:bg-white/[0.04]'
            )}
          >
            {/* Nummer-index / Albumcover met afspeelknop */}
            <button
              type="button"
              onClick={() => onPlayIndex(idx)}
              className="relative w-11 h-11 rounded-md overflow-hidden shrink-0 group/cover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1ED760]"
              aria-label={`Speel ${entry.track.title}`}
            >
              <img
                src={entry.track.albumArtwork}
                alt={entry.track.title}
                className="w-full h-full object-cover"
              />
              <div
                className={cn(
                  'absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity',
                  isCurrent ? 'opacity-100' : 'opacity-0 group-hover/cover:opacity-100'
                )}
              >
                {isCurrent ? (
                  <AudioWaveform isPlaying={isPlaying} bars={3} className="h-4" />
                ) : (
                  <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                )}
              </div>
            </button>

            {/* Titel, artiest & subtiele sociale tag */}
            <button
              type="button"
              onClick={() => onPlayIndex(idx)}
              className="min-w-0 flex-1 text-left focus-visible:outline-none"
            >
              <p
                className={cn(
                  'text-sm font-semibold truncate leading-tight',
                  isCurrent ? 'text-[#1ED760]' : 'text-white'
                )}
              >
                {entry.track.title}
              </p>
              <p className="text-xs text-[#B3B3B3] truncate mt-0.5 leading-tight">
                {entry.track.artist}
              </p>

              {/* Subtiel sociaal label: compact, geen lange paragraaf */}
              <div className="flex items-center gap-1.5 mt-1">
                {avatars.length > 0 && (
                  <div className="flex -space-x-1 shrink-0">
                    {avatars.map((f) => (
                      <img
                        key={f.id}
                        src={f.avatar}
                        alt={f.name}
                        className="w-3.5 h-3.5 rounded-full ring-1 ring-[#121212] object-cover"
                      />
                    ))}
                  </div>
                )}
                <span className="text-[11px] font-medium text-[#1ED760]/90 truncate">
                  ✦ {shortSocialTag}
                </span>
              </div>
            </button>

            {/* Duur & Info-knop voor Waarom dit nummer */}
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-[#727272] tabular-nums font-medium">
                {formatTime(entry.track.duration)}
              </span>
              <button
                type="button"
                onClick={() => onOpenWhy(entry)}
                aria-label={`Waarom ${entry.track.title}?`}
                title="Waarom dit nummer?"
                className="w-8 h-8 rounded-full flex items-center justify-center text-[#727272] hover:text-[#1ED760] hover:bg-white/10 active:scale-95 transition"
              >
                <Info className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
