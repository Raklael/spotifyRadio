import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Radio, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';
import { FRIEND_BY_ID } from '../../data/mockData';
import { generateRadioQueue, getVibePreset } from '../../engine/recommendationEngine';
import { Group, VibeId } from '../../types/music';
import { FriendSelector } from './FriendSelector';
import { VibeSelector } from './VibeSelector';
import { DiscoverySlider } from './DiscoverySlider';
import { AudioWaveform } from '../player/AudioWaveform';
import { cn } from '../../utils/cn';

interface RadioBuilderProps {
  preselectedFriendIds?: string[];
  preselectedGroupId?: string;
  initialStep?: 1 | 2 | 3 | 4;
}

export const RadioBuilder: React.FC<RadioBuilderProps> = ({
  preselectedFriendIds,
  preselectedGroupId,
  initialStep = 1,
}) => {
  const {
    currentUser,
    friends,
    groups,
    goBack,
    createAndStartRadio,
  } = useApp();

  const initialGroup = preselectedGroupId
    ? groups.find((g) => g.id === preselectedGroupId)
    : undefined;

  const [step, setStep] = useState<1 | 2 | 3 | 4>(initialStep);
  const [selectedIds, setSelectedIds] = useState<string[]>(() => {
    if (initialGroup) return initialGroup.memberIds;
    if (preselectedFriendIds && preselectedFriendIds.length > 0) return preselectedFriendIds;
    return ['f-milan', 'f-thomas', 'f-lisa', 'f-daan', 'f-bram', 'f-niels'];
  });
  const [selectedGroupId, setSelectedGroupId] = useState<string | undefined>(preselectedGroupId);
  const [vibe, setVibe] = useState<VibeId>(initialGroup?.defaultVibe ?? 'derde-helft');
  const [discoveryLevel, setDiscoveryLevel] = useState<number>(
    initialGroup?.defaultDiscovery ?? 45
  );
  const [equalInfluence, setEqualInfluence] = useState<boolean>(
    initialGroup?.equalInfluence ?? true
  );
  const [isMerging, setIsMerging] = useState(true);

  const selectedFriends = useMemo(
    () =>
      selectedIds
        .map((id) => FRIEND_BY_ID[id])
        .filter((f): f is NonNullable<typeof f> => Boolean(f)),
    [selectedIds]
  );

  const activeGroup = useMemo(
    () =>
      selectedGroupId
        ? groups.find((g) => g.id === selectedGroupId)
        : groups.find(
            (g) =>
              g.memberIds.length === selectedIds.length &&
              g.memberIds.every((id) => selectedIds.includes(id))
          ),
    [groups, selectedGroupId, selectedIds]
  );

  const previewQueue = useMemo(() => {
    const members = [currentUser, ...selectedFriends];
    return generateRadioQueue({
      members,
      vibeId: vibe,
      discoveryLevel,
      equalInfluence,
      limit: 8,
      groupName: activeGroup?.name,
    });
  }, [activeGroup?.name, currentUser, discoveryLevel, equalInfluence, selectedFriends, vibe]);

  useEffect(() => {
    if (step !== 4) return;
    setIsMerging(true);
    const timer = window.setTimeout(() => setIsMerging(false), 1150);
    return () => window.clearTimeout(timer);
  }, [step]);

  const handleToggleFriend = (id: string) => {
    setSelectedGroupId(undefined);
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectGroup = (group: Group) => {
    setSelectedGroupId(group.id);
    setSelectedIds(group.memberIds);
    setVibe(group.defaultVibe);
  };

  const handleLaunchRadio = () => {
    const title = activeGroup
      ? `${activeGroup.name} Radio`
      : selectedFriends.length === 1
        ? `Radio met ${selectedFriends[0].name}`
        : `Vriendenradio (${selectedFriends.length})`;

    createAndStartRadio({
      title,
      sourceType: activeGroup ? 'group' : selectedFriends.length === 1 ? 'friend' : 'friends',
      sourceGroupId: activeGroup?.id,
      memberIds: selectedIds,
      vibe,
      discoveryLevel,
      equalInfluence,
      coverArtwork: activeGroup?.coverArtwork,
    });
  };

  const vibePreset = getVibePreset(vibe);

  return (
    <div className="min-h-full bg-gradient-to-b from-[#172B1E] via-[#121212] via-25% to-[#121212] flex flex-col">
      {/* Header + Stepper */}
      <header className="sticky top-0 z-20 bg-[#121212]/85 backdrop-blur-md px-4 pt-3 pb-3 border-b border-white/5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => (step > 1 ? setStep((s) => (s - 1) as 1 | 2 | 3 | 4) : goBack())}
            aria-label="Vorige stap"
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center">
            <h1 className="text-sm font-extrabold text-white">Maak een vriendenradio</h1>
            <p className="text-[11px] text-[#B3B3B3]">Stap {step} van 4</p>
          </div>

          <div className="w-9" />
        </div>

        {/* 4-step progress indicator */}
        <div className="grid grid-cols-4 gap-1.5">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className={cn(
                'h-1 rounded-full transition-colors',
                n <= step ? 'bg-[#1ED760]' : 'bg-white/15'
              )}
            />
          ))}
        </div>
      </header>

      {/* Step Content */}
      <div className="flex-1 px-4 pt-4 pb-24">
        {step === 1 && (
          <FriendSelector
            friends={friends}
            groups={groups}
            selectedIds={selectedIds}
            onToggleFriend={handleToggleFriend}
            onSelectGroup={handleSelectGroup}
            onClearAll={() => {
              setSelectedIds([]);
              setSelectedGroupId(undefined);
            }}
          />
        )}

        {step === 2 && (
          <VibeSelector selectedVibe={vibe} onSelectVibe={(v) => setVibe(v)} />
        )}

        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">Personaliseer je radio</h2>
              <p className="text-xs text-[#B3B3B3] mt-0.5">
                Pas aan hoeveel verrassingen jullie willen en hoe eerlijk iedereen meeweegt.
              </p>
            </div>

            <DiscoverySlider
              value={discoveryLevel}
              onChange={setDiscoveryLevel}
              equalInfluence={equalInfluence}
              onToggleEqualInfluence={setEqualInfluence}
            />

            {/* Live Preview van wat het algoritme kiest */}
            <div className="rounded-2xl bg-[#181818] border border-white/10 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#1ED760]" />
                  <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
                    Live voorproefje ({vibePreset.label})
                  </p>
                </div>
                <span className="text-[11px] font-bold text-[#1ED760]">
                  {selectedIds.length + 1} smaken
                </span>
              </div>

              <div className="space-y-2">
                {previewQueue.slice(0, 3).map((rec) => (
                  <div
                    key={rec.track.id}
                    className="flex items-center gap-2.5 p-2 rounded-xl bg-[#242424]/70"
                  >
                    <img
                      src={rec.track.albumArtwork}
                      alt={rec.track.title}
                      className="w-10 h-10 rounded-md object-cover shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-white truncate">{rec.track.title}</p>
                      <p className="text-[10px] text-[#B3B3B3] truncate">{rec.primaryReason}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col items-center text-center pt-4 space-y-6">
            {/* Animated overlapping cluster merging into waveform/collage */}
            <div className="relative w-56 h-44 flex items-center justify-center">
              <motion.div
                animate={isMerging ? { scale: [0.92, 1.06, 1] } : { scale: 1 }}
                transition={{ duration: 1.1, repeat: isMerging ? Infinity : 0 }}
                className="absolute inset-4 rounded-full bg-[#1ED760]/15 blur-2xl"
              />

              <div className="relative flex items-center justify-center">
                {[currentUser, ...selectedFriends.slice(0, 5)].map((person, idx, arr) => {
                  const angle = (idx / arr.length) * Math.PI * 2;
                  const radius = isMerging ? 54 : 26;
                  const x = Math.cos(angle) * radius;
                  const y = Math.sin(angle) * (radius * 0.65);

                  return (
                    <motion.img
                      key={person.id}
                      src={person.avatar}
                      alt={person.name}
                      initial={{ x: x * 1.4, y: y * 1.4, opacity: 0.4, scale: 0.8 }}
                      animate={{ x, y, opacity: 1, scale: 1 }}
                      transition={{ type: 'spring', stiffness: 140, damping: 14 }}
                      className="w-14 h-14 rounded-full object-cover ring-2 ring-[#1ED760] shadow-xl absolute"
                    />
                  );
                })}

                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="relative z-10 w-16 h-16 rounded-2xl bg-[#121212]/90 border-2 border-[#1ED760] flex flex-col items-center justify-center shadow-2xl"
                >
                  <AudioWaveform isPlaying={true} bars={5} className="h-6" />
                </motion.div>
              </div>
            </div>

            <div className="space-y-1.5">
              <h2 className="text-2xl font-extrabold tracking-tight">
                Jullie muzieksmaken komen samen
              </h2>
              <p className="text-xs text-[#B3B3B3] max-w-xs mx-auto">
                {isMerging
                  ? 'Favorieten, sfeermatch en eerlijke verdeling worden berekend...'
                  : `${previewQueue.length}+ nummers klaargezet voor ${
                      activeGroup ? activeGroup.name : `${selectedIds.length} vrienden en jou`
                    }.`}
              </p>
            </div>

            {/* Summary & Collage */}
            {!isMerging && (
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full space-y-4"
              >
                <div className="rounded-2xl bg-[#181818] border border-white/10 p-4 text-left space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-[#1ED760]">Klaar om af te spelen</p>
                      <p className="text-base font-extrabold text-white">
                        {activeGroup
                          ? `${activeGroup.name} Radio`
                          : selectedFriends.length === 1
                            ? `Radio met ${selectedFriends[0].name}`
                            : `Vriendenradio (${selectedFriends.length})`}
                      </p>
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-white/10 text-[11px] font-bold text-white">
                      {vibePreset.label}
                    </span>
                  </div>

                  {/* 4-album art collage */}
                  <div className="grid grid-cols-4 gap-2">
                    {previewQueue.slice(0, 4).map((rec) => (
                      <img
                        key={rec.track.id}
                        src={rec.track.albumArtwork}
                        alt={rec.track.title}
                        className="aspect-square rounded-lg object-cover shadow"
                      />
                    ))}
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-[#B3B3B3]">
                    <Check className="w-3.5 h-3.5 text-[#1ED760] shrink-0" />
                    <span>
                      {equalInfluence
                        ? 'Eerlijke invloed actief voor alle groepsleden'
                        : 'Focus op grootste gedeelde voorkeur'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleLaunchRadio}
                  className="w-full py-3.5 px-6 rounded-full bg-[#1ED760] hover:bg-[#1FDF64] active:scale-[0.98] text-black font-extrabold text-sm inline-flex items-center justify-center gap-2 shadow-xl transition"
                >
                  <Radio className="w-4 h-4" />
                  Start onze Radio
                </button>
              </motion.div>
            )}
          </div>
        )}
      </div>

      {/* Sticky Bottom CTA for Steps 1-3 */}
      {step < 4 && (
        <div className="sticky bottom-16 z-20 px-4 py-3 bg-gradient-to-t from-[#121212] via-[#121212]/95 to-transparent">
          <button
            type="button"
            disabled={step === 1 && selectedIds.length === 0}
            onClick={() => setStep((s) => (s + 1) as 1 | 2 | 3 | 4)}
            className={cn(
              'w-full py-3.5 px-5 rounded-full font-extrabold text-sm inline-flex items-center justify-center gap-2 shadow-xl transition',
              step === 1 && selectedIds.length === 0
                ? 'bg-[#282828] text-[#727272] cursor-not-allowed'
                : 'bg-[#1ED760] hover:bg-[#1FDF64] active:scale-[0.98] text-black'
            )}
          >
            {step === 1 && (
              <>
                <span>
                  Verder met {selectedIds.length}{' '}
                  {selectedIds.length === 1 ? 'vriend' : 'vrienden'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
            {step === 2 && (
              <>
                <span>Volgende: Personaliseren</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
            {step === 3 && (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Genereer onze Radio</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
