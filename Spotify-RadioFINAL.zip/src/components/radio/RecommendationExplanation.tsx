import React from 'react';
import { CheckCircle2, Info, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { FRIEND_BY_ID } from '../../data/mockData';
import { computeMemberTrackAffinity } from '../../engine/recommendationEngine';
import { BottomSheet } from '../ui/BottomSheet';

export const RecommendationExplanation: React.FC = () => {
  const { whyTrack, closeWhyModal, currentUser } = useApp();

  if (!whyTrack) return null;

  const contributors = whyTrack.contributingFriendIds
    .map((id) => (id === 'user-self' ? currentUser : FRIEND_BY_ID[id]))
    .filter(Boolean);

  const { breakdown } = whyTrack;

  const factors = [
    {
      label: 'Groepssmaak match',
      value: breakdown.groupTasteMatch,
      weightPct: Math.round(breakdown.weights.groupTaste * 100),
    },
    {
      label: 'Sfeermatch',
      value: breakdown.vibeMatch,
      weightPct: Math.round(breakdown.weights.vibe * 100),
    },
    {
      label: 'Eerlijke verdeling',
      value: breakdown.fairnessScore,
      weightPct: Math.round(breakdown.weights.fairness * 100),
    },
    {
      label: 'Ontdekkingswaarde',
      value: breakdown.discoveryScore,
      weightPct: Math.round(breakdown.weights.discovery * 100),
    },
  ];

  return (
    <BottomSheet
      open={Boolean(whyTrack)}
      onClose={closeWhyModal}
      title="Waarom dit nummer?"
      subtitle="Transparante uitleg op basis van jullie voorkeuren"
    >
      <div className="space-y-5 pb-3">
        {/* Track Header */}
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-[#242424]">
          <img
            src={whyTrack.track.albumArtwork}
            alt={whyTrack.track.title}
            className="w-14 h-14 rounded-xl object-cover shrink-0"
          />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-extrabold text-white truncate">{whyTrack.track.title}</p>
            <p className="text-xs text-[#B3B3B3] truncate">
              {whyTrack.track.artist} • {whyTrack.track.genre}
            </p>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#1ED760] mt-1">
              <Sparkles className="w-3 h-3" />
              Aanbevelingsscore: {whyTrack.score}/100
            </span>
          </div>
        </div>

        {/* Belangrijkste redenen */}
        <div className="space-y-2">
          <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Redenen voor deze keuze
          </p>
          <ul className="space-y-2">
            {whyTrack.detailedReasons.map((reason, idx) => (
              <li
                key={idx}
                className="flex items-start gap-2.5 text-xs text-white bg-white/[0.04] rounded-xl p-2.5"
              >
                <CheckCircle2 className="w-4 h-4 text-[#1ED760] shrink-0 mt-0.5" />
                <span className="leading-snug">{reason}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Bijdragende groepsleden visualisatie */}
        <div className="space-y-2.5">
          <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Leden met de sterkste match
          </p>
          <div className="space-y-2 rounded-2xl bg-[#202020] p-3 border border-white/5">
            {contributors.map((member) => {
              const affPct = Math.round(computeMemberTrackAffinity(member, whyTrack.track) * 100);
              return (
                <div key={member.id} className="flex items-center gap-2.5">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-8 h-8 rounded-full object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between text-xs mb-1">
                      <span className="font-bold text-white truncate">{member.name}</span>
                      <span className="text-[#1ED760] font-bold">{affPct}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#1ED760]"
                        style={{ width: `${affPct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Gewogen scoringsmodel uitleg */}
        <div className="space-y-2">
          <p className="text-xs font-extrabold uppercase tracking-wider text-[#B3B3B3]">
            Opbouw van de score
          </p>
          <div className="grid grid-cols-2 gap-2">
            {factors.map((f) => (
              <div key={f.label} className="rounded-xl bg-[#202020] p-2.5 border border-white/5">
                <p className="text-[11px] text-[#B3B3B3]">{f.label}</p>
                <div className="flex items-baseline justify-between mt-0.5">
                  <span className="text-sm font-extrabold text-white">
                    {Math.round(f.value * 100)}%
                  </span>
                  <span className="text-[10px] text-[#1ED760] font-semibold">
                    weging {f.weightPct}%
                  </span>
                </div>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-[#727272] flex items-start gap-1.5 leading-relaxed pt-1">
            <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>
              Deze wegingen zijn transparante ontwerpaannames op lokale demodata (geen getraind
              ML-model) en veranderen direct mee met de gekozen sfeer en ontdekkingsschuif.
            </span>
          </p>
        </div>
      </div>
    </BottomSheet>
  );
};
