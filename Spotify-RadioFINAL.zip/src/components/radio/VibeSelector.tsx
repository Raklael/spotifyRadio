import React from 'react';
import { Car, Check, Coffee, Compass, Flame, Sparkles, Trophy } from 'lucide-react';
import { VIBE_PRESETS } from '../../data/mockData';
import { VibeId } from '../../types/music';
import { cn } from '../../utils/cn';

interface VibeSelectorProps {
  selectedVibe: VibeId;
  onSelectVibe: (vibeId: VibeId) => void;
  compact?: boolean;
}

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Coffee,
  Flame,
  Trophy,
  Sparkles,
  Car,
  Compass,
};

export const VibeSelector: React.FC<VibeSelectorProps> = ({
  selectedVibe,
  onSelectVibe,
  compact = false,
}) => {
  if (compact) {
    return (
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {VIBE_PRESETS.map((vibe) => {
          const Icon = ICONS[vibe.iconName] ?? Sparkles;
          const active = selectedVibe === vibe.id;
          return (
            <button
              key={vibe.id}
              type="button"
              onClick={() => onSelectVibe(vibe.id)}
              className={cn(
                'shrink-0 px-3 py-2 rounded-full text-xs font-bold inline-flex items-center gap-1.5 border transition',
                active
                  ? 'bg-[#1ED760] border-[#1ED760] text-black shadow'
                  : 'bg-[#282828] border-white/10 text-white hover:bg-[#333333]'
              )}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{vibe.label}</span>
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div>
        <h2 className="text-xl font-extrabold tracking-tight">Wat is de sfeer?</h2>
        <p className="text-xs text-[#B3B3B3] mt-0.5">
          Elke sfeer stuurt het energie- en ontdekkingsniveau van de aanbevelingen bij.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-2.5">
        {VIBE_PRESETS.map((vibe) => {
          const Icon = ICONS[vibe.iconName] ?? Sparkles;
          const active = selectedVibe === vibe.id;
          return (
            <button
              key={vibe.id}
              type="button"
              onClick={() => onSelectVibe(vibe.id)}
              className={cn(
                'flex items-start gap-3.5 p-3.5 rounded-2xl border text-left transition active:scale-[0.99]',
                active
                  ? 'bg-[#1ED760]/12 border-[#1ED760]'
                  : 'bg-[#181818] border-white/10 hover:bg-[#242424]'
              )}
            >
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
                style={{
                  backgroundColor: active ? vibe.accentColor : `${vibe.accentColor}26`,
                  color: active ? '#000000' : vibe.accentColor,
                }}
              >
                <Icon className="w-5 h-5" />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-extrabold text-white">{vibe.label}</p>
                  {active && (
                    <span className="w-5 h-5 rounded-full bg-[#1ED760] text-black flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </span>
                  )}
                </div>
                <p className="text-xs font-semibold text-[#D1D5DB] mt-0.5">{vibe.shortDesc}</p>
                <p className="text-[11px] text-[#B3B3B3] mt-1 leading-snug">{vibe.impactDesc}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
