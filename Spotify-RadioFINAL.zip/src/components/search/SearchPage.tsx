import React, { useMemo, useState } from 'react';
import { Play, Radio, Search as SearchIcon, Users, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { TRACKS } from '../../data/mockData';
import { Genre } from '../../types/music';
import { getGenreAccent } from '../../utils/artwork';

const BROWSE_GENRES: { genre: Genre; label: string }[] = [
  { genre: 'Hip-hop', label: 'Hip-hop' },
  { genre: 'House & Techno', label: 'House & Techno' },
  { genre: 'Nederlandstalig', label: 'Nederlandstalig' },
  { genre: 'Feest', label: 'Derde Helft & Feest' },
  { genre: 'Pop', label: 'Pop' },
  { genre: 'Indie', label: 'Indie' },
  { genre: 'Dance & EDM', label: 'Dance & EDM' },
  { genre: 'Rock', label: 'Rock' },
  { genre: 'Hardstyle', label: 'Hardstyle' },
  { genre: 'R&B', label: 'R&B' },
];

export const SearchPage: React.FC = () => {
  const { friends, groups, playTrack, startTrackRadio, navigate } = useApp();
  const [query, setQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<Genre | null>(null);

  const normalized = query.trim().toLowerCase();

  const matchedFriends = useMemo(() => {
    if (!normalized) return [];
    return friends
      .filter(
        (f) =>
          f.name.toLowerCase().includes(normalized) ||
          f.favoriteGenres.some((g) => g.toLowerCase().includes(normalized)) ||
          f.favoriteArtists.some((a) => a.toLowerCase().includes(normalized))
      )
      .slice(0, 6);
  }, [friends, normalized]);

  const matchedGroups = useMemo(() => {
    if (!normalized) return [];
    return groups.filter((g) => g.name.toLowerCase().includes(normalized));
  }, [groups, normalized]);

  const matchedTracks = useMemo(() => {
    if (selectedGenre) {
      return TRACKS.filter((t) => t.genre === selectedGenre);
    }
    if (!normalized) return [];
    return TRACKS.filter(
      (t) =>
        t.title.toLowerCase().includes(normalized) ||
        t.artist.toLowerCase().includes(normalized) ||
        t.genre.toLowerCase().includes(normalized)
    ).slice(0, 20);
  }, [normalized, selectedGenre]);

  return (
    <div className="px-4 pt-5 pb-6 space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold tracking-tight">Zoeken</h1>
        <button
          type="button"
          onClick={() => navigate({ name: 'radio-builder', initialStep: 1 })}
          className="px-3 py-1.5 rounded-full bg-[#1ED760]/15 text-[#1ED760] text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#1ED760]/25 transition"
        >
          <Radio className="w-3.5 h-3.5" />
          Vriendenradio
        </button>
      </div>

      {/* Zoekbalk */}
      <div className="relative">
        <SearchIcon className="w-4 h-4 text-black/70 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="search"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setSelectedGenre(null);
          }}
          placeholder="Wat wil je luisteren? Nummers, artiesten, vrienden..."
          aria-label="Zoek nummers, artiesten of vrienden"
          className="w-full rounded-lg bg-white text-black placeholder:text-black/60 pl-10 pr-9 py-3 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#1ED760]"
        />
        {(query || selectedGenre) && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setSelectedGenre(null);
            }}
            aria-label="Wis zoekopdracht"
            className="absolute right-2.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full hover:bg-black/10 flex items-center justify-center text-black"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Actieve resultaten of genre-overzicht */}
      {normalized || selectedGenre ? (
        <div className="space-y-5">
          {selectedGenre && (
            <div className="flex items-center justify-between">
              <h2 className="text-base font-extrabold">Genre: {selectedGenre}</h2>
              <button
                type="button"
                onClick={() => setSelectedGenre(null)}
                className="text-xs font-bold text-[#1ED760]"
              >
                Terug naar genres
              </button>
            </div>
          )}

          {matchedFriends.length > 0 && (
            <div className="space-y-2">
              <h2 className="text-sm font-bold text-[#B3B3B3] uppercase tracking-wider">
                Vrienden
              </h2>
              <div className="space-y-2">
                {matchedFriends.map((friend) => (
                  <button
                    key={friend.id}
                    type="button"
                    onClick={() => navigate({ name: 'friend-profile', friendId: friend.id })}
                    className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
                  >
                    <img
                      src={friend.avatar}
                      alt={friend.name}
                      className="w-11 h-11 rounded-full object-cover shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-white truncate">{friend.fullName}</p>
                      <p className="text-xs text-[#B3B3B3] truncate">
                        {friend.favoriteGenres.join(' • ')}
                      </p>
                    </div>
                    <Users className="w-4 h-4 text-[#1ED760] shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {matchedGroups.length > 0 && (
            <div className="space-y-2">
              <h2 className="text-sm font-bold text-[#B3B3B3] uppercase tracking-wider">
                Groepen
              </h2>
              {matchedGroups.map((group) => (
                <button
                  key={group.id}
                  type="button"
                  onClick={() => navigate({ name: 'group-profile', groupId: group.id })}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-[#181818] hover:bg-[#282828] text-left transition"
                >
                  <img
                    src={group.coverArtwork}
                    alt={group.name}
                    className="w-11 h-11 rounded-lg object-cover shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white truncate">{group.name}</p>
                    <p className="text-xs text-[#B3B3B3]">{group.memberIds.length} leden</p>
                  </div>
                </button>
              ))}
            </div>
          )}

          <div className="space-y-2">
            <h2 className="text-sm font-bold text-[#B3B3B3] uppercase tracking-wider">
              Nummers ({matchedTracks.length})
            </h2>
            {matchedTracks.length === 0 ? (
              <p className="text-sm text-[#B3B3B3] py-6 text-center">
                Geen nummers gevonden voor &ldquo;{query}&rdquo;.
              </p>
            ) : (
              <div className="space-y-1.5">
                {matchedTracks.map((track) => (
                  <div
                    key={track.id}
                    className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#282828] text-left transition group"
                  >
                    <button
                      type="button"
                      onClick={() => playTrack(track.id, true)}
                      className="w-11 h-11 rounded-md overflow-hidden shrink-0"
                    >
                      <img
                        src={track.albumArtwork}
                        alt={track.title}
                        className="w-full h-full object-cover"
                      />
                    </button>
                    <button
                      type="button"
                      onClick={() => playTrack(track.id, true)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <p className="text-sm font-bold text-white truncate">{track.title}</p>
                      <p className="text-xs text-[#B3B3B3] truncate">
                        {track.artist} • {track.genre}
                      </p>
                    </button>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => startTrackRadio(track)}
                        title="Start Radio vanaf dit nummer"
                        className="px-2 py-1 rounded-full text-[11px] font-bold text-[#1ED760] bg-[#1ED760]/10 hover:bg-[#1ED760]/20 inline-flex items-center gap-1 transition"
                      >
                        <Radio className="w-3.5 h-3.5" />
                        <span>Radio</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => playTrack(track.id, true)}
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white hover:bg-white/10"
                        aria-label="Speel af"
                      >
                        <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <h2 className="text-base font-extrabold">Alles verkennen</h2>
          <div className="grid grid-cols-2 gap-3">
            {BROWSE_GENRES.map((item) => {
              const color = getGenreAccent(item.genre);
              return (
                <button
                  key={item.genre}
                  type="button"
                  onClick={() => setSelectedGenre(item.genre)}
                  className="relative overflow-hidden rounded-xl h-24 p-3 text-left transition active:scale-[0.98]"
                  style={{
                    background: `linear-gradient(135deg, ${color}CC 0%, ${color}55 100%)`,
                  }}
                >
                  <p className="text-sm font-extrabold text-white leading-tight max-w-[110px]">
                    {item.label}
                  </p>
                  <div className="absolute -bottom-3 -right-3 w-14 h-14 rounded-lg bg-black/25 rotate-12 border border-white/15" />
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
