import React, { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../utils/cn';

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidthClass?: string;
}

export const BottomSheet: React.FC<BottomSheetProps> = ({
  open,
  onClose,
  title,
  subtitle,
  children,
  maxWidthClass = 'max-w-[430px]',
}) => {
  const dialogRef = useRef<HTMLDialogElement | null>(null);
  const titleId = `sheet-title-${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;

    if (open && !dialog.open) {
      dialog.showModal();
    } else if (!open && dialog.open) {
      dialog.close();
    }
  }, [open]);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;

    const handleClose = () => {
      dialog.returnValue = '';
      onClose();
    };

    let pressedOutside = false;
    const isOutside = (e: PointerEvent) => {
      const r = dialog.getBoundingClientRect();
      return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom;
    };

    const handlePointerDown = (e: PointerEvent) => {
      pressedOutside = isOutside(e);
    };

    const handlePointerUp = (e: PointerEvent) => {
      if (pressedOutside && isOutside(e)) {
        dialog.close();
      }
      pressedOutside = false;
    };

    dialog.addEventListener('close', handleClose);
    dialog.addEventListener('pointerdown', handlePointerDown);
    dialog.addEventListener('pointerup', handlePointerUp);
    return () => {
      dialog.removeEventListener('close', handleClose);
      dialog.removeEventListener('pointerdown', handlePointerDown);
      dialog.removeEventListener('pointerup', handlePointerUp);
    };
  }, [onClose]);

  if (!open) return null;

  return (
    <dialog
      ref={dialogRef}
      aria-labelledby={titleId}
      className={cn(
        'fixed inset-x-0 bottom-0 top-auto m-0 mx-auto w-full rounded-t-3xl bg-[#181818] text-white shadow-2xl border-t border-white/10 p-0 max-h-[88dvh] overflow-hidden flex flex-col',
        'animate-[slideUp_220ms_cubic-bezier(0.22,1,0.36,1)]',
        maxWidthClass
      )}
    >
      <style>{`
        @keyframes slideUp {
          from { transform: translateY(28px); opacity: 0.6; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
      <div className="flex flex-col items-center pt-2.5 pb-2 px-5 border-b border-white/10 shrink-0">
        <div className="w-10 h-1 rounded-full bg-white/25 mb-3" />
        <div className="w-full flex items-start justify-between gap-3">
          <div>
            <h2 id={titleId} className="text-base font-bold tracking-tight text-white">
              {title}
            </h2>
            {subtitle && <p className="text-xs text-[#B3B3B3] mt-0.5">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={() => dialogRef.current?.close()}
            aria-label="Sluiten"
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="overflow-y-auto px-5 py-4 flex-1">{children}</div>
    </dialog>
  );
};
