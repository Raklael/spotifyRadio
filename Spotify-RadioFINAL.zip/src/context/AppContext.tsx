import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  ActiveTab,
  Friend,
  Group,
  GroupCoverTheme,
  GroupVoteState,
  PrivacySettings,
  RadioSession,
  RecommendedTrack,
  Track,
  VibeId,
  ViewRoute,
} from '../types/music';
import {
  CURRENT_USER,
  FRIENDS,
  FRIEND_BY_ID,
  HOME_PLAYLISTS,
  INITIAL_GROUPS,
  RECOMMENDED_ALBUMS,
  TRACKS,
  TRACK_BY_ID,
} from '../data/mockData';
import { generateRadioQueue, getVibePreset } from '../engine/recommendationEngine';
import { generateGroupCover, generateSpecialCover } from '../utils/artwork';
import { demoSynth } from '../utils/demoAudio';

const STORAGE_KEY = 'spotify-friends-radio-v2';

export type DeviceName = 'iPhone van Rafael' | 'Kleedkamer JBL Speaker' | 'Woonkamer Sonos';

interface PersistedState {
  groups: Group[];
  sessions: Record<string, RadioSession>;
  voteStates: Record<string, GroupVoteState>;
  likedTrackIds: string[];
  activeSessionId: string | null;
  currentTrackId: string;
  privacy: PrivacySettings;
  onboardingDismissed: boolean;
}

function buildInitialVoteState(session: RadioSession): GroupVoteState {
  const memberIds = session.memberIds;
  const firstTrack = session.queue[0]?.track;
  const likesByTrackId: GroupVoteState['likesByTrackId'] = {};

  if (firstTrack) {
    const initialLikers = memberIds.slice(0, Math.min(7, memberIds.length));
    likesByTrackId[firstTrack.id] = {
      count: initialLikers.length,
      userLiked: false,
      likerIds: initialLikers,
    };
  }

  // Seed 2 realistische groepssuggesties uit latere nummers of bekende feestnummers
  const suggestionSeeds = [
    { id: 'sug-1', trackId: 't028', suggestedByIds: memberIds.slice(0, 3), votes: 3, userVoted: false },
    { id: 'sug-2', trackId: 't095', suggestedByIds: memberIds.slice(2, 4), votes: 2, userVoted: false },
  ].filter((s) => TRACK_BY_ID[s.trackId] && s.trackId !== firstTrack?.id);

  return {
    likesByTrackId,
    skipVotesByTrackId: {},
    suggestions: suggestionSeeds,
    rules: {
      skipThreshold: Math.max(2, Math.min(5, Math.ceil(memberIds.length * 0.28))),
      allowSuggestions: true,
    },
  };
}

function createInitialPersistedState(): PersistedState {
  const fcGroup = INITIAL_GROUPS[0];
  const fcMembers = [
    CURRENT_USER,
    ...fcGroup.memberIds.map((id) => FRIEND_BY_ID[id]).filter((f): f is Friend => Boolean(f)),
  ];
  const initialQueue = generateRadioQueue({
    members: fcMembers,
    vibeId: fcGroup.defaultVibe,
    discoveryLevel: fcGroup.defaultDiscovery,
    equalInfluence: fcGroup.equalInfluence,
    groupName: fcGroup.name,
  });

  const initialSession: RadioSession = {
    id: 'session-fc-zaterdag-3',
    title: 'FC Zaterdag 3 Radio',
    subtitle: `Gebaseerd op ${fcGroup.memberIds.length} muzieksmaken`,
    sourceType: 'group',
    sourceGroupId: fcGroup.id,
    memberIds: fcGroup.memberIds,
    includeSelf: true,
    vibe: fcGroup.defaultVibe,
    discoveryLevel: fcGroup.defaultDiscovery,
    equalInfluence: fcGroup.equalInfluence,
    coverArtwork: fcGroup.coverArtwork,
    queue: initialQueue,
    currentIndex: 0,
    skippedTrackIds: [],
    playedTrackIds: [],
    createdAt: new Date().toISOString(),
    isSaved: true,
  };

  return {
    groups: INITIAL_GROUPS,
    sessions: { [initialSession.id]: initialSession },
    voteStates: { [initialSession.id]: buildInitialVoteState(initialSession) },
    likedTrackIds: [...CURRENT_USER.likedTracks],
    activeSessionId: initialSession.id,
    currentTrackId: initialQueue[0]?.track.id ?? TRACKS[0].id,
    privacy: {
      shareTasteWithFriends: false, // Opt-in privacy by default
      shareFavoriteGenres: true,
      shareLikedSongs: false,
      participateInGroupRadios: true,
    },
    onboardingDismissed: false,
  };
}

function loadPersistedState(): PersistedState {
  const fallback = createInitialPersistedState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    return {
      groups: parsed.groups && parsed.groups.length > 0 ? parsed.groups : fallback.groups,
      sessions: parsed.sessions && Object.keys(parsed.sessions).length > 0 ? parsed.sessions : fallback.sessions,
      voteStates: parsed.voteStates ?? fallback.voteStates,
      likedTrackIds: parsed.likedTrackIds ?? fallback.likedTrackIds,
      activeSessionId: parsed.activeSessionId ?? fallback.activeSessionId,
      currentTrackId: parsed.currentTrackId && TRACK_BY_ID[parsed.currentTrackId] ? parsed.currentTrackId : fallback.currentTrackId,
      privacy: { ...fallback.privacy, ...(parsed.privacy ?? {}) },
      onboardingDismissed: Boolean(parsed.onboardingDismissed),
    };
  } catch {
    return fallback;
  }
}

interface CreateRadioParams {
  title?: string;
  sourceType: 'friend' | 'friends' | 'group';
  sourceGroupId?: string;
  memberIds: string[];
  vibe: VibeId;
  discoveryLevel: number;
  equalInfluence: boolean;
  includeSelf?: boolean;
  coverArtwork?: string;
  openImmediately?: boolean;
}

interface AppContextValue {
  // Navigation
  route: ViewRoute;
  activeTab: ActiveTab;
  canGoBack: boolean;
  navigate: (next: ViewRoute) => void;
  switchTab: (tab: ActiveTab) => void;
  goBack: () => void;

  // Data
  currentUser: Friend;
  friends: Friend[];
  groups: Group[];
  sessions: Record<string, RadioSession>;
  activeSession: RadioSession | null;
  likedTrackIds: string[];

  // Playback
  currentTrack: Track;
  currentRecommendedEntry: RecommendedTrack | null;
  isPlaying: boolean;
  progressSec: number;
  shuffle: boolean;
  repeat: 'off' | 'all' | 'one';
  synthAudioEnabled: boolean;
  selectedDevice: DeviceName;
  fullPlayerOpen: boolean;
  setFullPlayerOpen: (open: boolean) => void;
  togglePlay: () => void;
  playTrack: (trackId: string, clearSession?: boolean) => void;
  playSessionTrackAt: (sessionId: string, index: number) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  seekTo: (sec: number) => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  toggleSynthAudio: () => void;
  setSelectedDevice: (d: DeviceName) => void;
  toggleLikeTrack: (trackId: string) => void;

  // Radio actions
  createAndStartRadio: (params: CreateRadioParams) => RadioSession;
  startTrackRadio: (track: Track, withFriends?: boolean) => RadioSession;
  getPlaylistData: (playlistId: string) => {
    id: string;
    title: string;
    subtitle: string;
    artwork: string;
    tracks: Track[];
    category?: string;
  } | null;
  updateSessionSettings: (
    sessionId: string,
    patch: Partial<Pick<RadioSession, 'vibe' | 'discoveryLevel' | 'equalInfluence'>>
  ) => void;
  toggleSaveSession: (sessionId: string) => void;

  // Voting & Social
  activeVoteState: GroupVoteState | null;
  toggleGroupTrackLike: (sessionId: string, trackId: string) => void;
  voteSkipTrack: (sessionId: string, trackId: string) => { skipped: boolean };
  suggestTrackToSession: (sessionId: string, trackId: string) => void;
  voteForSuggestion: (sessionId: string, suggestionId: string) => void;
  updateVotingRules: (sessionId: string, patch: Partial<GroupVoteState['rules']>) => void;
  simulateTeamActivity: (sessionId: string) => void;

  // Groups CRUD
  createGroup: (data: {
    name: string;
    description: string;
    memberIds: string[];
    coverTheme: GroupCoverTheme;
    defaultVibe: VibeId;
  }) => Group;
  updateGroup: (
    groupId: string,
    patch: Partial<Pick<Group, 'name' | 'description' | 'memberIds' | 'coverTheme' | 'defaultVibe' | 'defaultDiscovery' | 'equalInfluence'>>
  ) => void;

  // Modals & Sheets
  whyTrack: RecommendedTrack | null;
  openWhyModal: (entry: RecommendedTrack) => void;
  closeWhyModal: () => void;
  votingSheetOpen: boolean;
  setVotingSheetOpen: (open: boolean) => void;
  deviceSheetOpen: boolean;
  setDeviceSheetOpen: (open: boolean) => void;
  privacyModalOpen: boolean;
  setPrivacyModalOpen: (open: boolean) => void;
  onboardingOpen: boolean;
  dismissOnboarding: () => void;
  openOnboarding: () => void;
  privacy: PrivacySettings;
  updatePrivacy: (patch: Partial<PrivacySettings>) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [persisted, setPersisted] = useState<PersistedState>(loadPersistedState);
  const [navStack, setNavStack] = useState<ViewRoute[]>([{ name: 'tab', tab: 'home' }]);

  // Player UI state
  const [isPlaying, setIsPlaying] = useState(false);
  const [progressSec, setProgressSec] = useState(32);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<'off' | 'all' | 'one'>('off');
  const [synthAudioEnabled, setSynthAudioEnabled] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<DeviceName>('iPhone van Rafael');
  const [fullPlayerOpen, setFullPlayerOpen] = useState(false);

  // Modals & sheets
  const [whyTrack, setWhyTrack] = useState<RecommendedTrack | null>(null);
  const [votingSheetOpen, setVotingSheetOpen] = useState(false);
  const [deviceSheetOpen, setDeviceSheetOpen] = useState(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);
  const [onboardingOpen, setOnboardingOpen] = useState(() => !persisted.onboardingDismissed);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(persisted));
    } catch {
      // Negeer storage quota errors in demo
    }
  }, [persisted]);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const t = window.setTimeout(() => setToastMessage(null), 2800);
    return () => window.clearTimeout(t);
  }, [toastMessage]);

  const effectiveCurrentUser = useMemo<Friend>(() => {
    const { privacy } = persisted;
    return {
      ...CURRENT_USER,
      likedTracks: persisted.likedTrackIds,
      favoriteGenres:
        privacy.shareTasteWithFriends && privacy.shareFavoriteGenres
          ? CURRENT_USER.favoriteGenres
          : CURRENT_USER.favoriteGenres,
    };
  }, [persisted.likedTrackIds, persisted.privacy]);

  const getMembersForIds = useCallback(
    (memberIds: string[], includeSelf: boolean): Friend[] => {
      const resolved = memberIds
        .map((id) => FRIEND_BY_ID[id])
        .filter((f): f is Friend => Boolean(f));
      if (includeSelf && persisted.privacy.participateInGroupRadios) {
        return [effectiveCurrentUser, ...resolved.filter((f) => f.id !== 'user-self')];
      }
      return resolved.length > 0 ? resolved : [effectiveCurrentUser];
    },
    [effectiveCurrentUser, persisted.privacy.participateInGroupRadios]
  );

  const route = navStack[navStack.length - 1] ?? { name: 'tab', tab: 'home' };
  const activeTab: ActiveTab = useMemo(() => {
    for (let i = navStack.length - 1; i >= 0; i--) {
      const r = navStack[i];
      if (r.name === 'tab') return r.tab;
    }
    return 'home';
  }, [navStack]);

  const navigate = useCallback((next: ViewRoute) => {
    setNavStack((prev) => [...prev, next]);
  }, []);

  const switchTab = useCallback((tab: ActiveTab) => {
    setNavStack([{ name: 'tab', tab }]);
  }, []);

  const goBack = useCallback(() => {
    setNavStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  }, []);

  const activeSession = persisted.activeSessionId
    ? persisted.sessions[persisted.activeSessionId] ?? null
    : null;

  const currentTrack = TRACK_BY_ID[persisted.currentTrackId] ?? TRACKS[0];

  const currentRecommendedEntry = useMemo(() => {
    if (!activeSession) return null;
    return activeSession.queue.find((q) => q.track.id === currentTrack.id) ?? null;
  }, [activeSession, currentTrack.id]);

  // Web Audio demo synth sync
  useEffect(() => {
    if (isPlaying && synthAudioEnabled) {
      demoSynth.start(currentTrack);
    } else {
      demoSynth.stop();
    }
    return () => demoSynth.stop();
  }, [isPlaying, synthAudioEnabled, currentTrack]);

  const nextTrack = useCallback(() => {
    setPersisted((prev) => {
      const session = prev.activeSessionId ? prev.sessions[prev.activeSessionId] : null;
      if (session && session.queue.length > 0) {
        let nextIdx = session.currentIndex + 1;
        if (shuffle && session.queue.length > 2) {
          nextIdx = (session.currentIndex + 2) % session.queue.length;
        } else if (nextIdx >= session.queue.length) {
          nextIdx = repeat === 'all' ? 0 : 0;
        }
        const nextEntry = session.queue[nextIdx];
        const played = Array.from(new Set([...session.playedTrackIds, prev.currentTrackId]));
        return {
          ...prev,
          currentTrackId: nextEntry.track.id,
          sessions: {
            ...prev.sessions,
            [session.id]: {
              ...session,
              currentIndex: nextIdx,
              playedTrackIds: played,
            },
          },
        };
      }
      const idx = TRACKS.findIndex((t) => t.id === prev.currentTrackId);
      const next = TRACKS[(idx + 1) % TRACKS.length];
      return { ...prev, currentTrackId: next.id };
    });
    setProgressSec(0);
    setIsPlaying(true);
  }, [repeat, shuffle]);

  const prevTrack = useCallback(() => {
    if (progressSec > 5) {
      setProgressSec(0);
      return;
    }
    setPersisted((prev) => {
      const session = prev.activeSessionId ? prev.sessions[prev.activeSessionId] : null;
      if (session && session.queue.length > 0) {
        const prevIdx =
          (session.currentIndex - 1 + session.queue.length) % session.queue.length;
        return {
          ...prev,
          currentTrackId: session.queue[prevIdx].track.id,
          sessions: {
            ...prev.sessions,
            [session.id]: { ...session, currentIndex: prevIdx },
          },
        };
      }
      const idx = TRACKS.findIndex((t) => t.id === prev.currentTrackId);
      const previous = TRACKS[(idx - 1 + TRACKS.length) % TRACKS.length];
      return { ...prev, currentTrackId: previous.id };
    });
    setProgressSec(0);
  }, [progressSec]);

  // Playback progress timer
  useEffect(() => {
    if (!isPlaying) return;
    const interval = window.setInterval(() => {
      setProgressSec((prev) => {
        if (prev + 1 >= currentTrack.duration) {
          if (repeat === 'one') return 0;
          window.setTimeout(() => nextTrack(), 0);
          return 0;
        }
        return prev + 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isPlaying, currentTrack.duration, repeat, nextTrack]);

  const togglePlay = useCallback(() => setIsPlaying((p) => !p), []);
  const seekTo = useCallback((sec: number) => setProgressSec(sec), []);
  const toggleShuffle = useCallback(() => setShuffle((s) => !s), []);
  const cycleRepeat = useCallback(
    () => setRepeat((r) => (r === 'off' ? 'all' : r === 'all' ? 'one' : 'off')),
    []
  );
  const toggleSynthAudio = useCallback(() => {
    setSynthAudioEnabled((prev) => {
      const next = !prev;
      showToast(next ? 'Demo-audio (synth) ingeschakeld' : 'Demo-audio gedempt');
      return next;
    });
  }, [showToast]);

  const playTrack = useCallback((trackId: string, clearSession = false) => {
    setPersisted((prev) => ({
      ...prev,
      currentTrackId: trackId,
      activeSessionId: clearSession ? null : prev.activeSessionId,
    }));
    setProgressSec(0);
    setIsPlaying(true);
  }, []);

  const playSessionTrackAt = useCallback((sessionId: string, index: number) => {
    setPersisted((prev) => {
      const session = prev.sessions[sessionId];
      if (!session || !session.queue[index]) return prev;
      return {
        ...prev,
        activeSessionId: sessionId,
        currentTrackId: session.queue[index].track.id,
        sessions: {
          ...prev.sessions,
          [sessionId]: { ...session, currentIndex: index },
        },
      };
    });
    setProgressSec(0);
    setIsPlaying(true);
  }, []);

  const toggleLikeTrack = useCallback(
    (trackId: string) => {
      setPersisted((prev) => {
        const exists = prev.likedTrackIds.includes(trackId);
        const likedTrackIds = exists
          ? prev.likedTrackIds.filter((id) => id !== trackId)
          : [trackId, ...prev.likedTrackIds];
        showToast(exists ? 'Verwijderd uit gelikete nummers' : 'Opgeslagen in Nummers die je leuk vindt');
        return { ...prev, likedTrackIds };
      });
    },
    [showToast]
  );

  const createAndStartRadio = useCallback(
    (params: CreateRadioParams): RadioSession => {
      const includeSelf = params.includeSelf ?? true;
      const members = getMembersForIds(params.memberIds, includeSelf);
      const group = params.sourceGroupId
        ? persisted.groups.find((g) => g.id === params.sourceGroupId)
        : undefined;

      const resolvedTitle =
        params.title ??
        (group
          ? `${group.name} Radio`
          : params.memberIds.length === 1 && FRIEND_BY_ID[params.memberIds[0]]
            ? `Radio met ${FRIEND_BY_ID[params.memberIds[0]].name}`
            : `Vriendenradio (${params.memberIds.length})`);

      const subtitle =
        group
          ? `Gebaseerd op ${group.memberIds.length} muzieksmaken`
          : params.memberIds.length === 1 && FRIEND_BY_ID[params.memberIds[0]]
            ? `Jouw smaak + ${FRIEND_BY_ID[params.memberIds[0]].name}`
            : `Mix van ${members.length} muzieksmaken`;

      const queue = generateRadioQueue({
        members,
        vibeId: params.vibe,
        discoveryLevel: params.discoveryLevel,
        equalInfluence: params.equalInfluence,
        groupName: group?.name,
      });

      const id = `session-${Date.now()}`;
      const newSession: RadioSession = {
        id,
        title: resolvedTitle,
        subtitle,
        sourceType: params.sourceType,
        sourceGroupId: params.sourceGroupId,
        memberIds: params.memberIds,
        includeSelf,
        vibe: params.vibe,
        discoveryLevel: params.discoveryLevel,
        equalInfluence: params.equalInfluence,
        coverArtwork:
          params.coverArtwork ??
          group?.coverArtwork ??
          generateGroupCover(resolvedTitle, params.memberIds.length > 3 ? 'festival' : 'friends'),
        queue,
        currentIndex: 0,
        skippedTrackIds: [],
        playedTrackIds: [],
        createdAt: new Date().toISOString(),
        isSaved: Boolean(group),
      };

      const initialVote = buildInitialVoteState(newSession);

      setPersisted((prev) => ({
        ...prev,
        sessions: { ...prev.sessions, [id]: newSession },
        voteStates: { ...prev.voteStates, [id]: initialVote },
        activeSessionId: id,
        currentTrackId: queue[0]?.track.id ?? prev.currentTrackId,
      }));
      setProgressSec(0);
      setIsPlaying(true);

      if (params.openImmediately !== false) {
        navigate({ name: 'group-radio', sessionId: id });
      }

      return newSession;
    },
    [getMembersForIds, navigate, persisted.groups]
  );

  const startTrackRadio = useCallback(
    (track: Track, withFriends: boolean = true): RadioSession => {
      // Zoek vrienden die affiniteit hebben met dit genre, artiest of nummer
      let matchingFriends = FRIENDS.filter(
        (f) =>
          f.favoriteGenres.some((g) => g.toLowerCase() === track.genre.toLowerCase()) ||
          f.favoriteArtists.some((a) => a.toLowerCase() === track.artist.toLowerCase()) ||
          f.likedTracks.includes(track.id)
      );

      // Als er geen directe match is, pak 3 actieve vrienden
      if (matchingFriends.length === 0) {
        matchingFriends = FRIENDS.slice(0, 3);
      } else {
        matchingFriends = matchingFriends.slice(0, 4);
      }

      // Kies een passende vibe op basis van het genre van het nummer
      let vibe: VibeId = 'gewoon-gezellig';
      if (track.genre === 'House & Techno' || track.genre === 'Dance & EDM') {
        vibe = 'club';
      } else if (track.genre === 'Feest' || track.genre === 'Nederlandstalig') {
        vibe = 'derde-helft';
      } else if (track.genre === 'Rock') {
        vibe = 'festival';
      } else if (track.genre === 'Hip-hop') {
        vibe = 'voordrinken';
      } else if (track.genre === 'Indie' || track.genre === 'Pop') {
        vibe = 'roadtrip';
      }

      const members = [CURRENT_USER, ...(withFriends ? matchingFriends : [])];
      const memberNames = matchingFriends.slice(0, 2).map((f) => f.name).join(' & ');

      // Genereer de wachtrij
      const generatedQueue = generateRadioQueue({
        members,
        vibeId: vibe,
        discoveryLevel: 50,
        equalInfluence: true,
        groupName: `${track.title} Radio`,
      });

      // Zorg dat het startnummer vooraan staat
      const firstEntry: RecommendedTrack = {
        track,
        score: 100,
        matchedVibe: true,
        matchedFriendIds: matchingFriends.map((f) => f.id),
        contributingFriendIds: matchingFriends.slice(0, 3).map((f) => f.id),
        fairnessWeight: 1,
        discoveryScore: track.discoveryScore,
        primaryReason:
          matchingFriends.length > 0
            ? `Gestart vanaf "${track.title}" • Sluit aan bij smaak van ${memberNames}`
            : `Gestart vanaf "${track.title}" van ${track.artist}`,
      };

      const restQueue = generatedQueue.filter((item) => item.track.id !== track.id);
      const queue = [firstEntry, ...restQueue];

      const id = `session-track-${Date.now()}`;
      const newSession: RadioSession = {
        id,
        title: `${track.title} Radio`,
        subtitle: `Radio op basis van ${track.artist}${withFriends && matchingFriends.length > 0 ? ` + ${matchingFriends.length} vrienden` : ''}`,
        sourceType: 'track',
        memberIds: matchingFriends.map((f) => f.id),
        includeSelf: true,
        vibe,
        discoveryLevel: 50,
        equalInfluence: true,
        coverArtwork: track.albumArtwork,
        queue,
        currentIndex: 0,
        skippedTrackIds: [],
        playedTrackIds: [],
        createdAt: new Date().toISOString(),
        isSaved: false,
      };

      const initialVote = buildInitialVoteState(newSession);

      setPersisted((prev) => ({
        ...prev,
        sessions: { ...prev.sessions, [id]: newSession },
        voteStates: { ...prev.voteStates, [id]: initialVote },
        activeSessionId: id,
        currentTrackId: track.id,
      }));

      setProgressSec(0);
      setIsPlaying(true);
      setFullPlayerOpen(false);
      showToast(`Radio gestart vanaf "${track.title}"`);
      navigate({ name: 'group-radio', sessionId: id });

      return newSession;
    },
    [navigate, setFullPlayerOpen, showToast]
  );

  const getPlaylistData = useCallback(
    (playlistId: string) => {
      if (playlistId === 'liked') {
        const tracks = persisted.likedTrackIds
          .map((id) => TRACK_BY_ID[id])
          .filter((t): t is Track => Boolean(t));
        return {
          id: 'liked',
          title: 'Nummers die je leuk vindt',
          subtitle: `${tracks.length} nummers • Jouw favorieten`,
          artwork: generateSpecialCover('liked'),
          tracks: tracks.length > 0 ? tracks : TRACKS.slice(0, 15),
          category: 'Afspeellijst',
        };
      }

      const homePl = HOME_PLAYLISTS.find((p) => p.id === playlistId);
      if (homePl) {
        const tracks = homePl.trackIds
          .map((id) => TRACK_BY_ID[id])
          .filter((t): t is Track => Boolean(t));
        return {
          id: homePl.id,
          title: homePl.title,
          subtitle: homePl.subtitle,
          artwork: homePl.artwork,
          tracks,
          category: homePl.category,
        };
      }

      const album = RECOMMENDED_ALBUMS.find((a) => a.id === playlistId);
      if (album) {
        const seedTrack = TRACK_BY_ID[album.trackId];
        const genreTracks = TRACKS.filter(
          (t) => t.genre === album.genre || t.artist === album.artist
        );
        const albumTracks = [
          ...(seedTrack ? [seedTrack] : []),
          ...genreTracks.filter((t) => t.id !== album.trackId),
        ].slice(0, 10);

        return {
          id: album.id,
          title: album.title,
          subtitle: `Album • ${album.artist}`,
          artwork: album.artwork,
          tracks: albumTracks,
          category: 'Album',
        };
      }

      const group = persisted.groups.find((g) => g.id === playlistId);
      if (group) {
        const existingSession = Object.values(persisted.sessions).find(
          (s) => s.sourceGroupId === group.id
        );
        const tracks = existingSession
          ? existingSession.queue.map((q) => q.track)
          : TRACKS.slice(0, 12);

        return {
          id: group.id,
          title: `${group.name} Afspeellijst`,
          subtitle: group.description,
          artwork: group.coverArtwork,
          tracks,
          category: 'Groepslijst',
        };
      }

      const session = persisted.sessions[playlistId];
      if (session) {
        return {
          id: session.id,
          title: session.title,
          subtitle: session.subtitle,
          artwork: session.coverArtwork,
          tracks: session.queue.map((q) => q.track),
          category: 'Radio Afspeellijst',
        };
      }

      return null;
    },
    [persisted.groups, persisted.likedTrackIds, persisted.sessions]
  );

  const updateSessionSettings = useCallback(
    (
      sessionId: string,
      patch: Partial<Pick<RadioSession, 'vibe' | 'discoveryLevel' | 'equalInfluence'>>
    ) => {
      setPersisted((prev) => {
        const session = prev.sessions[sessionId];
        if (!session) return prev;

        const nextVibe = patch.vibe ?? session.vibe;
        const nextDiscovery = patch.discoveryLevel ?? session.discoveryLevel;
        const nextEqual = patch.equalInfluence ?? session.equalInfluence;

        const members = getMembersForIds(session.memberIds, session.includeSelf);
        const group = session.sourceGroupId
          ? prev.groups.find((g) => g.id === session.sourceGroupId)
          : undefined;
        const voteState = prev.voteStates[sessionId];
        const boostedTrackIds =
          voteState?.suggestions
            .filter((s) => s.votes >= 2 || s.userVoted)
            .sort((a, b) => b.votes - a.votes)
            .map((s) => s.trackId) ?? [];

        const currentEntry = session.queue[session.currentIndex];
        const excludePlayed = currentEntry ? [currentEntry.track.id] : [];

        const newUpcoming = generateRadioQueue({
          members,
          vibeId: nextVibe,
          discoveryLevel: nextDiscovery,
          equalInfluence: nextEqual,
          skippedTrackIds: session.skippedTrackIds,
          playedTrackIds: [...session.playedTrackIds, ...excludePlayed],
          boostedTrackIds,
          groupName: group?.name,
          limit: 20,
        });

        const updatedQueue = currentEntry ? [currentEntry, ...newUpcoming] : newUpcoming;

        return {
          ...prev,
          sessions: {
            ...prev.sessions,
            [sessionId]: {
              ...session,
              vibe: nextVibe,
              discoveryLevel: nextDiscovery,
              equalInfluence: nextEqual,
              queue: updatedQueue,
              currentIndex: 0,
            },
          },
        };
      });

      if (patch.vibe) {
        showToast(`Sfeer gewijzigd naar "${getVibePreset(patch.vibe).label}" — wachtrij vernieuwd`);
      }
    },
    [getMembersForIds, showToast]
  );

  const toggleSaveSession = useCallback(
    (sessionId: string) => {
      setPersisted((prev) => {
        const session = prev.sessions[sessionId];
        if (!session) return prev;
        const nextSaved = !session.isSaved;
        showToast(
          nextSaved ? 'Radio opgeslagen in je bibliotheek' : 'Radio verwijderd uit bibliotheek'
        );
        return {
          ...prev,
          sessions: {
            ...prev.sessions,
            [sessionId]: { ...session, isSaved: nextSaved },
          },
        };
      });
    },
    [showToast]
  );

  const activeVoteState = activeSession ? persisted.voteStates[activeSession.id] ?? null : null;

  const toggleGroupTrackLike = useCallback((sessionId: string, trackId: string) => {
    setPersisted((prev) => {
      const currentVote = prev.voteStates[sessionId] ?? {
        likesByTrackId: {},
        skipVotesByTrackId: {},
        suggestions: [],
        rules: { skipThreshold: 4, allowSuggestions: true },
      };
      const entry = currentVote.likesByTrackId[trackId] ?? {
        count: 0,
        userLiked: false,
        likerIds: [],
      };
      const userLiked = !entry.userLiked;
      const count = userLiked ? entry.count + 1 : Math.max(0, entry.count - 1);
      const likedTrackIds = userLiked
        ? Array.from(new Set([trackId, ...prev.likedTrackIds]))
        : prev.likedTrackIds.filter((id) => id !== trackId);

      return {
        ...prev,
        likedTrackIds,
        voteStates: {
          ...prev.voteStates,
          [sessionId]: {
            ...currentVote,
            likesByTrackId: {
              ...currentVote.likesByTrackId,
              [trackId]: { ...entry, count, userLiked },
            },
          },
        },
      };
    });
  }, []);

  const voteSkipTrack = useCallback(
    (sessionId: string, trackId: string): { skipped: boolean } => {
      let didSkip = false;
      setPersisted((prev) => {
        const session = prev.sessions[sessionId];
        const currentVote = prev.voteStates[sessionId];
        if (!session || !currentVote) return prev;

        const existing = currentVote.skipVotesByTrackId[trackId] ?? { count: 0, userVoted: false };
        if (existing.userVoted) return prev;

        const nextCount = existing.count + 1;
        const threshold = currentVote.rules.skipThreshold;
        const reached = nextCount >= threshold;
        didSkip = reached;

        const updatedVoteState: GroupVoteState = {
          ...currentVote,
          skipVotesByTrackId: {
            ...currentVote.skipVotesByTrackId,
            [trackId]: { count: nextCount, userVoted: true },
          },
        };

        if (!reached) {
          return {
            ...prev,
            voteStates: { ...prev.voteStates, [sessionId]: updatedVoteState },
          };
        }

        // Drempel bereikt -> sla nummer over en vernieuw wachtrij
        const nextSkipped = Array.from(new Set([...session.skippedTrackIds, trackId]));
        const remaining = session.queue.filter((q) => q.track.id !== trackId);
        const nextTrackItem = remaining[0];
        return {
          ...prev,
          currentTrackId: nextTrackItem ? nextTrackItem.track.id : prev.currentTrackId,
          sessions: {
            ...prev.sessions,
            [sessionId]: {
              ...session,
              skippedTrackIds: nextSkipped,
              queue: remaining,
              currentIndex: 0,
            },
          },
          voteStates: { ...prev.voteStates, [sessionId]: updatedVoteState },
        };
      });

      if (didSkip) {
        setProgressSec(0);
        showToast('Drempel bereikt — nummer overgeslagen door de groep');
      } else {
        showToast('Stem om over te slaan toegevoegd');
      }
      return { skipped: didSkip };
    },
    [showToast]
  );

  const suggestTrackToSession = useCallback(
    (sessionId: string, trackId: string) => {
      setPersisted((prev) => {
        const session = prev.sessions[sessionId];
        const voteState = prev.voteStates[sessionId];
        if (!session || !voteState) return prev;

        const already = voteState.suggestions.find((s) => s.trackId === trackId);
        let nextSuggestions = voteState.suggestions;
        if (already) {
          nextSuggestions = voteState.suggestions.map((s) =>
            s.trackId === trackId && !s.userVoted
              ? { ...s, votes: s.votes + 1, userVoted: true }
              : s
          );
        } else {
          nextSuggestions = [
            {
              id: `sug-${Date.now()}`,
              trackId,
              suggestedByIds: ['user-self'],
              votes: 1,
              userVoted: true,
            },
            ...voteState.suggestions,
          ];
        }

        // Herbereken wachtrij zodat voorgesteld nummer naar boven schuift
        const members = getMembersForIds(session.memberIds, session.includeSelf);
        const group = session.sourceGroupId
          ? prev.groups.find((g) => g.id === session.sourceGroupId)
          : undefined;
        const currentEntry = session.queue[session.currentIndex];
        const boostedIds = nextSuggestions
          .sort((a, b) => b.votes - a.votes)
          .map((s) => s.trackId);

        const rebuiltUpcoming = generateRadioQueue({
          members,
          vibeId: session.vibe,
          discoveryLevel: session.discoveryLevel,
          equalInfluence: session.equalInfluence,
          skippedTrackIds: session.skippedTrackIds,
          playedTrackIds: currentEntry ? [currentEntry.track.id] : [],
          boostedTrackIds: boostedIds,
          groupName: group?.name,
          limit: 20,
        });

        return {
          ...prev,
          sessions: {
            ...prev.sessions,
            [sessionId]: {
              ...session,
              queue: currentEntry ? [currentEntry, ...rebuiltUpcoming] : rebuiltUpcoming,
              currentIndex: 0,
            },
          },
          voteStates: {
            ...prev.voteStates,
            [sessionId]: { ...voteState, suggestions: nextSuggestions },
          },
        };
      });
      showToast('Nummer voorgesteld en omhooggestemd in de wachtrij');
    },
    [getMembersForIds, showToast]
  );

  const voteForSuggestion = useCallback(
    (sessionId: string, suggestionId: string) => {
      setPersisted((prev) => {
        const session = prev.sessions[sessionId];
        const voteState = prev.voteStates[sessionId];
        if (!session || !voteState) return prev;

        const nextSuggestions = voteState.suggestions.map((s) => {
          if (s.id !== suggestionId) return s;
          const userVoted = !s.userVoted;
          return { ...s, userVoted, votes: userVoted ? s.votes + 1 : Math.max(0, s.votes - 1) };
        });

        const members = getMembersForIds(session.memberIds, session.includeSelf);
        const group = session.sourceGroupId
          ? prev.groups.find((g) => g.id === session.sourceGroupId)
          : undefined;
        const currentEntry = session.queue[session.currentIndex];
        const boostedIds = nextSuggestions
          .filter((s) => s.votes >= 2 || s.userVoted)
          .sort((a, b) => b.votes - a.votes)
          .map((s) => s.trackId);

        const rebuiltUpcoming = generateRadioQueue({
          members,
          vibeId: session.vibe,
          discoveryLevel: session.discoveryLevel,
          equalInfluence: session.equalInfluence,
          skippedTrackIds: session.skippedTrackIds,
          playedTrackIds: currentEntry ? [currentEntry.track.id] : [],
          boostedTrackIds: boostedIds,
          groupName: group?.name,
          limit: 20,
        });

        return {
          ...prev,
          sessions: {
            ...prev.sessions,
            [sessionId]: {
              ...session,
              queue: currentEntry ? [currentEntry, ...rebuiltUpcoming] : rebuiltUpcoming,
              currentIndex: 0,
            },
          },
          voteStates: {
            ...prev.voteStates,
            [sessionId]: { ...voteState, suggestions: nextSuggestions },
          },
        };
      });
    },
    [getMembersForIds]
  );

  const updateVotingRules = useCallback(
    (sessionId: string, patch: Partial<GroupVoteState['rules']>) => {
      setPersisted((prev) => {
        const voteState = prev.voteStates[sessionId];
        if (!voteState) return prev;
        return {
          ...prev,
          voteStates: {
            ...prev.voteStates,
            [sessionId]: {
              ...voteState,
              rules: { ...voteState.rules, ...patch },
            },
          },
        };
      });
    },
    []
  );

  const simulateTeamActivity = useCallback(
    (sessionId: string) => {
      setPersisted((prev) => {
        const session = prev.sessions[sessionId];
        const voteState = prev.voteStates[sessionId];
        if (!session || !voteState) return prev;
        const curId = session.queue[session.currentIndex]?.track.id ?? prev.currentTrackId;
        const curLikes = voteState.likesByTrackId[curId] ?? {
          count: 2,
          userLiked: false,
          likerIds: [],
        };
        const curSkips = voteState.skipVotesByTrackId[curId] ?? { count: 0, userVoted: false };
        const nextLikeCount = Math.min(session.memberIds.length, curLikes.count + 2);
        const nextSkipCount = Math.min(voteState.rules.skipThreshold - 1, curSkips.count + 1);
        const nextSuggestions = voteState.suggestions.map((s, idx) =>
          idx === 0 ? { ...s, votes: s.votes + 1 } : s
        );

        return {
          ...prev,
          voteStates: {
            ...prev.voteStates,
            [sessionId]: {
              ...voteState,
              likesByTrackId: {
                ...voteState.likesByTrackId,
                [curId]: { ...curLikes, count: nextLikeCount },
              },
              skipVotesByTrackId: {
                ...voteState.skipVotesByTrackId,
                [curId]: { ...curSkips, count: nextSkipCount },
              },
              suggestions: nextSuggestions,
            },
          },
        };
      });
      showToast('Groepsactiviteit gesimuleerd (lokale demo)');
    },
    [showToast]
  );

  const createGroup = useCallback(
    (data: {
      name: string;
      description: string;
      memberIds: string[];
      coverTheme: GroupCoverTheme;
      defaultVibe: VibeId;
    }): Group => {
      const codePrefix = data.name
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, '')
        .slice(0, 6);
      const newGroup: Group = {
        id: `g-custom-${Date.now()}`,
        name: data.name,
        description: data.description || `${data.memberIds.length} leden`,
        memberIds: data.memberIds,
        coverArtwork: generateGroupCover(data.name, data.coverTheme),
        coverTheme: data.coverTheme,
        defaultVibe: data.defaultVibe,
        defaultDiscovery: 45,
        equalInfluence: true,
        inviteCode: `SPOTIFY-${codePrefix || 'GROEP'}-26`,
        isCustom: true,
      };
      setPersisted((prev) => ({
        ...prev,
        groups: [newGroup, ...prev.groups],
      }));
      showToast(`Groep "${newGroup.name}" aangemaakt`);
      return newGroup;
    },
    [showToast]
  );

  const updateGroup = useCallback(
    (
      groupId: string,
      patch: Partial<
        Pick<
          Group,
          | 'name'
          | 'description'
          | 'memberIds'
          | 'coverTheme'
          | 'defaultVibe'
          | 'defaultDiscovery'
          | 'equalInfluence'
        >
      >
    ) => {
      setPersisted((prev) => ({
        ...prev,
        groups: prev.groups.map((g) => {
          if (g.id !== groupId) return g;
          const nextName = patch.name ?? g.name;
          const nextTheme = patch.coverTheme ?? g.coverTheme;
          return {
            ...g,
            ...patch,
            coverArtwork:
              patch.name || patch.coverTheme ? generateGroupCover(nextName, nextTheme) : g.coverArtwork,
          };
        }),
      }));
      showToast('Groepsinstellingen opgeslagen');
    },
    [showToast]
  );

  const updatePrivacy = useCallback(
    (patch: Partial<PrivacySettings>) => {
      setPersisted((prev) => ({
        ...prev,
        privacy: { ...prev.privacy, ...patch },
      }));
      showToast('Privacyvoorkeuren bijgewerkt');
    },
    [showToast]
  );

  const dismissOnboarding = useCallback(() => {
    setOnboardingOpen(false);
    setPersisted((prev) => ({ ...prev, onboardingDismissed: true }));
  }, []);

  const openOnboarding = useCallback(() => {
    setOnboardingOpen(true);
  }, []);

  const value: AppContextValue = {
    route,
    activeTab,
    canGoBack: navStack.length > 1,
    navigate,
    switchTab,
    goBack,
    currentUser: effectiveCurrentUser,
    friends: FRIENDS,
    groups: persisted.groups,
    sessions: persisted.sessions,
    activeSession,
    likedTrackIds: persisted.likedTrackIds,
    currentTrack,
    currentRecommendedEntry,
    isPlaying,
    progressSec,
    shuffle,
    repeat,
    synthAudioEnabled,
    selectedDevice,
    fullPlayerOpen,
    setFullPlayerOpen,
    togglePlay,
    playTrack,
    playSessionTrackAt,
    nextTrack,
    prevTrack,
    seekTo,
    toggleShuffle,
    cycleRepeat,
    toggleSynthAudio,
    setSelectedDevice,
    toggleLikeTrack,
    createAndStartRadio,
    startTrackRadio,
    getPlaylistData,
    updateSessionSettings,
    toggleSaveSession,
    activeVoteState,
    toggleGroupTrackLike,
    voteSkipTrack,
    suggestTrackToSession,
    voteForSuggestion,
    updateVotingRules,
    simulateTeamActivity,
    createGroup,
    updateGroup,
    whyTrack,
    openWhyModal: (entry) => setWhyTrack(entry),
    closeWhyModal: () => setWhyTrack(null),
    votingSheetOpen,
    setVotingSheetOpen,
    deviceSheetOpen,
    setDeviceSheetOpen,
    privacyModalOpen,
    setPrivacyModalOpen,
    onboardingOpen,
    dismissOnboarding,
    openOnboarding,
    privacy: persisted.privacy,
    updatePrivacy,
    toastMessage,
    showToast,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp moet binnen AppProvider gebruikt worden');
  }
  return ctx;
}
