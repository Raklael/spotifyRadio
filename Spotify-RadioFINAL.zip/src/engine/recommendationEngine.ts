import {
  DiscoveryInsight,
  Friend,
  Genre,
  Group,
  RecommendationBreakdown,
  RecommendedTrack,
  Track,
  VibeId,
  VibePreset,
} from '../types/music';
import { TRACKS, TRACK_BY_ID, VIBE_PRESETS } from '../data/mockData';

/**
 * Modulaire aanbevelingsservice voor Spotify Friends Radio.
 *
 * Let op: dit is een transparant, deterministisch gewogen scoringsmodel
 * op basis van lokale simulatiedata — geen getraind ML-model.
 * Kan later 1-op-1 worden vervangen door een echte ML/collaborative-filtering API.
 */

export function getVibePreset(vibeId: VibeId): VibePreset {
  return VIBE_PRESETS.find((v) => v.id === vibeId) ?? VIBE_PRESETS[0];
}

export function isDutchTrack(track: Track): boolean {
  if (track.genre === 'Nederlandstalig' || track.genre === 'Feest') return true;
  const dutchArtists = [
    'Antoon',
    'Flemming',
    'Suzan & Freek',
    'Goldband',
    'Roxy Dekker',
    'Guus Meeuwis',
    'Acda en De Munnik',
    'Kris Kross Amsterdam',
    'Froukje',
    'André Hazes',
    'Snelle',
    'Claude',
    'Ronnie Flex',
    'Fresku',
    'Lijpe',
    'Sor',
    'Sef',
    'Josylvio',
    'Ares',
    'Wies',
    'S10',
    'Bente',
    'Spinvis',
    'BLØF',
    'Kensington',
    'De Staat',
    'Reinier Zonneveld',
    'Chris Stussy',
    'Job Jobse',
    'Martin Garrix',
    'Tiësto',
    'Lucas & Steve',
    'Sam Feldt',
    'Headhunterz',
    'Sub Zero Project',
    'Wildstylez',
    'Sefa',
    'Brennan Heart',
    'Vertile',
    'Rooler',
    'Joost',
    'MEAU',
    'Numidia',
    'Tabitha',
    'Snollebollekes',
    'Marco Schuitmaker',
    'Django Wagner',
    'De Lawineboys',
    'Vieze Jack',
  ];
  return dutchArtists.some((a) => track.artist.includes(a));
}

export function computeMemberTrackAffinity(member: Friend, track: Track): number {
  if (member.dislikedTracks.includes(track.id)) {
    return 0.02;
  }

  let score = 0.12; // baseline neutrale kans

  if (member.likedTracks.includes(track.id)) {
    score += 0.44;
  }
  if (member.recentlyPlayed.includes(track.id)) {
    score += 0.14;
  }
  if (member.favoriteGenres.includes(track.genre)) {
    const genreIdx = member.favoriteGenres.indexOf(track.genre);
    score += genreIdx === 0 ? 0.28 : genreIdx === 1 ? 0.21 : 0.15;
  }
  if (
    member.favoriteArtists.some(
      (artist) =>
        track.artist.toLowerCase().includes(artist.toLowerCase()) ||
        artist.toLowerCase().includes(track.artist.toLowerCase())
    )
  ) {
    score += 0.3;
  }

  const energyDiff = Math.abs(member.listeningPreferences.energyPreference - track.energy);
  const danceDiff = Math.abs(
    member.listeningPreferences.danceabilityPreference - track.danceability
  );
  score += Math.max(0, 0.14 - (energyDiff + danceDiff) * 0.12);

  if (isDutchTrack(track)) {
    score += (member.listeningPreferences.dutchMusicAffinity - 0.4) * 0.14;
  }

  return Math.max(0, Math.min(1, score));
}

export function calculateFriendCompatibility(
  user: Friend,
  friend: Friend
): {
  score: number;
  sharedGenres: Genre[];
  sharedArtists: string[];
  mutualTracks: Track[];
} {
  const sharedGenres = user.favoriteGenres.filter((g) => friend.favoriteGenres.includes(g));
  const sharedArtists = user.favoriteArtists.filter((a) => friend.favoriteArtists.includes(a));
  const mutualTrackIds = Array.from(
    new Set([
      ...user.likedTracks.filter((id) => friend.likedTracks.includes(id)),
      ...user.recentlyPlayed.filter(
        (id) => friend.likedTracks.includes(id) || friend.recentlyPlayed.includes(id)
      ),
    ])
  );
  const mutualTracks = mutualTrackIds
    .map((id) => TRACK_BY_ID[id])
    .filter((t): t is Track => Boolean(t));

  const genreRatio =
    sharedGenres.length /
    Math.max(1, Math.min(user.favoriteGenres.length, friend.favoriteGenres.length));
  const artistRatio =
    sharedArtists.length /
    Math.max(1, Math.min(user.favoriteArtists.length, friend.favoriteArtists.length));
  const trackBonus = Math.min(1, mutualTracks.length / 4);

  const energySim =
    1 - Math.abs(user.listeningPreferences.energyPreference - friend.listeningPreferences.energyPreference);
  const danceSim =
    1 -
    Math.abs(
      user.listeningPreferences.danceabilityPreference -
        friend.listeningPreferences.danceabilityPreference
    );
  const dutchSim =
    1 -
    Math.abs(
      user.listeningPreferences.dutchMusicAffinity - friend.listeningPreferences.dutchMusicAffinity
    );
  const prefSim = (energySim + danceSim + dutchSim) / 3;

  const rawScore = genreRatio * 0.36 + artistRatio * 0.26 + trackBonus * 0.2 + prefSim * 0.18;
  const percentage = Math.round(Math.max(38, Math.min(96, 36 + rawScore * 60)));

  return {
    score: percentage,
    sharedGenres,
    sharedArtists,
    mutualTracks,
  };
}

export function computeDynamicWeights(
  vibe: VibePreset,
  discoveryLevel: number,
  equalInfluence: boolean
) {
  // Basisgewichten (ontwerpaannames, geen wetenschappelijk model):
  // groupTaste: 0.35, vibe: 0.25, fairness: 0.20, discovery: 0.15, diversity: 0.05
  const normDiscovery = Math.max(0, Math.min(1, discoveryLevel / 100 + vibe.discoveryBias));

  // Verschuif tussen groepssmaak (vertrouwd) en ontdekking (verrassend)
  const discoveryShift = (normDiscovery - 0.5) * 0.22; // -0.11 tot +0.11

  let groupTaste = 0.35 - discoveryShift * 0.7;
  let discovery = 0.15 + discoveryShift;
  let vibeWeight = 0.25;
  let fairness = equalInfluence ? 0.2 : 0.04;
  let diversity = 0.05 + (equalInfluence ? 0 : 0.03);

  if (!equalInfluence) {
    groupTaste += 0.09;
    vibeWeight += 0.04;
  }

  // Normaliseer naar som = 1
  const total = groupTaste + vibeWeight + fairness + discovery + diversity;
  return {
    groupTaste: Number((groupTaste / total).toFixed(3)),
    vibe: Number((vibeWeight / total).toFixed(3)),
    fairness: Number((fairness / total).toFixed(3)),
    discovery: Number((discovery / total).toFixed(3)),
    diversity: Number((diversity / total).toFixed(3)),
  };
}

function computeVibeMatch(track: Track, vibe: VibePreset): number {
  const energyScore = 1 - Math.abs(track.energy - vibe.targetEnergy);
  const danceScore = 1 - Math.abs(track.danceability - vibe.targetDanceability);
  const moodBonus = vibe.preferredMoods.includes(track.mood) ? 0.25 : 0;
  const genreBonus = vibe.preferredGenres.includes(track.genre) ? 0.25 : 0;

  return Math.max(0, Math.min(1, energyScore * 0.32 + danceScore * 0.28 + moodBonus + genreBonus));
}

function formatNamesList(names: string[]): string {
  if (names.length === 0) return 'de groep';
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} en ${names[1]}`;
  return `${names[0]}, ${names[1]} en ${names[2]}`;
}

export interface GenerateQueueInput {
  members: Friend[];
  vibeId: VibeId;
  discoveryLevel: number; // 0 - 100
  equalInfluence: boolean;
  skippedTrackIds?: string[];
  playedTrackIds?: string[];
  boostedTrackIds?: string[];
  limit?: number;
  groupName?: string;
}

export function generateRadioQueue({
  members,
  vibeId,
  discoveryLevel,
  equalInfluence,
  skippedTrackIds = [],
  playedTrackIds = [],
  boostedTrackIds = [],
  limit = 22,
  groupName,
}: GenerateQueueInput): RecommendedTrack[] {
  if (members.length === 0) return [];

  const vibe = getVibePreset(vibeId);
  const weights = computeDynamicWeights(vibe, discoveryLevel, equalInfluence);
  const normDiscovery = Math.max(0, Math.min(1, discoveryLevel / 100 + vibe.discoveryBias));

  const excludedIds = new Set([...skippedTrackIds, ...playedTrackIds]);
  const candidates = TRACKS.filter((t) => !excludedIds.has(t.id));

  const memberCredits: Record<string, number> = Object.fromEntries(members.map((m) => [m.id, 0]));
  const selected: RecommendedTrack[] = [];
  const usedIds = new Set<string>();

  const targetCount = Math.min(limit, candidates.length);

  for (let step = 0; step < targetCount; step++) {
    const minCredit = Math.min(...Object.values(memberCredits));
    const maxCredit = Math.max(...Object.values(memberCredits));
    const recentWindow = selected.slice(-4).map((s) => s.track);

    let bestEntry: RecommendedTrack | null = null;
    let bestAdjustedScore = -Infinity;

    for (const track of candidates) {
      if (usedIds.has(track.id)) continue;

      // 1. Groepssmaak & individuele bijdrage
      const affinities = members.map((m) => ({
        member: m,
        affinity: computeMemberTrackAffinity(m, track),
      }));

      const avgAffinity =
        affinities.reduce((sum, item) => sum + item.affinity, 0) / affinities.length;
      const supporters = affinities.filter((a) => a.affinity >= 0.45);
      const consensusBonus = Math.min(0.25, (supporters.length / members.length) * 0.25);

      // Vermijd tracks die veel leden expliciet niet leuk vinden
      const dislikeCount = members.filter((m) => m.dislikedTracks.includes(track.id)).length;
      const dislikePenalty = (dislikeCount / members.length) * 0.4;

      const groupTasteMatch = Math.max(0, Math.min(1, avgAffinity + consensusBonus - dislikePenalty));

      // 2. Sfeermatch
      const vibeMatch = computeVibeMatch(track, vibe);

      // 3. Eerlijkheid (fairness): geef ondervertegenwoordigde groepsleden een duwtje
      let fairnessScore = 0.6;
      if (equalInfluence && members.length > 1) {
        const creditSpan = Math.max(0.5, maxCredit - minCredit);
        let weightedNeed = 0;
        let totalWeight = 0;
        for (const { member, affinity } of affinities) {
          const deficit = (maxCredit - memberCredits[member.id]) / creditSpan;
          weightedNeed += affinity * (0.4 + deficit * 0.9);
          totalWeight += 1;
        }
        fairnessScore = Math.max(0, Math.min(1, (weightedNeed / totalWeight) * 1.45));
      }

      // 4. Ontdekkingsscore (afhankelijk van discovery slider)
      const knownByCount = members.filter(
        (m) => m.likedTracks.includes(track.id) || m.recentlyPlayed.includes(track.id)
      ).length;
      const unfamiliarCount = members.length - knownByCount;
      const unfamiliarRatio = unfamiliarCount / members.length;

      // Als slider laag (vertrouwd) staat, krijgen bekende hits juist hogere score;
      // als slider hoog (verrassend) staat, krijgen onbekende parels hogere score.
      const noveltyFit =
        normDiscovery >= 0.5
          ? track.discoveryScore * 0.55 + unfamiliarRatio * 0.45
          : (1 - track.discoveryScore) * 0.5 + (1 - unfamiliarRatio) * 0.5;
      const discoveryScore = Math.max(0, Math.min(1, noveltyFit));

      // 5. Diversiteit (voorkom herhaling van artiest of genre achter elkaar)
      const sameArtistRecent = recentWindow.filter((t) => t.artist === track.artist).length;
      const sameGenreLastTwo = selected
        .slice(-2)
        .filter((s) => s.track.genre === track.genre).length;
      let diversityScore = 1;
      if (sameArtistRecent > 0) diversityScore -= 0.75;
      if (sameGenreLastTwo >= 2) diversityScore -= 0.45;
      else if (sameGenreLastTwo === 1) diversityScore -= 0.15;
      diversityScore = Math.max(0, diversityScore);

      const finalScore =
        groupTasteMatch * weights.groupTaste +
        vibeMatch * weights.vibe +
        fairnessScore * weights.fairness +
        discoveryScore * weights.discovery +
        diversityScore * weights.diversity;

      // Hard penalty als dezelfde artiest direct achter elkaar zou komen
      const backToBackArtistPenalty =
        selected.length > 0 && selected[selected.length - 1].track.artist === track.artist
          ? 0.45
          : 0;

      // Boost voor door de groep voorgestelde / gestemde nummers
      const boostIndex = boostedTrackIds.indexOf(track.id);
      const voteBoost = boostIndex >= 0 ? 0.55 : 0;

      const adjustedScore = finalScore - backToBackArtistPenalty + voteBoost;

      if (adjustedScore > bestAdjustedScore) {
        bestAdjustedScore = adjustedScore;

        const sortedContributors = [...affinities]
          .sort((a, b) => b.affinity - a.affinity)
          .slice(0, Math.min(4, members.length))
          .map((a) => a.member);

        const artistFans = members.filter((m) =>
          m.favoriteArtists.some((fa) => track.artist.toLowerCase().includes(fa.toLowerCase()))
        );
        const genreFans = members.filter((m) => m.favoriteGenres.includes(track.genre));
        const sharedMutualCount = members.filter((m) => m.likedTracks.includes(track.id)).length;

        // Bepaal primaire sociale uitleg op basis van échte mockdata
        const topNames = sortedContributors.slice(0, 3).map((m) => m.name);
        let primaryReason = '';

        if (boostIndex >= 0) {
          primaryReason = 'Aangevraagd en omhooggestemd door de groep.';
        } else if (members.length === 2) {
          const other = members.find((m) => m.id !== 'user-self') ?? members[0];
          if (artistFans.some((f) => f.id === other.id)) {
            primaryReason = `Aanbevolen omdat ${other.name} van ${track.artist} houdt en jij vergelijkbare muziek luistert.`;
          } else if (sharedMutualCount === 2) {
            primaryReason = `Een gezamenlijke favoriet van jou en ${other.name}.`;
          } else if (unfamiliarCount >= 1 && normDiscovery > 0.55) {
            primaryReason = `Nieuwe ontdekking in ${track.genre} die past bij jullie gedeelde smaak.`;
          } else {
            primaryReason = `Mixt jouw smaak met die van ${other.name} binnen ${track.genre}.`;
          }
        } else if (unfamiliarCount >= Math.ceil(members.length * 0.7) && normDiscovery >= 0.55) {
          primaryReason = `Nieuwe ontdekking voor ${unfamiliarCount} van de ${members.length} ${
            groupName?.toLowerCase().includes('zaterdag') ? 'spelers' : 'leden'
          }.`;
        } else if (artistFans.length >= 2) {
          primaryReason = `${formatNamesList(
            artistFans.slice(0, 2).map((f) => f.name)
          )} luisteren vaak naar ${track.artist}.`;
        } else if (sharedMutualCount >= Math.max(3, Math.ceil(members.length * 0.28))) {
          primaryReason = groupName
            ? `Een favoriet binnen ${groupName}.`
            : `Geliefd door ${sharedMutualCount} groepsleden.`;
        } else {
          primaryReason = `Dit nummer past bij de smaak van ${formatNamesList(topNames)}.`;
        }

        const detailedReasons: string[] = [];
        detailedReasons.push(
          artistFans.length > 0
            ? `${artistFans.length} ${
                artistFans.length === 1 ? 'groepslid luistert' : 'groepsleden luisteren'
              } graag naar ${track.artist}`
            : `${genreFans.length} groepsleden hebben ${track.genre} als favoriet genre`
        );
        detailedReasons.push(`Past bij jullie gekozen sfeer: ${vibe.label}`);
        if (sharedMutualCount > 0) {
          detailedReasons.push(
            `Direct geliket door ${sharedMutualCount} van de ${members.length} ${
              members.length > 6 ? 'groepsleden' : 'leden'
            }`
          );
        } else {
          detailedReasons.push(`Sluit aan op het tempo en energieprofiel van de groep`);
        }
        if (unfamiliarCount > Math.floor(members.length * 0.5)) {
          detailedReasons.push(
            `Nieuw voor ${unfamiliarCount} van de ${members.length} leden — hoge ontdekkingswaarde`
          );
        } else {
          detailedReasons.push(`Bekend herkenningspunt voor een groot deel van de groep`);
        }

        const breakdown: RecommendationBreakdown = {
          groupTasteMatch: Number(groupTasteMatch.toFixed(2)),
          vibeMatch: Number(vibeMatch.toFixed(2)),
          fairnessScore: Number(fairnessScore.toFixed(2)),
          discoveryScore: Number(discoveryScore.toFixed(2)),
          diversityScore: Number(diversityScore.toFixed(2)),
          weights,
          finalScore: Number(finalScore.toFixed(3)),
        };

        bestEntry = {
          track,
          score: Math.round(finalScore * 100),
          breakdown,
          contributingFriendIds: sortedContributors.map((m) => m.id),
          unfamiliarCount,
          totalMembers: members.length,
          primaryReason,
          detailedReasons,
        };
      }
    }

    if (!bestEntry) break;

    selected.push(bestEntry);
    usedIds.add(bestEntry.track.id);

    // Update fairness credits voor alle leden op basis van wie dit nummer bedient
    for (const member of members) {
      const aff = computeMemberTrackAffinity(member, bestEntry.track);
      memberCredits[member.id] += aff;
    }
  }

  return selected;
}

export function computeSocialInsights(
  friends: Friend[],
  groups: Group[]
): DiscoveryInsight[] {
  const insights: DiscoveryInsight[] = [];

  // 1. Meest populaire track onder alle vrienden
  const listenerCounts: Record<string, Friend[]> = {};
  for (const friend of friends) {
    const unique = new Set([...friend.likedTracks, ...friend.recentlyPlayed]);
    for (const tid of unique) {
      if (!listenerCounts[tid]) listenerCounts[tid] = [];
      listenerCounts[tid].push(friend);
    }
  }

  const sortedByPopularity = Object.entries(listenerCounts)
    .sort((a, b) => b[1].length - a[1].length)
    .slice(0, 6);

  if (sortedByPopularity[0]) {
    const [tid, fans] = sortedByPopularity[0];
    const track = TRACK_BY_ID[tid];
    if (track) {
      insights.push({
        id: `ins-pop-${tid}`,
        track,
        headline: `${fans.length} vrienden luisteren naar dit nummer.`,
        subtext: `O.a. ${fans.slice(0, 3).map((f) => f.name).join(', ')}`,
        friendIds: fans.slice(0, 4).map((f) => f.id),
        badge: 'Trending bij vrienden',
      });
    }
  }

  // 2. Nieuw ontdekt door Milan en Thomas (of top 2 online vrienden)
  const milan = friends.find((f) => f.id === 'f-milan');
  const thomas = friends.find((f) => f.id === 'f-thomas');
  if (milan && thomas) {
    const sharedDiscovery =
      milan.likedTracks.find(
        (id) => thomas.likedTracks.includes(id) && id !== sortedByPopularity[0]?.[0]
      ) ?? 't013';
    const track = TRACK_BY_ID[sharedDiscovery];
    if (track) {
      insights.push({
        id: `ins-pair-${track.id}`,
        track,
        headline: `Nieuw ontdekt door ${milan.name} en ${thomas.name}.`,
        subtext: `${track.genre} • Sluit 81% aan bij jouw smaak`,
        friendIds: [milan.id, thomas.id],
        badge: 'Samen ontdekt',
      });
    }
  }

  // 3. Populair in jouw voetbalteam (FC Zaterdag 3)
  const fcTeam = groups.find((g) => g.id === 'g-fc-zaterdag-3') ?? groups[0];
  if (fcTeam) {
    const teamMembers = friends.filter((f) => fcTeam.memberIds.includes(f.id));
    const teamCounts: Record<string, Friend[]> = {};
    for (const m of teamMembers) {
      for (const tid of m.likedTracks) {
        if (!teamCounts[tid]) teamCounts[tid] = [];
        teamCounts[tid].push(m);
      }
    }
    const topTeam = Object.entries(teamCounts)
      .filter(([tid]) => !insights.some((i) => i.track.id === tid))
      .sort((a, b) => b[1].length - a[1].length)[0];

    if (topTeam) {
      const track = TRACK_BY_ID[topTeam[0]];
      if (track) {
        insights.push({
          id: `ins-team-${track.id}`,
          track,
          headline: `Populair in jouw voetbalteam.`,
          subtext: `${topTeam[1].length} spelers van ${fcTeam.name} hebben dit geliket`,
          friendIds: topTeam[1].slice(0, 4).map((f) => f.id),
          badge: fcTeam.name,
        });
      }
    }
  }

  // 4. Extra indie/ontdekkingstip van Lisa & Emma
  const lisa = friends.find((f) => f.id === 'f-lisa');
  const emma = friends.find((f) => f.id === 'f-emma');
  if (lisa && emma) {
    const indieTip =
      lisa.likedTracks.find(
        (id) => emma.likedTracks.includes(id) && !insights.some((i) => i.track.id === id)
      ) ?? 't048';
    const track = TRACK_BY_ID[indieTip];
    if (track) {
      insights.push({
        id: `ins-indie-${track.id}`,
        track,
        headline: `Veel gedraaid door ${lisa.name} en ${emma.name}.`,
        subtext: `Favoriet in De vriendengroep`,
        friendIds: [lisa.id, emma.id],
        badge: 'Vrienden favoriet',
      });
    }
  }

  return insights;
}

export function computeGroupAnalytics(group: Group, members: Friend[]) {
  const genreCounts: Record<string, number> = {};
  const artistCounts: Record<string, number> = {};
  const trackCounts: Record<string, number> = {};

  for (const m of members) {
    for (const g of m.favoriteGenres) {
      genreCounts[g] = (genreCounts[g] ?? 0) + 1;
    }
    for (const a of m.favoriteArtists) {
      artistCounts[a] = (artistCounts[a] ?? 0) + 1;
    }
    for (const t of m.likedTracks) {
      trackCounts[t] = (trackCounts[t] ?? 0) + 1;
    }
  }

  const topGenres = Object.entries(genreCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([genre, count]) => ({
      genre: genre as Genre,
      count,
      percentage: Math.round((count / Math.max(1, members.length)) * 100),
    }));

  const topArtists = Object.entries(artistCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([artist, count]) => ({ artist, count }));

  const sharedFavorites = Object.entries(trackCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([id, count]) => ({ track: TRACK_BY_ID[id], count }))
    .filter((item): item is { track: Track; count: number } => Boolean(item.track));

  // Nieuwe ontdekkingen speciaal voor deze groep (hoge discoveryScore, onbekend bij leden)
  const discoveries = generateRadioQueue({
    members,
    vibeId: 'nieuwe-muziek',
    discoveryLevel: 85,
    equalInfluence: true,
    limit: 4,
    groupName: group.name,
  });

  return {
    topGenres,
    topArtists,
    sharedFavorites,
    discoveries,
  };
}
