export type Genre =
  | 'Hip-hop'
  | 'House & Techno'
  | 'Pop'
  | 'Indie'
  | 'Nederlandstalig'
  | 'Rock'
  | 'Dance & EDM'
  | 'Hardstyle'
  | 'R&B'
  | 'Feest';

export type Mood =
  | 'energiek'
  | 'feest'
  | 'chill'
  | 'euforisch'
  | 'gefocust'
  | 'meezinger'
  | 'zomers'
  | 'donker';

export type VibeId =
  | 'gewoon-gezellig'
  | 'voor-de-wedstrijd'
  | 'derde-helft'
  | 'huisfeest'
  | 'onderweg'
  | 'nieuwe-muziek';

export interface VibePreset {
  id: VibeId;
  label: string;
  shortDesc: string;
  impactDesc: string;
  targetEnergy: number; // 0 - 1
  targetDanceability: number; // 0 - 1
  preferredMoods: string[];
  preferredGenres: Genre[];
  discoveryBias: number; // -0.15 to +0.25 adjustment
  accentColor: string;
  iconName: string;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  albumArtwork: string;
  genre: Genre;
  energy: number; // 0 - 1
  danceability: number; // 0 - 1
  mood: string;
  popularity: number; // 0 - 100
  discoveryScore: number; // 0 - 1 (higher = newer / less mainstream)
  duration: number; // seconds
  accentColor: string;
}

export interface ListeningPreferences {
  energyPreference: number; // 0 - 1
  danceabilityPreference: number; // 0 - 1
  discoveryAppetite: number; // 0 - 1
  dutchMusicAffinity: number; // 0 - 1
}

export interface Friend {
  id: string;
  name: string;
  fullName: string;
  avatar: string;
  roleOrTag?: string;
  isOnline: boolean;
  currentActivity: string;
  favoriteGenres: Genre[];
  favoriteArtists: string[];
  likedTracks: string[];
  dislikedTracks: string[];
  recentlyPlayed: string[];
  listeningPreferences: ListeningPreferences;
}

export type GroupCoverTheme = 'football' | 'friends' | 'housemates' | 'festival' | 'night';

export interface Group {
  id: string;
  name: string;
  description: string;
  memberIds: string[];
  coverArtwork: string;
  coverTheme: GroupCoverTheme;
  defaultVibe: VibeId;
  defaultDiscovery: number; // 0 - 100
  equalInfluence: boolean;
  inviteCode: string;
  isCustom?: boolean;
}

export interface RecommendationBreakdown {
  groupTasteMatch: number; // 0 - 1
  vibeMatch: number; // 0 - 1
  fairnessScore: number; // 0 - 1
  discoveryScore: number; // 0 - 1
  diversityScore: number; // 0 - 1
  weights: {
    groupTaste: number;
    vibe: number;
    fairness: number;
    discovery: number;
    diversity: number;
  };
  finalScore: number;
}

export interface RecommendedTrack {
  track: Track;
  score: number;
  breakdown: RecommendationBreakdown;
  contributingFriendIds: string[];
  unfamiliarCount: number;
  totalMembers: number;
  primaryReason: string;
  detailedReasons: string[];
}

export interface SuggestedTrack {
  id: string;
  trackId: string;
  suggestedByIds: string[];
  votes: number;
  userVoted: boolean;
}

export interface GroupVotingRules {
  skipThreshold: number;
  allowSuggestions: boolean;
}

export interface GroupVoteState {
  likesByTrackId: Record<string, { count: number; userLiked: boolean; likerIds: string[] }>;
  skipVotesByTrackId: Record<string, { count: number; userVoted: boolean }>;
  suggestions: SuggestedTrack[];
  rules: GroupVotingRules;
}

export interface RadioSession {
  id: string;
  title: string;
  subtitle: string;
  sourceType: 'friend' | 'friends' | 'group' | 'track';
  sourceGroupId?: string;
  memberIds: string[]; // friend IDs (current user 'user-self' is implicitly included or explicitly tracked)
  includeSelf: boolean;
  vibe: VibeId;
  discoveryLevel: number; // 0 (Vertrouwd) - 100 (Verrassend)
  equalInfluence: boolean;
  coverArtwork: string;
  queue: RecommendedTrack[];
  currentIndex: number;
  skippedTrackIds: string[];
  playedTrackIds: string[];
  createdAt: string;
  isSaved: boolean;
}

export interface PrivacySettings {
  shareTasteWithFriends: boolean;
  shareFavoriteGenres: boolean;
  shareLikedSongs: boolean;
  participateInGroupRadios: boolean;
}

export interface HomePlaylist {
  id: string;
  title: string;
  subtitle: string;
  artwork: string;
  category: 'Muziek' | 'Podcasts' | 'Mix';
  trackIds: string[];
  badge?: string;
}

export interface DiscoveryInsight {
  id: string;
  track: Track;
  headline: string;
  subtext: string;
  friendIds: string[];
  badge: string;
}

export type ActiveTab = 'home' | 'search' | 'friends' | 'library';

export type ViewRoute =
  | { name: 'tab'; tab: ActiveTab }
  | { name: 'friend-profile'; friendId: string }
  | { name: 'group-profile'; groupId: string }
  | { name: 'playlist-detail'; playlistId: string }
  | { name: 'radio-builder'; preselectedFriendIds?: string[]; preselectedGroupId?: string; initialStep?: 1 | 2 | 3 | 4 }
  | { name: 'group-radio'; sessionId: string };
