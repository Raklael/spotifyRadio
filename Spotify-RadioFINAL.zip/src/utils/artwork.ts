import { Genre, GroupCoverTheme } from '../types/music';

function encodeSvg(svg: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const GENRE_PALETTES: Record<Genre, [string, string, string]> = {
  'Hip-hop': ['#F97316', '#991B1B', '#181818'],
  'House & Techno': ['#06B6D4', '#312E81', '#09090B'],
  Pop: ['#EC4899', '#7E22CE', '#18181B'],
  Indie: ['#F59E0B', '#0F766E', '#1C1917'],
  Nederlandstalig: ['#FB923C', '#EA580C', '#1E293B'],
  Rock: ['#EF4444', '#27272A', '#09090B'],
  'Dance & EDM': ['#3B82F6', '#4F46E5', '#0F172A'],
  Hardstyle: ['#A855F7', '#DC2626', '#09090B'],
  'R&B': ['#C084FC', '#831843', '#18181B'],
  Feest: ['#1ED760', '#EAB308', '#14532D'],
};

function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function getGenreAccent(genre: Genre): string {
  return GENRE_PALETTES[genre]?.[0] ?? '#1ED760';
}

export function generateAlbumArtwork(
  id: string,
  title: string,
  artist: string,
  genre: Genre
): string {
  const hash = hashString(`${id}-${title}-${artist}`);
  const [c1, c2, c3] = GENRE_PALETTES[genre] ?? ['#1ED760', '#166534', '#121212'];
  const pattern = hash % 4;
  const cx1 = 40 + (hash % 120);
  const cy1 = 40 + ((hash >> 3) % 120);
  const rot = (hash % 60) - 30;
  const safeTitle = escapeXml(title.slice(0, 16));
  const safeArtist = escapeXml(artist.slice(0, 18).toUpperCase());

  let shapes = '';
  if (pattern === 0) {
    shapes = `
      <circle cx="${cx1}" cy="${cy1}" r="95" fill="${c1}" fill-opacity="0.55"/>
      <circle cx="${200 - cx1}" cy="${200 - cy1}" r="70" fill="${c2}" fill-opacity="0.7"/>
      <circle cx="100" cy="100" r="42" fill="none" stroke="rgba(255,255,255,0.28)" stroke-width="2"/>
    `;
  } else if (pattern === 1) {
    shapes = `
      <g transform="rotate(${rot} 100 100)">
        <rect x="-20" y="35" width="240" height="44" rx="22" fill="${c1}" fill-opacity="0.65"/>
        <rect x="-10" y="100" width="220" height="32" rx="16" fill="rgba(255,255,255,0.16)"/>
      </g>
      <circle cx="152" cy="52" r="24" fill="${c1}" fill-opacity="0.8"/>
    `;
  } else if (pattern === 2) {
    shapes = `
      <polygon points="0,200 105,30 200,200" fill="${c1}" fill-opacity="0.45"/>
      <polygon points="40,200 145,55 200,200" fill="${c2}" fill-opacity="0.65"/>
      <circle cx="62" cy="58" r="22" fill="rgba(255,255,255,0.2)"/>
    `;
  } else {
    shapes = `
      <rect x="24" y="24" width="152" height="152" rx="24" fill="none" stroke="${c1}" stroke-width="10" stroke-opacity="0.6"/>
      <circle cx="100" cy="100" r="46" fill="${c1}" fill-opacity="0.75"/>
      <circle cx="100" cy="100" r="14" fill="${c3}"/>
    `;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${c2}"/>
        <stop offset="55%" stop-color="${c3}"/>
        <stop offset="100%" stop-color="#0a0a0a"/>
      </linearGradient>
    </defs>
    <rect width="200" height="200" fill="url(#g)"/>
    ${shapes}
    <rect width="200" height="200" fill="url(#g)" fill-opacity="0.12"/>
    <text x="16" y="164" fill="rgba(255,255,255,0.92)" font-family="system-ui, -apple-system, sans-serif" font-size="15" font-weight="800" letter-spacing="-0.3">${safeTitle}</text>
    <text x="16" y="182" fill="rgba(255,255,255,0.65)" font-family="system-ui, -apple-system, sans-serif" font-size="10" font-weight="700" letter-spacing="1.1">${safeArtist}</text>
  </svg>`;

  return encodeSvg(svg);
}

export const REAL_PERSON_AVATARS: Record<string, string> = {
  Jij: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=256&h=256&q=80',
  Milan: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&h=256&q=80',
  Thomas: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&h=256&q=80',
  Lisa: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=256&h=256&q=80',
  Daan: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=256&h=256&q=80',
  Bram: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=256&h=256&q=80',
  Niels: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=256&h=256&q=80',
  Julia: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=256&h=256&q=80',
  Sven: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=256&h=256&q=80',
  Emma: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=256&h=256&q=80',
  Luuk: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=256&h=256&q=80',
  Joost: 'https://images.unsplash.com/photo-1517070208541-6ddc4d3efbcb?auto=format&fit=crop&w=256&h=256&q=80',
  Rick: 'https://images.unsplash.com/photo-1463453091185-61582044d556?auto=format&fit=crop&w=256&h=256&q=80',
  Tim: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=256&h=256&q=80',
  Bas: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=256&h=256&q=80',
  Koen: 'https://images.unsplash.com/photo-1513956589380-bad6acb9b9d4?auto=format&fit=crop&w=256&h=256&q=80',
  Sam: 'https://images.unsplash.com/photo-1480429370139-e0132c086e2a?auto=format&fit=crop&w=256&h=256&q=80',
  Max: 'https://images.unsplash.com/photo-1528892952291-009c663ce843?auto=format&fit=crop&w=256&h=256&q=80',
  Jesse: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=256&h=256&q=80',
  Timo: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=256&h=256&q=80',
  Lars: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=256&h=256&q=80',
};

export function generateAvatarArtwork(name: string, seedIndex: number, isSelf = false): string {
  if (isSelf) return REAL_PERSON_AVATARS['Jij'];
  if (REAL_PERSON_AVATARS[name]) return REAL_PERSON_AVATARS[name];

  const pool = Object.values(REAL_PERSON_AVATARS);
  return pool[Math.abs(seedIndex) % pool.length];
}

export function generateGroupCover(name: string, theme: GroupCoverTheme): string {
  const safeName = escapeXml(name.slice(0, 18));

  if (theme === 'football') {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="240" height="240">
      <defs>
        <linearGradient id="fc" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#1ED760"/>
          <stop offset="45%" stop-color="#14532D"/>
          <stop offset="100%" stop-color="#09090B"/>
        </linearGradient>
      </defs>
      <rect width="240" height="240" fill="url(#fc)"/>
      <!-- Abstract football pitch lines -->
      <rect x="20" y="20" width="200" height="200" rx="18" fill="none" stroke="rgba(255,255,255,0.16)" stroke-width="2"/>
      <line x1="20" y1="120" x2="220" y2="120" stroke="rgba(255,255,255,0.18)" stroke-width="2"/>
      <circle cx="120" cy="120" r="38" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="2.5"/>
      <circle cx="120" cy="120" r="8" fill="#1ED760"/>
      <path d="M72 20 L72 52 L168 52 L168 20" fill="none" stroke="rgba(255,255,255,0.18)" stroke-width="2"/>
      <path d="M72 220 L72 188 L168 188 L168 220" fill="none" stroke="rgba(255,255,255,0.18)" stroke-width="2"/>
      <!-- Sound rings -->
      <circle cx="120" cy="120" r="68" fill="none" stroke="#1ED760" stroke-opacity="0.35" stroke-width="3" stroke-dasharray="10 8"/>
      <rect x="18" y="176" width="204" height="44" rx="10" fill="rgba(0,0,0,0.52)"/>
      <text x="30" y="204" fill="#FFFFFF" font-family="system-ui, sans-serif" font-size="18" font-weight="800">${safeName}</text>
    </svg>`;
    return encodeSvg(svg);
  }

  const palettes: Record<Exclude<GroupCoverTheme, 'football'>, [string, string]> = {
    friends: ['#F97316', '#7E22CE'],
    housemates: ['#06B6D4', '#1E3A8A'],
    festival: ['#EC4899', '#EAB308'],
    night: ['#8B5CF6', '#09090B'],
  };
  const [p1, p2] = palettes[theme === 'friends' || theme === 'housemates' || theme === 'festival' || theme === 'night' ? theme : 'friends'];

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="240" height="240">
    <defs>
      <linearGradient id="gr" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${p1}"/>
        <stop offset="100%" stop-color="${p2}"/>
      </linearGradient>
    </defs>
    <rect width="240" height="240" fill="url(#gr)"/>
    <circle cx="65" cy="80" r="55" fill="rgba(255,255,255,0.14)"/>
    <circle cx="165" cy="110" r="65" fill="rgba(0,0,0,0.22)"/>
    <circle cx="120" cy="110" r="32" fill="none" stroke="rgba(255,255,255,0.45)" stroke-width="3"/>
    <rect x="18" y="176" width="204" height="44" rx="10" fill="rgba(0,0,0,0.48)"/>
    <text x="30" y="204" fill="#FFFFFF" font-family="system-ui, sans-serif" font-size="18" font-weight="800">${safeName}</text>
  </svg>`;
  return encodeSvg(svg);
}

export function generateSpecialCover(kind: 'liked' | 'friends-radio' | 'podcast-1' | 'podcast-2' | 'mix-1' | 'mix-2'): string {
  const configs: Record<typeof kind, { c1: string; c2: string; label: string; sub: string }> = {
    liked: { c1: '#4F46E5', c2: '#C4B5FD', label: '♥', sub: 'Gelikete nummers' },
    'friends-radio': { c1: '#1ED760', c2: '#064E3B', label: 'RADIO', sub: 'Vriendenmix' },
    'podcast-1': { c1: '#EA580C', c2: '#431407', label: 'POD', sub: 'De Derde Helft' },
    'podcast-2': { c1: '#0284C7', c2: '#082F49', label: 'POD', sub: 'Muziek & Smaak' },
    'mix-1': { c1: '#DB2777', c2: '#500724', label: 'MIX 1', sub: 'Dagelijkse Mix' },
    'mix-2': { c1: '#7C3AED', c2: '#1E1B4B', label: 'MIX 2', sub: 'Nederlandse Mix' },
  };
  const cfg = configs[kind];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <defs>
      <linearGradient id="sp" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${cfg.c1}"/>
        <stop offset="100%" stop-color="${cfg.c2}"/>
      </linearGradient>
    </defs>
    <rect width="200" height="200" fill="url(#sp)"/>
    <circle cx="155" cy="45" r="55" fill="rgba(255,255,255,0.12)"/>
    <text x="100" y="108" text-anchor="middle" fill="#FFFFFF" font-family="system-ui, sans-serif" font-size="${kind === 'liked' ? '58' : '32'}" font-weight="900">${cfg.label}</text>
    <text x="100" y="168" text-anchor="middle" fill="rgba(255,255,255,0.85)" font-family="system-ui, sans-serif" font-size="14" font-weight="700">${cfg.sub}</text>
  </svg>`;
  return encodeSvg(svg);
}
