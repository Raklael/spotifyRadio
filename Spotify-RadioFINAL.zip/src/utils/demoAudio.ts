import { Track } from '../types/music';

/**
 * Royalty-free Web Audio API synthesizer preview voor de interactieve demosimulatie.
 * Speelt alleen wanneer de gebruiker expliciet 'Demo-audio' aanzet in de speler.
 */
class DemoSynthPlayer {
  private ctx: AudioContext | null = null;
  private timer: number | null = null;
  private step = 0;

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public start(track: Track) {
    this.stop();
    const ctx = this.ensureContext();
    if (!ctx) return;

    const bpm = Math.round(92 + track.energy * 42);
    const intervalMs = Math.round((60 / bpm / 2) * 1000);
    const scale = [220, 261.63, 293.66, 329.63, 392.0, 440];

    this.timer = window.setInterval(() => {
      if (!this.ctx || this.ctx.state !== 'running') return;
      const now = this.ctx.currentTime;

      // Subtiele bass/kick op tel 0 en 4
      if (this.step % 4 === 0) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(110, now);
        osc.frequency.exponentialRampToValueAtTime(48, now + 0.14);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.17);
      }

      // Zachte melodische pluck op basis van track-energie
      if (this.step % 2 === 0) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = track.energy > 0.8 ? 'triangle' : 'sine';
        const noteIdx = (this.step + track.title.length) % scale.length;
        osc.frequency.setValueAtTime(scale[noteIdx], now);
        gain.gain.setValueAtTime(0.035, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.24);
      }

      this.step = (this.step + 1) % 16;
    }, intervalMs);
  }

  public stop() {
    if (this.timer !== null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  }
}

export const demoSynth = new DemoSynthPlayer();
