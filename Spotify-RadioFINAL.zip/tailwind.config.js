/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        spotify: {
          bg: '#121212',
          elevated: '#181818',
          card: '#282828',
          cardHover: '#333333',
          green: '#1ED760',
          greenHover: '#1FDF64',
          greenDark: '#169C46',
          text: '#FFFFFF',
          muted: '#B3B3B3',
          subtle: '#727272',
        },
      },
      fontFamily: {
        sans: [
          'Circular',
          'Plus Jakarta Sans',
          'Inter',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'sans-serif',
        ],
      },
    },
  },
  plugins: [],
};
