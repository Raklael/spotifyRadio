import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ command }) => ({
  plugins: [
    react(),
    command === 'serve'
      ? {
          name: 'serve-app-html-on-root',
          configureServer(server) {
            server.middlewares.use((req, _res, next) => {
              if (req.url === '/' || req.url === '/index.html') {
                req.url = '/app.html';
              }
              next();
            });
          },
        }
      : null,
  ].filter(Boolean),
  build: {
    rollupOptions: {
      input: 'app.html',
    },
  },
}));
